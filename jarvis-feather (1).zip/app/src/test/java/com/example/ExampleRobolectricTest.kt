package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.DeviceCapabilities
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches JARVIS Feather`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS Feather", appName)
    }

    @Test
    fun `device capabilities inspect returns valid snapshot`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val snapshot = DeviceCapabilities.inspect(context)
        assertTrue(snapshot.maxSupportedVideoHeight >= 720)
    }
}
