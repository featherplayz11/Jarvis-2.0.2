package com.example

import com.example.ai.AiModelRegistry
import com.example.ai.LocalCommandAction
import com.example.ai.OfflineAssistantEngine
import com.example.ai.VoiceWakeResult
import com.example.data.model.AssistantMode
import com.example.data.model.GameCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JarvisCoreUnitTest {

    @Test
    fun strictVoiceCommandsActivateAndSwitchAsSpecified() {
        val j = OfflineAssistantEngine.parseVoiceWakeCommand("Hey JARVIS", AssistantMode.INACTIVE, "Feather")
        assertTrue(j is VoiceWakeResult.Activate)
        assertEquals(AssistantMode.JARVIS_ONLY, (j as VoiceWakeResult.Activate).mode)

        val r = OfflineAssistantEngine.parseVoiceWakeCommand("Hey ROSE", AssistantMode.JARVIS_ONLY, "Sujan")
        assertTrue(r is VoiceWakeResult.Activate)
        assertEquals(AssistantMode.ROSE_ONLY, (r as VoiceWakeResult.Activate).mode)

        val both = OfflineAssistantEngine.parseVoiceWakeCommand("Hey JARVIS and ROSE", AssistantMode.INACTIVE, "Feather")
        assertTrue(both is VoiceWakeResult.Activate)
        assertEquals(AssistantMode.DUAL_MODE, (both as VoiceWakeResult.Activate).mode)

        val jOnly = OfflineAssistantEngine.parseVoiceWakeCommand("Hey JARVIS only", AssistantMode.DUAL_MODE, "Feather")
        assertTrue(jOnly is VoiceWakeResult.Activate)
        assertEquals(AssistantMode.JARVIS_ONLY, (jOnly as VoiceWakeResult.Activate).mode)

        val rOnly = OfflineAssistantEngine.parseVoiceWakeCommand("Hey ROSE only", AssistantMode.DUAL_MODE, "Feather")
        assertTrue(rOnly is VoiceWakeResult.Activate)
        assertEquals(AssistantMode.ROSE_ONLY, (rOnly as VoiceWakeResult.Activate).mode)

        val stopBoth = OfflineAssistantEngine.parseVoiceWakeCommand("Stop both", AssistantMode.DUAL_MODE, "Feather")
        assertTrue(stopBoth is VoiceWakeResult.StopBoth)
    }

    @Test
    fun accidentalAndUnclearSpeechDoesNotActivateAssistants() {
        val accidentalRose = OfflineAssistantEngine.parseVoiceWakeCommand("I bought a red rose today", AssistantMode.INACTIVE, "Feather")
        assertTrue(accidentalRose is VoiceWakeResult.UnclearOrAccidental)

        val bareName = OfflineAssistantEngine.parseVoiceWakeCommand("jarvis", AssistantMode.INACTIVE, "Feather")
        assertTrue(bareName is VoiceWakeResult.UnclearOrAccidental)

        // Normal query while already active should pass through as null (not treated as wake switch)
        val normalQuery = OfflineAssistantEngine.parseVoiceWakeCommand("tell me a joke about roses", AssistantMode.ROSE_ONLY, "Feather")
        assertNull(normalQuery)
    }

    @Test
    fun voiceReminderParsingExtractsTitleAndDelay() {
        val action = OfflineAssistantEngine.parseCommandOrOfflineReply(
            "Remind me to export Minecraft highlight in 25 minutes"
        )
        assertTrue(action is LocalCommandAction.CreateReminder)
        val reminder = action as LocalCommandAction.CreateReminder
        assertEquals("export Minecraft highlight", reminder.title)
        assertEquals(25L, reminder.delayMinutes)
    }

    @Test
    fun offlineEngineProvidesAllGamingGenres() {
        GameCategory.entries.forEach { category ->
            val tip = OfflineAssistantEngine.gamingTipsFor(category)
            assertTrue(tip.isNotBlank())
        }
    }

    @Test
    fun modelRegistryDefaultsToGemini38FlashAndNeverInventsGemini5() {
        assertEquals("gemini-3.8-flash", AiModelRegistry.verifiedModels.first().id)
        assertFalse(AiModelRegistry.verifiedModels.any { it.id.contains("gemini-5", ignoreCase = true) })
    }
}
