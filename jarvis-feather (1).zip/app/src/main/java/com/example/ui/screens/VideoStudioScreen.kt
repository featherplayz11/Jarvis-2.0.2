package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.model.ColorGradePreset
import com.example.data.model.ExportResolution
import com.example.data.model.TransitionType
import com.example.data.model.VideoStylePreset
import com.example.ui.theme.AmberPulse
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramCardElevated
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.OutlineCyan
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import com.example.videoeditor.VideoEditorViewModel
import com.example.videoeditor.VideoExportState

@Composable
fun VideoStudioScreen(
    editorVm: VideoEditorViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val state by editorVm.state.collectAsStateWithLifecycle()
    val canUndo by editorVm.canUndo.collectAsStateWithLifecycle()
    val canRedo by editorVm.canRedo.collectAsStateWithLifecycle()
    val exportState by editorVm.exportState.collectAsStateWithLifecycle()
    val aiSuggestion by editorVm.aiSuggestion.collectAsStateWithLifecycle()
    val isAnalyzingAi by editorVm.isAnalyzingAi.collectAsStateWithLifecycle()
    val savedProjects by editorVm.savedProjects.collectAsStateWithLifecycle()
    val statusBanner by editorVm.statusBanner.collectAsStateWithLifecycle()

    val selectedClip = state.clips.getOrNull(state.selectedClipIndex)

    // Zero-permission Photo Picker for videos
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { editorVm.importVideoUri(it) }
    }

    // SAF OpenDocument for audio / music tracks
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { editorVm.importBackgroundAudio(it, it.lastPathSegment ?: "Music Track") }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(selectedClip?.uriString, selectedClip?.trimStartMs, selectedClip?.trimEndMs, selectedClip?.speed) {
        if (selectedClip != null) {
            val item = MediaItem.Builder()
                .setUri(Uri.parse(selectedClip.uriString))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(selectedClip.trimStartMs)
                        .setEndPositionMs(selectedClip.trimEndMs)
                        .build()
                )
                .build()
            exoPlayer.setMediaItem(item)
            exoPlayer.setPlaybackSpeed(selectedClip.speed)
            exoPlayer.prepare()
        } else {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepVoidNavy, SpaceSlate, DeepVoidNavy)))
            .padding(horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 820.dp).fillMaxSize()) {
            // Top Studio Toolbar
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("studio_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = JarvisCyan)
                    }
                    Text("AI VIDEO STUDIO", style = MaterialTheme.typography.titleLarge, color = JarvisCyan)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(enabled = canUndo, onClick = { editorVm.undo() }, modifier = Modifier.testTag("editor_undo")) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = if (canUndo) IceWhite else MistBlue.copy(alpha = 0.35f))
                    }
                    IconButton(enabled = canRedo, onClick = { editorVm.redo() }, modifier = Modifier.testTag("editor_redo")) {
                        Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = if (canRedo) IceWhite else MistBlue.copy(alpha = 0.35f))
                    }
                    IconButton(onClick = { editorVm.saveProject() }, modifier = Modifier.testTag("editor_save")) {
                        Icon(Icons.Default.Save, "Save project", tint = NeonMint)
                    }
                }
            }

            statusBanner?.let { msg ->
                Text(
                    text = msg,
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonMint,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Video Preview Player
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(HologramPanel)
                            .border(1.dp, OutlineCyan, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedClip != null) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        player = exoPlayer
                                        useController = true
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.MovieCreation, null, tint = JarvisCyan, modifier = Modifier.size(40.dp))
                                Spacer(Modifier.height(6.dp))
                                Text("Import a video via Android Photo Picker", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                Text("Non-destructive editing: original files are never overwritten", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                            }
                        }
                    }
                }

                // Import & AI Director Actions
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            modifier = Modifier.weight(1f).testTag("import_video_button")
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(4.dp))
                            Text("Import Video")
                        }
                        OutlinedButton(
                            onClick = { audioPicker.launch(arrayOf("audio/*")) },
                            modifier = Modifier.weight(1f).testTag("import_audio_button")
                        ) {
                            Icon(Icons.Default.MusicNote, null, tint = RoseAzure)
                            Spacer(Modifier.width(4.dp))
                            Text("Add Music")
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = { editorVm.requestAiDirectorAnalysis() },
                        colors = ButtonDefaults.buttonColors(containerColor = HologramCardElevated),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, JarvisCyan, RoundedCornerShape(12.dp))
                            .testTag("ai_director_button")
                    ) {
                        if (isAnalyzingAi) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = JarvisCyan)
                            Spacer(Modifier.width(8.dp))
                            Text("Gemini Analyzing Frames...", color = JarvisCyan)
                        } else {
                            Icon(Icons.Default.AutoAwesome, null, tint = JarvisCyan)
                            Spacer(Modifier.width(6.dp))
                            Text("AI Video Director (Suggest Cuts, SFX, Music & Subtitles)", color = JarvisCyan)
                        }
                    }
                }

                // AI Suggestion Preview & Apply Card
                aiSuggestion?.let { suggestion ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = HologramCardElevated),
                            modifier = Modifier.fillMaxWidth().border(1.dp, JarvisCyan, RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("AI Director Plan (${suggestion.recommendedStyle})", style = MaterialTheme.typography.titleMedium, color = JarvisCyan)
                                Text(suggestion.summary, style = MaterialTheme.typography.bodySmall, color = IceWhite)
                                Text("Cuts: ${suggestion.cutRecommendations.joinToString(" | ")}", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                                Text("Music: ${suggestion.musicMood} • SFX: ${suggestion.soundEffects.joinToString()}", style = MaterialTheme.typography.bodySmall, color = RoseAzure)
                                Text("Subtitles: ${suggestion.suggestedSubtitles.joinToString(" / ")}", style = MaterialTheme.typography.bodySmall, color = NeonMint)
                                Button(
                                    onClick = { editorVm.applyAiSuggestion(suggestion) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Approve & Apply AI Edits to Timeline")
                                }
                            }
                        }
                    }
                }

                // Timeline Clips Strip
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = HologramPanel),
                        modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Timeline (${state.clips.size} clips • Audio: ${state.musicTitle})", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            if (state.clips.isNotEmpty()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    state.clips.forEachIndexed { idx, clip ->
                                        val isSelected = idx == state.selectedClipIndex
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(if (isSelected) JarvisCyan.copy(alpha = 0.22f) else HologramCardElevated)
                                                .border(1.dp, if (isSelected) JarvisCyan else OutlineCyan, RoundedCornerShape(10.dp))
                                                .clickable { editorVm.selectClip(idx) }
                                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                        ) {
                                            Column {
                                                Text(clip.title, style = MaterialTheme.typography.labelLarge, color = IceWhite)
                                                Text(
                                                    "${(clip.trimEndMs - clip.trimStartMs) / 1000}s @ ${clip.speed}x",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = JarvisCyan
                                                )
                                            }
                                        }
                                    }
                                }

                                // Clip Controls (Trim, Split, Speed, Transition, Reorder, Delete)
                                selectedClip?.let { clip ->
                                    val maxDur = clip.durationMs.toFloat().coerceAtLeast(1000f)
                                    Text(
                                        "Trim: ${clip.trimStartMs / 1000}s – ${clip.trimEndMs / 1000}s",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MistBlue
                                    )
                                    RangeSlider(
                                        value = clip.trimStartMs.toFloat()..clip.trimEndMs.toFloat(),
                                        onValueChange = { range ->
                                            editorVm.updateSelectedTrim(range.start.toLong(), range.endInclusive.toLong())
                                        },
                                        valueRange = 0f..maxDur
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        OutlinedButton(onClick = { editorVm.splitSelectedClipAtMidpoint() }) {
                                            Icon(Icons.Default.ContentCut, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Split")
                                        }
                                        OutlinedButton(onClick = { editorVm.moveSelectedClipLeft() }) {
                                            Text("Move Left")
                                        }
                                        OutlinedButton(onClick = { editorVm.removeSelectedClip() }) {
                                            Icon(Icons.Default.Delete, null, tint = CrimsonAlert, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Text("Playback Speed", style = MaterialTheme.typography.labelMedium, color = MistBlue)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                            FilterChip(
                                                selected = clip.speed == spd,
                                                onClick = { editorVm.setSelectedClipSpeed(spd) },
                                                label = { Text("${spd}x") }
                                            )
                                        }
                                    }
                                    Text("Clip Transition", style = MaterialTheme.typography.labelMedium, color = MistBlue)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        TransitionType.entries.forEach { tr ->
                                            FilterChip(
                                                selected = clip.transitionAfter == tr,
                                                onClick = { editorVm.setSelectedTransition(tr) },
                                                label = { Text(tr.label) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Style Presets, Color Correction, Text/Subtitles, SFX
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = HologramPanel),
                        modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Editing Style Presets", style = MaterialTheme.typography.titleMedium, color = JarvisCyan)
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                VideoStylePreset.entries.forEach { preset ->
                                    FilterChip(
                                        selected = state.stylePreset == preset,
                                        onClick = { editorVm.applyStylePreset(preset) },
                                        label = { Text(preset.label) }
                                    )
                                }
                            }

                            Text("Color Correction & Cinematic Grade", style = MaterialTheme.typography.labelMedium, color = MistBlue)
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ColorGradePreset.entries.forEach { grade ->
                                    FilterChip(
                                        selected = state.colorGrade == grade,
                                        onClick = { editorVm.setColorGrade(grade) },
                                        label = { Text(grade.label) }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = state.projectName,
                                onValueChange = { editorVm.setProjectName(it) },
                                label = { Text("Project Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = state.textOverlay,
                                onValueChange = { editorVm.setTextAndSubtitles(it, state.subtitleText) },
                                label = { Text("Title Overlay Text") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = state.subtitleText,
                                onValueChange = { editorVm.setTextAndSubtitles(state.textOverlay, it) },
                                label = { Text("Subtitles / Captions Burn-in") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("SFX Cue Markers", style = MaterialTheme.typography.labelMedium, color = MistBlue)
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Whoosh", "Bass Drop", "Glitch Zap", "Vine Boom", "Chime").forEach { sfx ->
                                    FilterChip(
                                        selected = sfx in state.sfxTags,
                                        onClick = { editorVm.toggleSfxTag(sfx) },
                                        label = { Text(sfx) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Media3 Transformer Export Section
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = HologramCardElevated),
                        modifier = Modifier.fillMaxWidth().border(1.dp, JarvisCyan, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Media3 Export (Max HW Height: ${editorVm.maxHardwareHeight}p)",
                                style = MaterialTheme.typography.titleMedium,
                                color = JarvisCyan
                            )
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ExportResolution.entries.forEach { res ->
                                    val supported = res.heightPx <= editorVm.maxHardwareHeight
                                    FilterChip(
                                        selected = state.resolution == res,
                                        enabled = supported,
                                        onClick = { editorVm.setExportConfig(res, res.defaultBitrateMbps) },
                                        label = { Text(if (supported) res.label else "${res.label} (Unsupported)") }
                                    )
                                }
                            }
                            Text("Target Bitrate: ${state.bitrateMbps} Mbps", style = MaterialTheme.typography.labelMedium, color = MistBlue)
                            Slider(
                                value = state.bitrateMbps.toFloat(),
                                onValueChange = { editorVm.setExportConfig(state.resolution, it.toInt()) },
                                valueRange = 2f..24f
                            )

                            when (val exp = exportState) {
                                VideoExportState.Idle -> {
                                    Button(
                                        onClick = { editorVm.startExport() },
                                        enabled = state.clips.isNotEmpty(),
                                        modifier = Modifier.fillMaxWidth().testTag("export_video_button")
                                    ) {
                                        Text("Export Rendered MP4")
                                    }
                                }
                                is VideoExportState.Exporting -> {
                                    LinearProgressIndicator(
                                        progress = { exp.progressPercent / 100f },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Rendering ${exp.progressPercent}%...", color = JarvisCyan)
                                        TextButton(onClick = { editorVm.cancelExport() }) {
                                            Text("Cancel Export", color = CrimsonAlert)
                                        }
                                    }
                                }
                                is VideoExportState.Completed -> {
                                    Text("Exported cleanly: ${exp.outputFile.name}", color = NeonMint, style = MaterialTheme.typography.labelMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            val shareUri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                exp.outputFile
                                            )
                                            val share = Intent(Intent.ACTION_SEND).apply {
                                                type = "video/mp4"
                                                putExtra(Intent.EXTRA_STREAM, shareUri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(share, "Share Exported Video"))
                                        }) {
                                            Icon(Icons.Default.Share, null)
                                            Spacer(Modifier.width(4.dp))
                                            Text("Share Video")
                                        }
                                        OutlinedButton(onClick = { editorVm.processor.resetExportState() }) {
                                            Text("Done")
                                        }
                                    }
                                }
                                is VideoExportState.Failed -> {
                                    Text("Export Error: ${exp.message}", color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = { editorVm.processor.resetExportState() }) {
                                        Text("Dismiss")
                                    }
                                }
                            }
                        }
                    }
                }

                // Saved Projects List
                item {
                    AnimatedVisibility(visible = savedProjects.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = HologramPanel),
                            modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Saved Local Projects", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                savedProjects.forEach { proj ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${proj.name} (${proj.stylePreset})", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                                        TextButton(onClick = { editorVm.loadProject(proj) }) {
                                            Text("Load", color = JarvisCyan)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
