package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ConversationMessageEntity
import com.example.data.model.AssistantMode
import com.example.data.model.Speaker
import com.example.ui.AssistantStreamState
import com.example.ui.JarvisViewModel
import com.example.ui.hologram.HologramStage
import com.example.ui.theme.AmberPulse
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramCardElevated
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.OutlineCyan
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import com.example.voice.SpeechListenState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AssistantHubScreen(
    viewModel: JarvisViewModel,
    onOpenStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs by viewModel.prefs.collectAsStateWithLifecycle()
    val assistantMode by viewModel.assistantMode.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val streamState by viewModel.streamState.collectAsStateWithLifecycle()
    val speakingChar by viewModel.speakingCharacter.collectAsStateWithLifecycle()
    val lipAmplitude by viewModel.lipAmplitude.collectAsStateWithLifecycle()
    val speechState by viewModel.speechState.collectAsStateWithLifecycle()
    val deviceHealth by viewModel.deviceHealth.collectAsStateWithLifecycle()
    val isDualActive by viewModel.isDualConversationActive.collectAsStateWithLifecycle()
    val isDualPaused by viewModel.isDualPaused.collectAsStateWithLifecycle()
    val pendingApps by viewModel.pendingAppClarification.collectAsStateWithLifecycle()
    val accessibilityBanner by viewModel.accessibilityBanner.collectAsStateWithLifecycle()
    val continuousListening by viewModel.continuousListening.collectAsStateWithLifecycle()
    val wakeServiceRunning by viewModel.wakeServiceRunning.collectAsStateWithLifecycle()
    val voiceHintBanner by viewModel.voiceHintBanner.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var pendingContinuousToggle by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (pendingContinuousToggle) {
                viewModel.toggleContinuousVoiceStandby(true)
            } else {
                viewModel.startVoiceListen()
            }
        }
        pendingContinuousToggle = false
    }

    LaunchedEffect(messages.size, streamState) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val isListening = continuousListening ||
        speechState is SpeechListenState.Listening ||
        speechState is SpeechListenState.Partial

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepVoidNavy, SpaceSlate, DeepVoidNavy)
                )
            )
            .imePadding()
            .padding(horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
        ) {
            // Top Futuristic HUD Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JARVIS FEATHER",
                        style = MaterialTheme.typography.titleLarge,
                        color = JarvisCyan
                    )
                    val greetingTarget = if (prefs.groupModeEnabled) prefs.groupTitle else prefs.privateName
                    Text(
                        text = "${assistantMode.displayName} • $greetingTarget • RAM ${deviceHealth.availableRamMb}MB",
                        style = MaterialTheme.typography.labelSmall,
                        color = MistBlue
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Small microphone / listening status indicator
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isListening || wakeServiceRunning) NeonMint.copy(alpha = 0.16f) else HologramPanel,
                        modifier = Modifier
                            .border(
                                1.dp,
                                if (isListening || wakeServiceRunning) NeonMint else OutlineCyan,
                                RoundedCornerShape(50)
                            )
                            .testTag("mic_status_indicator")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isListening || wakeServiceRunning) Icons.Default.GraphicEq else Icons.Default.Mic,
                                contentDescription = "Microphone listening status",
                                tint = if (isListening || wakeServiceRunning) NeonMint else MistBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = when {
                                    isListening -> "MIC ON"
                                    wakeServiceRunning -> "STANDBY"
                                    else -> "MIC OFF"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isListening || wakeServiceRunning) NeonMint else MistBlue
                            )
                        }
                    }

                    val online = prefs.onlineModeEnabled && deviceHealth.isOnline
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (online) NeonMint.copy(alpha = 0.16f) else AmberPulse.copy(alpha = 0.16f),
                        modifier = Modifier
                            .border(
                                1.dp,
                                if (online) NeonMint else AmberPulse,
                                RoundedCornerShape(50)
                            )
                            .clickable { viewModel.refreshDeviceHealth() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (online) Icons.Default.Wifi else Icons.Default.WifiOff,
                                contentDescription = "Connectivity status",
                                tint = if (online) NeonMint else AmberPulse,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (online) prefs.activeTextModel else "OFFLINE",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (online) NeonMint else AmberPulse
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.clearHistory() },
                        modifier = Modifier.testTag("clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear conversation history",
                            tint = MistBlue
                        )
                    }
                }
            }

            // Visible Accessibility Control Indicator (if running)
            AnimatedVisibility(visible = accessibilityBanner != null) {
                Surface(
                    color = CrimsonAlert.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .border(1.dp, CrimsonAlert, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = accessibilityBanner ?: "",
                            style = MaterialTheme.typography.labelMedium,
                            color = IceWhite
                        )
                        TextButton(onClick = { viewModel.stopAllVoiceAndAi() }) {
                            Text("STOP", color = CrimsonAlert, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Hologram Stage: shows ONLY when voice-activated (INACTIVE hides both character faces)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(
                        when (assistantMode) {
                            AssistantMode.INACTIVE -> 152.dp
                            AssistantMode.DUAL_MODE -> 176.dp
                            else -> 204.dp
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                HologramStage(
                    mode = assistantMode,
                    speakingCharacter = speakingChar,
                    lipAmplitude = lipAmplitude,
                    isListening = isListening,
                    graphicsQuality = prefs.graphicsQuality,
                    reducedAnimations = prefs.reducedAnimationMode || prefs.batterySaverMode
                )
            }

            // Utility & Microphone Standby Row (NO character mode/activation buttons anywhere)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(
                    onClick = {
                        if (continuousListening) {
                            viewModel.toggleContinuousVoiceStandby(false)
                        } else {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                viewModel.toggleContinuousVoiceStandby(true)
                            } else {
                                pendingContinuousToggle = true
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    label = { Text(if (continuousListening) "Stop Mic Standby" else "Voice Standby Mic") },
                    leadingIcon = {
                        Icon(
                            imageVector = if (continuousListening) Icons.Default.Stop else Icons.Default.Hearing,
                            contentDescription = "Voice standby microphone toggle",
                            tint = if (continuousListening) CrimsonAlert else NeonMint,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(containerColor = HologramPanel, labelColor = IceWhite),
                    modifier = Modifier.testTag("voice_standby_toggle_chip")
                )

                if (isDualActive) {
                    Button(
                        onClick = { viewModel.togglePauseDualConversation() },
                        colors = ButtonDefaults.buttonColors(containerColor = AmberPulse),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("dual_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isDualPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = "Pause or resume dual chat",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(if (isDualPaused) "Resume" else "Pause")
                    }
                    Button(
                        onClick = { viewModel.stopAllVoiceAndAi() },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("dual_stop_button")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop speaking", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Stop")
                    }
                }

                AssistChip(
                    onClick = onOpenStudio,
                    label = { Text("Video Studio") },
                    leadingIcon = {
                        Icon(Icons.Default.MovieCreation, null, tint = JarvisCyan, modifier = Modifier.size(16.dp))
                    },
                    colors = AssistChipDefaults.assistChipColors(containerColor = HologramPanel, labelColor = JarvisCyan)
                )
            }

            // Voice command reference / unclear repeat prompt
            voiceHintBanner?.let { banner ->
                Text(
                    text = banner,
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberPulse,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            // Ambiguous App Launch Clarification Bar
            AnimatedVisibility(visible = pendingApps.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pendingApps.forEach { app ->
                        Button(
                            onClick = { viewModel.launchClarifiedApp(app) },
                            colors = ButtonDefaults.buttonColors(containerColor = HologramCardElevated)
                        ) {
                            Text("Open ${app.label}", color = JarvisCyan)
                        }
                    }
                }
            }

            // Live Speech Recognition Indicator
            when (val s = speechState) {
                is SpeechListenState.Listening -> {
                    Text(
                        text = "Listening for voice command (\"Hey JARVIS\", \"Hey ROSE\", \"Hey JARVIS and ROSE\", \"Stop both\")...",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonMint,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                is SpeechListenState.Partial -> {
                    Text(
                        text = "Hearing: \"${s.text}\"",
                        style = MaterialTheme.typography.labelMedium,
                        color = JarvisCyan,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                is SpeechListenState.Error -> {
                    if (!continuousListening) {
                        Text(
                            text = s.message,
                            style = MaterialTheme.typography.labelMedium,
                            color = AmberPulse,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }
                SpeechListenState.Idle -> Unit
            }

            // Conversation Transcript (or clean home standby guide when empty & inactive)
            if (messages.isEmpty() && assistantMode == AssistantMode.INACTIVE) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(HologramPanel)
                            .border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Text("Voice-Only Assistant Activation", style = MaterialTheme.typography.titleMedium, color = JarvisCyan)
                        Text(
                            "Tap the microphone and speak a wake command:\n• \"Hey JARVIS\" — Activate JARVIS only\n• \"Hey ROSE\" — Activate ROSE only\n• \"Hey JARVIS and ROSE\" — Activate both\n• \"Hey JARVIS only\" / \"Hey ROSE only\" — Switch to one\n• \"Stop both\" — Return to standby",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageBubble(msg)
                    }
                    if (streamState is AssistantStreamState.Streaming) {
                        val st = streamState as AssistantStreamState.Streaming
                        item(key = "streaming_live") {
                            ChatMessageBubble(
                                ConversationMessageEntity(
                                    speaker = st.speaker.name,
                                    text = st.partialText + " ▌",
                                    mode = assistantMode.name,
                                    isOffline = false
                                )
                            )
                        }
                    }
                }
            }

            // Command Input & Voice Mic Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledIconButton(
                    onClick = {
                        if (isListening) {
                            viewModel.toggleContinuousVoiceStandby(false)
                            viewModel.speechManager.stopListening()
                        } else {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                viewModel.startVoiceListen()
                            } else {
                                pendingContinuousToggle = false
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isListening) NeonMint else HologramCardElevated,
                        contentColor = if (isListening) DeepVoidNavy else JarvisCyan
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop listening" else "Speak voice command"
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    enabled = assistantMode != AssistantMode.INACTIVE,
                    placeholder = {
                        Text(
                            if (assistantMode == AssistantMode.INACTIVE) {
                                "Speak \"Hey JARVIS\" or \"Hey ROSE\" to activate..."
                            } else {
                                "Message ${assistantMode.displayName}..."
                            },
                            color = MistBlue.copy(alpha = 0.7f)
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendTypedInput(inputText)
                                inputText = ""
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisCyan,
                        unfocusedBorderColor = OutlineCyan,
                        focusedContainerColor = HologramPanel,
                        unfocusedContainerColor = HologramPanel,
                        disabledContainerColor = HologramPanel.copy(alpha = 0.6f),
                        disabledBorderColor = OutlineCyan.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("assistant_text_input")
                )

                if (speakingChar != null) {
                    FilledIconButton(
                        onClick = { viewModel.stopAllVoiceAndAi() },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = CrimsonAlert,
                            contentColor = IceWhite
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("stop_tts_button")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop speaking")
                    }
                } else {
                    FilledIconButton(
                        enabled = assistantMode != AssistantMode.INACTIVE && inputText.isNotBlank(),
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendTypedInput(inputText)
                                inputText = ""
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = JarvisCyan,
                            contentColor = DeepVoidNavy
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("send_message_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message")
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(msg: ConversationMessageEntity) {
    val speaker = runCatching { Speaker.valueOf(msg.speaker) }.getOrDefault(Speaker.JARVIS)
    val isUser = speaker == Speaker.USER
    val accent = when (speaker) {
        Speaker.JARVIS -> JarvisCyan
        Speaker.ROSE -> RoseAzure
        Speaker.SYSTEM -> AmberPulse
        Speaker.USER -> NeonMint
    }
    val timeText = remember(msg.timestampMillis) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestampMillis))
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (isUser) HologramCardElevated else HologramPanel)
                .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Text(
                    text = speaker.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = accent
                )
                if (msg.isOffline) {
                    Text(
                        text = "OFFLINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberPulse
                    )
                }
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MistBlue
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyMedium,
                color = IceWhite
            )
        }
    }
}
