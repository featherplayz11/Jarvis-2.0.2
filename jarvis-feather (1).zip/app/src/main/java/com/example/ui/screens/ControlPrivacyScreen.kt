package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.system.FloatingHologramService
import com.example.system.JarvisAccessibilityService
import com.example.ui.JarvisViewModel
import com.example.ui.theme.AmberPulse
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramCardElevated
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.OutlineCyan
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import com.example.voice.WakeWordForegroundService
import kotlinx.coroutines.launch

@Composable
fun ControlPrivacyScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val prefs by viewModel.prefs.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val wakeRunning by viewModel.wakeServiceRunning.collectAsStateWithLifecycle()
    val overlayRunning by viewModel.overlayRunning.collectAsStateWithLifecycle()
    val accessibilityEnabled by viewModel.accessibilityEnabled.collectAsStateWithLifecycle()
    val cameraAnalysis by viewModel.cameraAnalysisResult.collectAsStateWithLifecycle()
    val isAnalyzingCamera by viewModel.isAnalyzingCamera.collectAsStateWithLifecycle()

    var cameraActive by remember { mutableStateOf(false) }
    var cameraPrompt by remember { mutableStateOf("What am I looking at and how can you help?") }
    var imageCaptureRef by remember { mutableStateOf<ImageCapture?>(null) }
    var appFilterQuery by remember { mutableStateOf("") }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        cameraActive = granted
        if (!granted) {
            Toast.makeText(context, "Camera permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    val wakePermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micOk = results[Manifest.permission.RECORD_AUDIO] == true
        if (micOk) {
            WakeWordForegroundService.start(context)
            scope.launch { viewModel.prefsRepo.setBackgroundWakeWord(true) }
        } else {
            Toast.makeText(context, "Microphone permission is needed for Wake Word standby.", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(Unit) {
        onDispose { cameraActive = false }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepVoidNavy, SpaceSlate, DeepVoidNavy)))
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 720.dp).fillMaxSize(),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("DEVICE CONTROL & PRIVACY", style = MaterialTheme.typography.titleLarge, color = JarvisCyan)
            }

            // 1. Camera Visual Assistant (explicit start/stop + visible indicator)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (cameraActive) NeonMint else OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.CameraAlt, null, tint = if (cameraActive) NeonMint else JarvisCyan)
                                Text("Camera Visual Assistant", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            }
                            if (cameraActive) {
                                Text("CAMERA ACTIVE", style = MaterialTheme.typography.labelSmall, color = NeonMint)
                            }
                        }
                        Text(
                            "Camera activates only on your explicit tap and stops immediately on Stop. No background recording or secret uploads.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )

                        AnimatedVisibility(visible = cameraActive) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(210.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                ) {
                                    AndroidView(
                                        factory = { ctx ->
                                            val previewView = PreviewView(ctx)
                                            val providerFuture = ProcessCameraProvider.getInstance(ctx)
                                            providerFuture.addListener({
                                                val provider = providerFuture.get()
                                                val preview = Preview.Builder().build().also {
                                                    it.surfaceProvider = previewView.surfaceProvider
                                                }
                                                val capture = ImageCapture.Builder()
                                                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                                    .build()
                                                imageCaptureRef = capture
                                                runCatching {
                                                    provider.unbindAll()
                                                    provider.bindToLifecycle(
                                                        lifecycleOwner,
                                                        CameraSelector.DEFAULT_BACK_CAMERA,
                                                        preview,
                                                        capture
                                                    )
                                                }
                                            }, ContextCompat.getMainExecutor(ctx))
                                            previewView
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                OutlinedTextField(
                                    value = cameraPrompt,
                                    onValueChange = { cameraPrompt = it },
                                    label = { Text("Ask JARVIS / ROSE about this view") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        enabled = !isAnalyzingCamera,
                                        onClick = {
                                            val capture = imageCaptureRef ?: return@Button
                                            capture.takePicture(
                                                ContextCompat.getMainExecutor(context),
                                                object : ImageCapture.OnImageCapturedCallback() {
                                                    override fun onCaptureSuccess(image: ImageProxy) {
                                                        val bmp = imageProxyToSmallBitmap(image)
                                                        image.close()
                                                        if (bmp != null) {
                                                            viewModel.analyzeCameraBitmap(bmp, cameraPrompt)
                                                        }
                                                    }

                                                    override fun onError(exception: ImageCaptureException) {
                                                        Toast.makeText(context, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            )
                                        },
                                        modifier = Modifier.weight(1f).testTag("capture_analyze_button")
                                    ) {
                                        if (isAnalyzingCamera) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        } else {
                                            Text("Capture & Analyze")
                                        }
                                    }
                                    Button(
                                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                                        onClick = { cameraActive = false },
                                        modifier = Modifier.testTag("stop_camera_button")
                                    ) {
                                        Icon(Icons.Default.Stop, null)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Stop")
                                    }
                                }
                            }
                        }

                        if (!cameraActive) {
                            Button(
                                onClick = {
                                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                                        PackageManager.PERMISSION_GRANTED
                                    if (granted) cameraActive = true
                                    else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                },
                                modifier = Modifier.testTag("start_camera_button")
                            ) {
                                Text("Activate Camera Assistant")
                            }
                        }

                        cameraAnalysis?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = JarvisCyan)
                        }
                    }
                }
            }

            // 2. Floating Hologram Overlay & Background Wake Word Service
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Layers, null, tint = RoseAzure)
                            Text("Floating Hologram Overlay", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "Moveable character bubble with switch, minimize, quick mic & close button. Respects secure apps that disallow overlays.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!FloatingHologramService.canDrawOverlays(context)) {
                                OutlinedButton(onClick = { viewModel.phoneControl.openOverlayPermissionSettings() }) {
                                    Text("Grant Overlay Permission")
                                }
                            } else {
                                Button(
                                    onClick = {
                                        if (overlayRunning) FloatingHologramService.stop(context)
                                        else FloatingHologramService.start(context)
                                    },
                                    modifier = Modifier.testTag("toggle_overlay_button")
                                ) {
                                    Text(if (overlayRunning) "Stop Floating Overlay" else "Start Floating Overlay")
                                }
                            }
                        }

                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Mic, null, tint = JarvisCyan)
                            Text("Background Voice Wake Standby", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "Uses an explicit microphone permission + supported Foreground Service with a persistent notification and Stop Listening action. Android restricts silent background microphone access and Force Stop halts all wake-word detection.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (wakeRunning) {
                                        WakeWordForegroundService.stop(context)
                                        scope.launch { viewModel.prefsRepo.setBackgroundWakeWord(false) }
                                    } else {
                                        val perms = buildList {
                                            add(Manifest.permission.RECORD_AUDIO)
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                add(Manifest.permission.POST_NOTIFICATIONS)
                                            }
                                        }.toTypedArray()
                                        wakePermLauncher.launch(perms)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (wakeRunning) CrimsonAlert else JarvisCyan
                                ),
                                modifier = Modifier.testTag("toggle_wake_service_button")
                            ) {
                                Text(
                                    if (wakeRunning) "Stop Listening Service" else "Start Wake Standby",
                                    color = if (wakeRunning) IceWhite else DeepVoidNavy
                                )
                            }
                            OutlinedButton(onClick = { viewModel.phoneControl.openSystemScreen("battery") }) {
                                Text("Battery Settings")
                            }
                        }
                    }
                }
            }

            // 3. Optional Accessibility Screen Control
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AccessibilityNew, null, tint = JarvisCyan)
                                Text("Optional Screen Control", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            }
                            Text(
                                if (accessibilityEnabled) "ENABLED" else "OFF",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (accessibilityEnabled) NeonMint else AmberPulse
                            )
                        }
                        Text(
                            "Strictly optional. Supports Back, Scroll, Tap & non-password text entry only. Never interacts with password fields, payments, or anti-cheat screens.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { viewModel.phoneControl.openAccessibilitySettings() }) {
                                Text("Accessibility Settings")
                            }
                            if (accessibilityEnabled) {
                                OutlinedButton(onClick = { JarvisAccessibilityService.getInstance()?.performScroll(true) }) {
                                    Text("Test Scroll")
                                }
                                Button(
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                                    onClick = { JarvisAccessibilityService.emergencyStop() }
                                ) {
                                    Text("STOP")
                                }
                            }
                        }
                    }
                }
            }

            // 4. Approved App Access & App Launcher
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Apps, null, tint = JarvisCyan)
                                Text("Approved App Access (${installedApps.size})", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            }
                            Switch(
                                checked = prefs.restrictToApprovedApps,
                                onCheckedChange = { checked ->
                                    scope.launch { viewModel.prefsRepo.setRestrictToApprovedApps(checked) }
                                }
                            )
                        }
                        Text(
                            if (prefs.restrictToApprovedApps) "Strict mode ON: Assistant can only launch toggled-on apps below."
                            else "Open mode: Toggle apps below if you enable strict allowlist.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        OutlinedTextField(
                            value = appFilterQuery,
                            onValueChange = { appFilterQuery = it },
                            label = { Text("Filter installed apps") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        val filtered = installedApps.filter {
                            appFilterQuery.isBlank() || it.label.contains(appFilterQuery, ignoreCase = true)
                        }.take(12)

                        filtered.forEach { app ->
                            val isApproved = app.packageName in prefs.approvedAppPackages
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(HologramCardElevated)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.label, style = MaterialTheme.typography.bodyMedium, color = IceWhite)
                                    Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MistBlue)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(onClick = {
                                        viewModel.phoneControl.launchPackage(app.packageName, prefs.restrictToApprovedApps, prefs.approvedAppPackages)
                                    }) {
                                        Text("Open")
                                    }
                                    Switch(
                                        checked = isApproved,
                                        onCheckedChange = {
                                            scope.launch { viewModel.prefsRepo.toggleApprovedApp(app.packageName) }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. Permission Transparency Notice
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.PrivacyTip, null, tint = NeonMint)
                            Text("Permission & Privacy Pledge", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text("• Microphone: Only active when you tap Speak or start the visible Voice Standby notification.", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                        Text("• Camera: Only active inside Camera Assistant when explicitly turned on; never records silently.", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                        Text("• Media & Storage: Uses zero-permission Android Photo Picker & SAF (no broad storage scan).", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                        Text("• Accessibility & Overlay: Strictly optional, visibly indicated, and immediately stoppable.", style = MaterialTheme.typography.bodySmall, color = MistBlue)
                    }
                }
            }
        }
    }
}

private fun imageProxyToSmallBitmap(image: ImageProxy): Bitmap? {
    return runCatching {
        val bitmap = image.toBitmap()
        val matrix = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        val maxDim = 640f
        val scale = minOf(maxDim / rotated.width, maxDim / rotated.height, 1f)
        if (scale < 1f) {
            Bitmap.createScaledBitmap(
                rotated,
                (rotated.width * scale).toInt().coerceAtLeast(64),
                (rotated.height * scale).toInt().coerceAtLeast(64),
                true
            ).also { rotated.recycle() }
        } else rotated
    }.getOrNull()
}
