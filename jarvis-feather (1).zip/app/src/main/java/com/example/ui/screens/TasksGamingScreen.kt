package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.OfflineAssistantEngine
import com.example.data.local.ReminderEntity
import com.example.data.model.GameCategory
import com.example.ui.JarvisViewModel
import com.example.ui.theme.AmberPulse
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramCardElevated
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.OutlineCyan
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun TasksGamingScreen(
    viewModel: JarvisViewModel,
    onNavigateToAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Reminders", "Gaming Hub", "Mini-Quiz")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepVoidNavy, SpaceSlate, DeepVoidNavy)))
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 720.dp).fillMaxSize()) {
            Text(
                text = "TASKS, GAMING & ENTERTAINMENT",
                style = MaterialTheme.typography.titleLarge,
                color = JarvisCyan,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            )

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = HologramPanel,
                contentColor = JarvisCyan
            ) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                    )
                }
            }

            when (selectedTab) {
                0 -> RemindersSection(viewModel)
                1 -> GamingSection(viewModel, onNavigateToAssistant)
                2 -> EntertainmentQuizSection(viewModel)
            }
        }
    }
}

@Composable
private fun RemindersSection(viewModel: JarvisViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var editingReminder by remember { mutableStateOf<ReminderEntity?>(null) }
    var deleteConfirmReminder by remember { mutableStateOf<ReminderEntity?>(null) }
    var feedbackBanner by remember { mutableStateOf<String?>(null) }

    val pendingCount = reminders.count { !it.isCompleted }

    LazyColumn(
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        editingReminder = null
                        showCreateDialog = true
                    },
                    modifier = Modifier.weight(1f).testTag("new_reminder_button")
                ) {
                    Icon(Icons.Default.AddAlert, null)
                    Spacer(Modifier.width(6.dp))
                    Text("New Reminder ($pendingCount)")
                }
                OutlinedButton(
                    onClick = {
                        viewModel.sendDailyReminderSummary()
                        feedbackBanner = "Daily reminder summary notification sent."
                    },
                    modifier = Modifier.testTag("daily_summary_button")
                ) {
                    Icon(Icons.Default.NotificationsActive, null, tint = RoseAzure)
                    Spacer(Modifier.width(4.dp))
                    Text("Daily Brief")
                }
            }
            feedbackBanner?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.labelMedium, color = NeonMint)
            }
        }

        if (reminders.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Schedule, null, tint = JarvisCyan)
                        Spacer(Modifier.height(8.dp))
                        Text("No reminders scheduled yet.", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        Text(
                            "Tap New Reminder or say \"Remind me to stretch in 20 minutes\" in the Assistant tab.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                    }
                }
            }
        } else {
            items(reminders, key = { it.id }) { rem ->
                val dateStr = SimpleDateFormat("EEE, MMM d • hh:mm a", Locale.getDefault()).format(Date(rem.dueAtMillis))
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (rem.isCompleted) NeonMint.copy(alpha = 0.35f) else OutlineCyan, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.toggleReminderComplete(rem) }) {
                            Icon(
                                imageVector = if (rem.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Toggle completion",
                                tint = if (rem.isCompleted) NeonMint else JarvisCyan
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = rem.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (rem.isCompleted) MistBlue else IceWhite
                            )
                            Text(
                                text = "$dateStr • ${rem.characterTag}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (rem.isCompleted) MistBlue else RoseAzure
                            )
                            if (rem.notes.isNotBlank()) {
                                Text(rem.notes, style = MaterialTheme.typography.bodySmall, color = MistBlue)
                            }
                        }
                        IconButton(onClick = {
                            editingReminder = rem
                            showCreateDialog = true
                        }) {
                            Icon(Icons.Default.Edit, "Edit or reschedule", tint = MistBlue)
                        }
                        IconButton(onClick = { deleteConfirmReminder = rem }) {
                            Icon(Icons.Default.Delete, "Delete reminder", tint = CrimsonAlert)
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var title by remember { mutableStateOf(editingReminder?.title ?: "") }
        var notes by remember { mutableStateOf(editingReminder?.notes ?: "") }
        var dueMillis by remember {
            mutableLongStateOf(editingReminder?.dueAtMillis ?: (System.currentTimeMillis() + 30 * 60_000L))
        }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = HologramCardElevated,
            title = { Text(if (editingReminder == null) "Create Reminder" else "Edit / Reschedule") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Reminder Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Scheduled: ${SimpleDateFormat("MMM d, hh:mm a", Locale.getDefault()).format(Date(dueMillis))}",
                        style = MaterialTheme.typography.labelMedium,
                        color = JarvisCyan
                    )
                    OutlinedButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = dueMillis }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                cal.set(Calendar.YEAR, y)
                                cal.set(Calendar.MONTH, m)
                                cal.set(Calendar.DAY_OF_MONTH, d)
                                TimePickerDialog(
                                    context,
                                    { _, h, min ->
                                        cal.set(Calendar.HOUR_OF_DAY, h)
                                        cal.set(Calendar.MINUTE, min)
                                        dueMillis = cal.timeInMillis
                                    },
                                    cal.get(Calendar.HOUR_OF_DAY),
                                    cal.get(Calendar.MINUTE),
                                    false
                                ).show()
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }) {
                        Text("Pick Date & Time")
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = title.isNotBlank(),
                    onClick = {
                        val target = editingReminder
                        scope.launch {
                            if (target == null) {
                                val saved = viewModel.addReminder(title, notes, dueMillis, "JARVIS")
                                feedbackBanner = if (saved) "Reminder verified and saved!" else "Save failed."
                            } else {
                                viewModel.updateReminder(target.copy(title = title, notes = notes, dueAtMillis = dueMillis))
                                feedbackBanner = "Reminder updated & rescheduled."
                            }
                            showCreateDialog = false
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    deleteConfirmReminder?.let { rem ->
        AlertDialog(
            onDismissRequest = { deleteConfirmReminder = null },
            containerColor = HologramCardElevated,
            title = { Text("Delete Reminder?") },
            text = { Text("Confirm removing \"${rem.title}\"? This cancels its notification.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                    onClick = {
                        viewModel.deleteReminderConfirmed(rem)
                        deleteConfirmReminder = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmReminder = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun GamingSection(
    viewModel: JarvisViewModel,
    onNavigateToAssistant: () -> Unit
) {
    var statusText by remember { mutableStateOf<String?>(null) }
    var customQuery by remember { mutableStateOf("") }

    LazyColumn(
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            OutlinedTextField(
                value = customQuery,
                onValueChange = { customQuery = it },
                label = { Text("Custom gaming question (optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Note: Game launching works for installed packages; automated taps are strictly optional and never bypass anti-cheat or app security.",
                style = MaterialTheme.typography.bodySmall,
                color = MistBlue
            )
            statusText?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.labelMedium, color = AmberPulse)
            }
        }

        items(GameCategory.entries) { cat ->
            Card(
                colors = CardDefaults.cardColors(containerColor = HologramPanel),
                modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.SportsEsports, null, tint = JarvisCyan)
                        Column {
                            Text(cat.label, style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            Text(cat.subtitle, style = MaterialTheme.typography.bodySmall, color = MistBlue)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { statusText = viewModel.launchMatchingGame(cat) }) {
                            Text("Launch Game")
                        }
                        Button(onClick = {
                            viewModel.askGamingTip(cat, customQuery)
                            onNavigateToAssistant()
                        }) {
                            Text("Strategy & Settings")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EntertainmentQuizSection(viewModel: JarvisViewModel) {
    val quizzes = OfflineAssistantEngine.quizzes
    var qIndex by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }

    val (question, options, correctIdx) = quizzes[qIndex % quizzes.size]

    LazyColumn(
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = HologramPanel),
                modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Quiz, null, tint = RoseAzure)
                        Text("Offline & Online Trivia • Score: $score", style = MaterialTheme.typography.titleMedium, color = JarvisCyan)
                    }
                    Text(question, style = MaterialTheme.typography.bodyLarge, color = IceWhite)
                    options.forEachIndexed { idx, opt ->
                        val isChosen = selectedAnswer == idx
                        val btnColor = when {
                            selectedAnswer == -1 -> HologramCardElevated
                            idx == correctIdx -> NeonMint.copy(alpha = 0.25f)
                            isChosen -> CrimsonAlert.copy(alpha = 0.25f)
                            else -> HologramCardElevated
                        }
                        OutlinedButton(
                            onClick = {
                                if (selectedAnswer == -1) {
                                    selectedAnswer = idx
                                    if (idx == correctIdx) score++
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = btnColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(opt, color = IceWhite)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            selectedAnswer = -1
                            qIndex++
                        }) {
                            Text("Next Question")
                        }
                        OutlinedButton(onClick = { viewModel.sendTypedInput("Suggest a fun creative 10-minute offline activity") }) {
                            Text("Creative Idea")
                        }
                    }
                }
            }
        }
    }
}
