package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = DeepVoidNavy,
    primaryContainer = HologramCardElevated,
    onPrimaryContainer = IceWhite,
    secondary = RoseAzure,
    onSecondary = DeepVoidNavy,
    secondaryContainer = HologramPanel,
    onSecondaryContainer = IceWhite,
    tertiary = DualVioletCyan,
    onTertiary = DeepVoidNavy,
    background = DeepVoidNavy,
    onBackground = IceWhite,
    surface = SpaceSlate,
    onSurface = IceWhite,
    surfaceVariant = HologramPanel,
    onSurfaceVariant = MistBlue,
    outline = OutlineCyan,
    outlineVariant = DimSteel,
    error = CrimsonAlert,
    onError = IceWhite
)

private val JarvisShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun JarvisFeatherTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = JarvisTypography,
        shapes = JarvisShapes,
        content = content
    )
}
