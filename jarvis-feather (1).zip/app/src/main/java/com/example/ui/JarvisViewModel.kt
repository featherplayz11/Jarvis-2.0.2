package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.view.KeyEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiModelRegistry
import com.example.ai.AiResponseChunk
import com.example.ai.FirebaseJarvisAiProvider
import com.example.ai.LocalCommandAction
import com.example.ai.ModelAvailabilityResult
import com.example.ai.OfflineAssistantEngine
import com.example.ai.VoiceWakeResult
import com.example.core.DeviceCapabilities
import com.example.core.DeviceHealthSnapshot
import com.example.data.local.AppDatabase
import com.example.data.local.ConfigSnapshotEntity
import com.example.data.local.ConversationMessageEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.ReminderEntity
import com.example.data.local.SkillModuleEntity
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.UserPreferencesState
import com.example.data.model.AiModelSpec
import com.example.data.model.AssistantMode
import com.example.data.model.GameCategory
import com.example.data.model.GraphicsQuality
import com.example.data.model.Speaker
import com.example.system.AppLaunchResult
import com.example.system.FloatingHologramService
import com.example.system.InstalledAppInfo
import com.example.system.JarvisAccessibilityService
import com.example.system.PhoneControlManager
import com.example.system.ReminderScheduler
import com.example.system.SafeUpdateManager
import com.example.system.UpdateStatus
import com.example.voice.SpeechInputManager
import com.example.voice.SpeechListenState
import com.example.voice.VoiceTtsManager
import com.example.voice.WakeWordForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject

sealed interface AssistantStreamState {
    data object Idle : AssistantStreamState
    data class Streaming(val speaker: Speaker, val partialText: String) : AssistantStreamState
    data class Error(val message: String) : AssistantStreamState
}

object AssistantActivationBus {
    private val _mode = MutableStateFlow(AssistantMode.INACTIVE)
    val mode: StateFlow<AssistantMode> = _mode.asStateFlow()

    fun update(newMode: AssistantMode) {
        _mode.value = newMode
    }
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val reminderDao = db.reminderDao()
    private val memoryDao = db.memoryDao()
    private val conversationDao = db.conversationDao()
    private val skillDao = db.skillModuleDao()
    private val snapshotDao = db.configSnapshotDao()

    val prefsRepo = UserPreferencesRepository(application)
    val aiProvider = FirebaseJarvisAiProvider(application)
    val ttsManager = VoiceTtsManager(application)
    val speechManager = SpeechInputManager(application)
    val phoneControl = PhoneControlManager(application)
    val updateManager = SafeUpdateManager(application)

    val prefs: StateFlow<UserPreferencesState> = prefsRepo.preferencesFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserPreferencesState()
    )

    // Strict voice-only session state: ALWAYS starts INACTIVE on app launch
    private val _assistantMode = MutableStateFlow(AssistantMode.INACTIVE)
    val assistantMode: StateFlow<AssistantMode> = _assistantMode.asStateFlow()

    val messages: StateFlow<List<ConversationMessageEntity>> = conversationDao.observeRecent().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val reminders: StateFlow<List<ReminderEntity>> = reminderDao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val memories: StateFlow<List<MemoryEntryEntity>> = memoryDao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val skillModules: StateFlow<List<SkillModuleEntity>> = skillDao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val configSnapshots: StateFlow<List<ConfigSnapshotEntity>> = snapshotDao.observeSnapshots().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val speakingCharacter: StateFlow<Speaker?> = ttsManager.speakingCharacter
    val lipAmplitude: StateFlow<Float> = ttsManager.lipAmplitude
    val speechState: StateFlow<SpeechListenState> = speechManager.state
    val wakeServiceRunning: StateFlow<Boolean> = WakeWordForegroundService.isRunning
    val overlayRunning: StateFlow<Boolean> = FloatingHologramService.isRunning
    val accessibilityEnabled: StateFlow<Boolean> = JarvisAccessibilityService.isServiceEnabled
    val accessibilityBanner: StateFlow<String?> = JarvisAccessibilityService.activeControlBanner
    val updateStatus: StateFlow<UpdateStatus> = updateManager.status

    private val _streamState = MutableStateFlow<AssistantStreamState>(AssistantStreamState.Idle)
    val streamState: StateFlow<AssistantStreamState> = _streamState.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _deviceHealth = MutableStateFlow(DeviceCapabilities.inspect(application))
    val deviceHealth: StateFlow<DeviceHealthSnapshot> = _deviceHealth.asStateFlow()

    private val _modelRegistry = MutableStateFlow(AiModelRegistry.verifiedModels)
    val modelRegistry: StateFlow<List<AiModelSpec>> = _modelRegistry.asStateFlow()

    private val _modelCheckResult = MutableStateFlow<ModelAvailabilityResult?>(null)
    val modelCheckResult: StateFlow<ModelAvailabilityResult?> = _modelCheckResult.asStateFlow()

    private val _isDualConversationActive = MutableStateFlow(false)
    val isDualConversationActive: StateFlow<Boolean> = _isDualConversationActive.asStateFlow()

    private val _isDualPaused = MutableStateFlow(false)
    val isDualPaused: StateFlow<Boolean> = _isDualPaused.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(true)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    private val _cameraAnalysisResult = MutableStateFlow<String?>(null)
    val cameraAnalysisResult: StateFlow<String?> = _cameraAnalysisResult.asStateFlow()

    private val _isAnalyzingCamera = MutableStateFlow(false)
    val isAnalyzingCamera: StateFlow<Boolean> = _isAnalyzingCamera.asStateFlow()

    private val _pendingAppClarification = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val pendingAppClarification: StateFlow<List<InstalledAppInfo>> = _pendingAppClarification.asStateFlow()

    private val _continuousListening = MutableStateFlow(false)
    val continuousListening: StateFlow<Boolean> = _continuousListening.asStateFlow()

    private val _voiceHintBanner = MutableStateFlow<String?>(null)
    val voiceHintBanner: StateFlow<String?> = _voiceHintBanner.asStateFlow()

    private var activeGenJob: Job? = null
    private var dualLoopJob: Job? = null
    private var continuousLoopJob: Job? = null
    private var navigateToEditorCallback: (() -> Unit)? = null

    init {
        // Ensure cold start is strictly INACTIVE with neither face shown
        AssistantActivationBus.update(AssistantMode.INACTIVE)
        viewModelScope.launch {
            seedBuiltInSkillsIfEmpty()
            refreshInstalledApps()
            val initialPrefs = prefsRepo.preferencesFlow.first()
            if (initialPrefs.appLockEnabled) {
                _isAppUnlocked.value = false
            }
        }
    }

    fun attachEditorNavigator(callback: () -> Unit) {
        navigateToEditorCallback = callback
    }

    fun refreshDeviceHealth() {
        _deviceHealth.value = DeviceCapabilities.inspect(getApplication())
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = phoneControl.listLaunchableApps()
        }
    }

    fun unlockApp() {
        _isAppUnlocked.value = true
    }

    fun lockAppNow() {
        _isAppUnlocked.value = false
    }

    fun verifyPinAndUnlock(pin: String): Boolean {
        val ok = prefsRepo.verifyPin(pin, prefs.value.pinHash)
        if (ok) _isAppUnlocked.value = true
        return ok
    }

    fun verifyRecoveryAndResetLock(code: String): Boolean {
        val ok = prefsRepo.verifyRecoveryCode(code, prefs.value.recoveryCodeHash)
        if (ok) {
            _isAppUnlocked.value = true
            viewModelScope.launch {
                prefsRepo.setSecurityConfig(
                    appLockEnabled = false,
                    biometricEnabled = prefs.value.biometricEnabled,
                    pinRaw = null,
                    recoveryCodeRaw = null
                )
            }
        }
        return ok
    }

    private fun setActiveVoiceMode(mode: AssistantMode) {
        _assistantMode.value = mode
        AssistantActivationBus.update(mode)
    }

    fun startVoiceListen() {
        _voiceHintBanner.value = null
        ttsManager.stop()
        speechManager.startListening { transcript ->
            processVoiceTranscript(transcript)
        }
    }

    fun toggleContinuousVoiceStandby(enable: Boolean) {
        _continuousListening.value = enable
        continuousLoopJob?.cancel()
        if (!enable) {
            speechManager.stopListening()
            _voiceHintBanner.value = "Voice standby paused."
            return
        }
        _voiceHintBanner.value = "Voice standby listening for wake command..."
        continuousLoopJob = viewModelScope.launch {
            while (_continuousListening.value) {
                val st = speechState.value
                if (st is SpeechListenState.Idle || st is SpeechListenState.Error) {
                    if (speakingCharacter.value == null && activeGenJob?.isActive != true) {
                        speechManager.startListening { transcript ->
                            processVoiceTranscript(transcript)
                        }
                    }
                }
                delay(if (prefs.value.batterySaverMode) 2200L else 1200L)
            }
        }
    }

    fun stopAllVoiceAndAi() {
        activeGenJob?.cancel()
        dualLoopJob?.cancel()
        _isDualConversationActive.value = false
        _isDualPaused.value = false
        _continuousListening.value = false
        continuousLoopJob?.cancel()
        speechManager.stopListening()
        ttsManager.stop()
        JarvisAccessibilityService.emergencyStop()
        _streamState.value = AssistantStreamState.Idle
    }

    /**
     * ONLY entry point allowed to activate or switch JARVIS / ROSE / Dual Mode.
     */
    fun processVoiceTranscript(transcript: String) {
        val currentMode = _assistantMode.value
        val currentPrefs = prefs.value
        val addressName = if (currentPrefs.groupModeEnabled) currentPrefs.groupTitle else currentPrefs.privateName

        val wakeResult = OfflineAssistantEngine.parseVoiceWakeCommand(
            rawTranscript = transcript,
            currentMode = currentMode,
            preferredAddress = addressName
        )

        if (wakeResult != null) {
            when (wakeResult) {
                is VoiceWakeResult.StopBoth -> {
                    activeGenJob?.cancel()
                    dualLoopJob?.cancel()
                    _isDualConversationActive.value = false
                    _isDualPaused.value = false
                    ttsManager.stop()
                    setActiveVoiceMode(AssistantMode.INACTIVE)
                    _voiceHintBanner.value = "Both assistants deactivated. Standing by."
                    viewModelScope.launch {
                        appendMessage(Speaker.USER, transcript, AssistantMode.INACTIVE, isOffline = true)
                        appendMessage(Speaker.SYSTEM, "Both assistants deactivated. Say \"Hey JARVIS\", \"Hey ROSE\", or \"Hey JARVIS and ROSE\" to activate.", AssistantMode.INACTIVE, isOffline = true)
                    }
                }
                is VoiceWakeResult.Activate -> {
                    activeGenJob?.cancel()
                    dualLoopJob?.cancel()
                    _isDualConversationActive.value = false
                    _isDualPaused.value = false
                    ttsManager.stop()

                    setActiveVoiceMode(wakeResult.mode)
                    _voiceHintBanner.value = null
                    viewModelScope.launch {
                        appendMessage(Speaker.USER, transcript, wakeResult.mode, isOffline = false)
                        val sp = when (wakeResult.mode) {
                            AssistantMode.ROSE_ONLY -> Speaker.ROSE
                            AssistantMode.JARVIS_ONLY -> Speaker.JARVIS
                            AssistantMode.DUAL_MODE -> Speaker.JARVIS
                            AssistantMode.INACTIVE -> Speaker.SYSTEM
                        }
                        if (wakeResult.trailingCommand != null) {
                            handleActiveAssistantQuery(wakeResult.trailingCommand, wakeResult.mode, currentPrefs)
                        } else {
                            appendMessage(sp, wakeResult.spokenConfirmation, wakeResult.mode, isOffline = true)
                            speakIfEnabled(sp, wakeResult.spokenConfirmation, currentPrefs)
                            if (wakeResult.mode == AssistantMode.DUAL_MODE) {
                                val roseLine = "Hello $addressName! ROSE is active too. Ask us anything or tell us a topic to discuss!"
                                appendMessage(Speaker.ROSE, roseLine, wakeResult.mode, isOffline = true)
                                speakIfEnabled(Speaker.ROSE, roseLine, currentPrefs, queueAdd = true)
                            }
                        }
                    }
                }
                is VoiceWakeResult.UnclearOrAccidental -> {
                    val promptMsg = if (currentMode == AssistantMode.INACTIVE) {
                        "Command unclear ($transcript). Both assistants stay inactive. Please repeat clearly: \"Hey JARVIS\", \"Hey ROSE\", or \"Hey JARVIS and ROSE\"."
                    } else {
                        "Command unclear. Please repeat clearly, or say \"Hey JARVIS only\", \"Hey ROSE only\", or \"Stop both\"."
                    }
                    _voiceHintBanner.value = promptMsg
                    viewModelScope.launch {
                        appendMessage(Speaker.SYSTEM, promptMsg, currentMode, isOffline = true)
                    }
                }
            }
            return
        }

        // Normal spoken command while an assistant is ALREADY active
        viewModelScope.launch {
            appendMessage(Speaker.USER, transcript, currentMode, isOffline = !DeviceCapabilities.isNetworkAvailable(getApplication()))
        }
        handleActiveAssistantQuery(transcript, currentMode, currentPrefs)
    }

    /**
     * Typed input NEVER activates or switches assistants.
     * It only works when an assistant has already been activated by voice.
     */
    fun sendTypedInput(rawText: String) {
        val input = rawText.trim()
        if (input.isEmpty()) return

        val currentMode = _assistantMode.value
        val currentPrefs = prefs.value

        if (currentMode == AssistantMode.INACTIVE) {
            val msg = "Voice activation required: No assistant is active. Tap the microphone and say \"Hey JARVIS\", \"Hey ROSE\", or \"Hey JARVIS and ROSE\"."
            _voiceHintBanner.value = msg
            viewModelScope.launch {
                appendMessage(Speaker.SYSTEM, msg, AssistantMode.INACTIVE, isOffline = true)
            }
            return
        }

        // Block typed wake-word switching so character control stays strictly voice-only
        val addressName = if (currentPrefs.groupModeEnabled) currentPrefs.groupTitle else currentPrefs.privateName
        if (OfflineAssistantEngine.parseVoiceWakeCommand(input, currentMode, addressName) != null) {
            val msg = "Character activation and switching are voice-only. Please speak \"Hey JARVIS\", \"Hey ROSE\", \"Hey JARVIS and ROSE\", or \"Stop both\"."
            _voiceHintBanner.value = msg
            viewModelScope.launch {
                appendMessage(Speaker.SYSTEM, msg, currentMode, isOffline = true)
            }
            return
        }

        viewModelScope.launch {
            appendMessage(Speaker.USER, input, currentMode, isOffline = !DeviceCapabilities.isNetworkAvailable(getApplication()))
        }
        handleActiveAssistantQuery(input, currentMode, currentPrefs)
    }

    private fun handleActiveAssistantQuery(
        input: String,
        activeMode: AssistantMode,
        currentPrefs: UserPreferencesState
    ) {
        if (activeMode == AssistantMode.INACTIVE) return

        val lower = input.lowercase()
        // Trigger dual discussion naturally when BOTH are active and user asks them to discuss/talk
        if (activeMode == AssistantMode.DUAL_MODE &&
            (lower.startsWith("discuss ") || lower.contains("talk to each other") || lower.contains("debate "))
        ) {
            val topic = input.replaceFirst(Regex("(?i)^(discuss|debate)\\s+"), "").trim()
            startDualConversation(topic)
            return
        }

        val localAction = OfflineAssistantEngine.parseCommandOrOfflineReply(input)
        if (localAction != null) {
            handleLocalCommandAction(localAction, activeMode, currentPrefs)
            return
        }

        val addressName = if (currentPrefs.groupModeEnabled) currentPrefs.groupTitle else currentPrefs.privateName
        val isOnline = currentPrefs.onlineModeEnabled && DeviceCapabilities.isNetworkAvailable(getApplication())
        if (!isOnline) {
            val (sp, reply) = OfflineAssistantEngine.buildOfflineResponse(input, activeMode, addressName)
            viewModelScope.launch {
                appendMessage(sp, reply, activeMode, isOffline = true)
                speakIfEnabled(sp, reply, currentPrefs)
            }
            return
        }

        val targetSpeaker = pickPrimarySpeaker(input, activeMode)
        streamOnlineResponse(targetSpeaker, input, activeMode, currentPrefs)
    }

    private fun handleLocalCommandAction(
        action: LocalCommandAction,
        activeMode: AssistantMode,
        currentPrefs: UserPreferencesState
    ) {
        val activeSpeaker = if (activeMode == AssistantMode.ROSE_ONLY) Speaker.ROSE else Speaker.JARVIS
        viewModelScope.launch {
            when (action) {
                is LocalCommandAction.StopSpeakingOrControl -> {
                    stopAllVoiceAndAi()
                    appendMessage(Speaker.SYSTEM, "Voice output and active controls stopped.", activeMode, isOffline = true)
                }
                is LocalCommandAction.OpenApp -> {
                    when (val res = phoneControl.launchAppByQuery(action.query, currentPrefs.restrictToApprovedApps, currentPrefs.approvedAppPackages)) {
                        is AppLaunchResult.Launched -> {
                            val msg = "Opening ${res.app.label}."
                            appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                            speakIfEnabled(activeSpeaker, msg, currentPrefs)
                        }
                        is AppLaunchResult.BlockedByAllowlist -> {
                            val msg = "${res.app.label} is not in your Approved App Access list."
                            appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                            speakIfEnabled(activeSpeaker, msg, currentPrefs)
                        }
                        is AppLaunchResult.Ambiguous -> {
                            _pendingAppClarification.value = res.candidates
                            val names = res.candidates.joinToString(", ") { it.label }
                            val msg = "Multiple apps match \"${action.query}\": $names. Tap the exact app below to launch."
                            appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                            speakIfEnabled(activeSpeaker, msg, currentPrefs)
                        }
                        is AppLaunchResult.NotFound -> {
                            val msg = "I couldn't find an installed app matching \"${res.query}\"."
                            appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                            speakIfEnabled(activeSpeaker, msg, currentPrefs)
                        }
                    }
                }
                is LocalCommandAction.OpenSystemScreen -> {
                    val status = phoneControl.openSystemScreen(action.target)
                    appendMessage(activeSpeaker, status, activeMode, isOffline = true)
                }
                is LocalCommandAction.CreateReminder -> {
                    val due = System.currentTimeMillis() + action.delayMinutes * 60_000L
                    val ok = addReminder(action.title, "Voice reminder", due, activeSpeaker.label)
                    val msg = if (ok) {
                        "Saved and scheduled reminder: \"${action.title}\" in ${action.delayMinutes} minutes."
                    } else {
                        "Failed to save reminder locally."
                    }
                    appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                    speakIfEnabled(activeSpeaker, msg, currentPrefs)
                }
                is LocalCommandAction.SearchWeb -> {
                    val ok = phoneControl.searchWeb(action.query)
                    val msg = if (ok) "Searching for \"${action.query}\" in your browser." else "Unable to open browser search."
                    appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
                }
                LocalCommandAction.MediaPlayPause -> {
                    phoneControl.dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                    appendMessage(activeSpeaker, "Toggled media playback.", activeMode, isOffline = true)
                }
                LocalCommandAction.MediaNext -> {
                    phoneControl.dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
                    appendMessage(activeSpeaker, "Skipped to next track.", activeMode, isOffline = true)
                }
                LocalCommandAction.GoHome -> {
                    val acc = JarvisAccessibilityService.getInstance()
                    if (acc != null) acc.performHomeAction() else phoneControl.goHome()
                    appendMessage(activeSpeaker, "Navigated to Home screen.", activeMode, isOffline = true)
                }
                LocalCommandAction.NavigateBack -> {
                    val acc = JarvisAccessibilityService.getInstance()
                    if (acc != null) {
                        acc.performBackAction()
                        appendMessage(activeSpeaker, "Performed Back navigation.", activeMode, isOffline = true)
                    } else {
                        appendMessage(activeSpeaker, "Global Back requires optional Accessibility Screen Control to be enabled in Control.", activeMode, isOffline = true)
                    }
                }
                LocalCommandAction.OpenVideoEditor -> {
                    navigateToEditorCallback?.invoke()
                }
                is LocalCommandAction.ReplyOnly -> {
                    appendMessage(action.speaker, action.text, activeMode, isOffline = true)
                    speakIfEnabled(action.speaker, action.text, currentPrefs)
                }
            }
        }
    }

    fun launchClarifiedApp(app: InstalledAppInfo) {
        _pendingAppClarification.value = emptyList()
        val p = prefs.value
        val activeMode = _assistantMode.value
        val activeSpeaker = if (activeMode == AssistantMode.ROSE_ONLY) Speaker.ROSE else Speaker.JARVIS
        val res = phoneControl.launchPackage(app.packageName, p.restrictToApprovedApps, p.approvedAppPackages)
        viewModelScope.launch {
            val msg = when (res) {
                is AppLaunchResult.Launched -> "Launched ${res.app.label}."
                is AppLaunchResult.BlockedByAllowlist -> "${res.app.label} is blocked by Approved App Access."
                else -> "Could not launch ${app.label}."
            }
            appendMessage(activeSpeaker, msg, activeMode, isOffline = true)
        }
    }

    private fun pickPrimarySpeaker(input: String, mode: AssistantMode): Speaker {
        return when (mode) {
            AssistantMode.JARVIS_ONLY -> Speaker.JARVIS
            AssistantMode.ROSE_ONLY -> Speaker.ROSE
            AssistantMode.DUAL_MODE -> {
                val lower = input.lowercase()
                if (lower.contains("rose") || lower.contains("joke") || lower.contains("bored") || lower.contains("lonely") || lower.contains("cheer")) {
                    Speaker.ROSE
                } else {
                    Speaker.JARVIS
                }
            }
            AssistantMode.INACTIVE -> Speaker.SYSTEM
        }
    }

    private fun streamOnlineResponse(
        speaker: Speaker,
        prompt: String,
        activeMode: AssistantMode,
        currentPrefs: UserPreferencesState
    ) {
        activeGenJob?.cancel()
        activeGenJob = viewModelScope.launch {
            val approvedMemories = memoryDao.getApprovedOnce()
            val enabledSkills = skillDao.getEnabledOnce()
            val history = messages.value.takeLast(8).map {
                val sp = runCatching { Speaker.valueOf(it.speaker) }.getOrDefault(Speaker.USER)
                sp to it.text
            }

            aiProvider.streamReply(
                speaker = speaker,
                userPrompt = prompt,
                historyContext = history,
                prefs = currentPrefs,
                memories = approvedMemories,
                skills = enabledSkills
            ).collect { chunk ->
                when (chunk) {
                    is AiResponseChunk.Delta -> {
                        _streamState.value = AssistantStreamState.Streaming(speaker, chunk.accumulatedText)
                    }
                    is AiResponseChunk.Completed -> {
                        _streamState.value = AssistantStreamState.Idle
                        appendMessage(speaker, chunk.finalText, activeMode, isOffline = false)
                        speakIfEnabled(speaker, chunk.finalText, currentPrefs)
                    }
                    is AiResponseChunk.Error -> {
                        _streamState.value = AssistantStreamState.Error(chunk.message)
                        appendMessage(Speaker.SYSTEM, "AI Error: ${chunk.message}", activeMode, isOffline = chunk.isOfflineOrUnavailable)
                    }
                }
            }
        }
    }

    // Dual Conversation runs ONLY when Dual Mode has been activated by voice
    fun startDualConversation(topic: String) {
        if (_assistantMode.value != AssistantMode.DUAL_MODE) return
        val currentPrefs = prefs.value
        val addressName = if (currentPrefs.groupModeEnabled) currentPrefs.groupTitle else currentPrefs.privateName
        dualLoopJob?.cancel()
        _isDualConversationActive.value = true
        _isDualPaused.value = false

        dualLoopJob = viewModelScope.launch {
            val cleanTopic = topic.ifBlank { "optimizing gaming & video editing on Android" }
            val isOnline = currentPrefs.onlineModeEnabled && DeviceCapabilities.isNetworkAvailable(getApplication())
            if (!isOnline) {
                val jLine = "[Offline Dual] On $cleanTopic, $addressName: prioritize 720p timeline previews and local RAM budgeting first."
                val rLine = "[Offline Dual] And keep pacing snappy! Even offline we can trim clips, set reminders, and swap presets smoothly."
                appendMessage(Speaker.JARVIS, jLine, AssistantMode.DUAL_MODE, isOffline = true)
                speakIfEnabled(Speaker.JARVIS, jLine, currentPrefs, queueAdd = false)
                delay(2400L)
                if (_isDualConversationActive.value && _assistantMode.value == AssistantMode.DUAL_MODE) {
                    appendMessage(Speaker.ROSE, rLine, AssistantMode.DUAL_MODE, isOffline = true)
                    speakIfEnabled(Speaker.ROSE, rLine, currentPrefs, queueAdd = true)
                }
                _isDualConversationActive.value = false
                return@launch
            }

            val memoriesList = memoryDao.getApprovedOnce()
            val skillsList = skillDao.getEnabledOnce()
            var lastStatement = "Discuss \"$cleanTopic\" briefly with each other and $addressName."
            val speakers = listOf(Speaker.JARVIS, Speaker.ROSE, Speaker.JARVIS, Speaker.ROSE)

            for ((turnIdx, speaker) in speakers.withIndex()) {
                while (_isDualPaused.value) {
                    delay(200L)
                }
                if (!_isDualConversationActive.value || _assistantMode.value != AssistantMode.DUAL_MODE) break

                val partner = if (speaker == Speaker.JARVIS) "ROSE" else "JARVIS"
                val extra = "You are in Dual Conversation turn ${turnIdx + 1}/4 with $partner and $addressName. Keep your turn concise (2 sentences max), natural, and respond directly to the previous point."
                var finalTurn = ""
                var errorOccurred = false

                aiProvider.streamReply(
                    speaker = speaker,
                    userPrompt = lastStatement,
                    historyContext = emptyList(),
                    prefs = currentPrefs,
                    memories = memoriesList,
                    skills = skillsList,
                    extraInstruction = extra
                ).collect { chunk ->
                    when (chunk) {
                        is AiResponseChunk.Delta -> _streamState.value = AssistantStreamState.Streaming(speaker, chunk.accumulatedText)
                        is AiResponseChunk.Completed -> {
                            finalTurn = chunk.finalText
                            _streamState.value = AssistantStreamState.Idle
                        }
                        is AiResponseChunk.Error -> {
                            errorOccurred = true
                            _streamState.value = AssistantStreamState.Error(chunk.message)
                        }
                    }
                }
                if (errorOccurred || finalTurn.isBlank()) break
                appendMessage(speaker, finalTurn, AssistantMode.DUAL_MODE, isOffline = false)
                speakIfEnabled(speaker, finalTurn, currentPrefs, queueAdd = turnIdx > 0)
                lastStatement = "${speaker.label} just said: \"$finalTurn\". Reply naturally."
                delay(1800L)
            }
            _isDualConversationActive.value = false
            _isDualPaused.value = false
        }
    }

    fun togglePauseDualConversation() {
        _isDualPaused.value = !_isDualPaused.value
        if (_isDualPaused.value) ttsManager.stop()
    }

    fun analyzeCameraBitmap(bitmap: Bitmap, prompt: String) {
        viewModelScope.launch {
            _isAnalyzingCamera.value = true
            _cameraAnalysisResult.value = null
            val p = prefs.value
            val speaker = if (_assistantMode.value == AssistantMode.ROSE_ONLY) Speaker.ROSE else Speaker.JARVIS
            val result = aiProvider.analyzeCameraScene(bitmap, prompt, speaker, p)
            _cameraAnalysisResult.value = result.fold(
                onSuccess = { text ->
                    if (_assistantMode.value != AssistantMode.INACTIVE) {
                        speakIfEnabled(speaker, text, p)
                    }
                    text
                },
                onFailure = { err -> "Camera AI Error: ${err.localizedMessage ?: "Unable to analyze frame."}" }
            )
            _isAnalyzingCamera.value = false
        }
    }

    suspend fun addReminder(title: String, notes: String, dueAtMillis: Long, characterTag: String): Boolean {
        return try {
            val rowId = reminderDao.insert(
                ReminderEntity(
                    title = title.trim(),
                    notes = notes.trim(),
                    dueAtMillis = dueAtMillis,
                    characterTag = characterTag
                )
            )
            if (rowId > 0L) {
                ReminderScheduler.schedule(
                    getApplication(),
                    ReminderEntity(
                        id = rowId,
                        title = title.trim(),
                        notes = notes.trim(),
                        dueAtMillis = dueAtMillis,
                        characterTag = characterTag
                    )
                )
                true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    fun toggleReminderComplete(reminder: ReminderEntity) {
        viewModelScope.launch {
            val updated = reminder.copy(isCompleted = !reminder.isCompleted)
            reminderDao.update(updated)
            if (updated.isCompleted) {
                ReminderScheduler.cancel(getApplication(), updated.id)
            } else {
                ReminderScheduler.schedule(getApplication(), updated)
            }
        }
    }

    fun updateReminder(reminder: ReminderEntity) {
        viewModelScope.launch {
            reminderDao.update(reminder)
            if (!reminder.isCompleted) {
                ReminderScheduler.schedule(getApplication(), reminder)
            }
        }
    }

    fun deleteReminderConfirmed(reminder: ReminderEntity) {
        viewModelScope.launch {
            ReminderScheduler.cancel(getApplication(), reminder.id)
            reminderDao.deleteById(reminder.id)
        }
    }

    fun sendDailyReminderSummary() {
        viewModelScope.launch {
            val pending = reminderDao.getPendingOnce()
            ReminderScheduler.showDailySummaryNotification(getApplication(), pending)
        }
    }

    fun askGamingTip(category: GameCategory, customQuestion: String) {
        val p = prefs.value
        val activeMode = _assistantMode.value
        val isOnline = p.onlineModeEnabled && DeviceCapabilities.isNetworkAvailable(getApplication())
        if (!isOnline || activeMode == AssistantMode.INACTIVE) {
            val tip = OfflineAssistantEngine.gamingTipsFor(category)
            viewModelScope.launch {
                val speaker = if (activeMode == AssistantMode.ROSE_ONLY) Speaker.ROSE else if (activeMode == AssistantMode.INACTIVE) Speaker.SYSTEM else Speaker.JARVIS
                appendMessage(speaker, tip, activeMode, isOffline = true)
                if (activeMode != AssistantMode.INACTIVE) speakIfEnabled(speaker, tip, p)
            }
        } else {
            val query = customQuestion.ifBlank {
                "Give practical gameplay tips, optimal settings for a 3GB RAM Android phone if applicable, and winning strategy for ${category.label}."
            }
            sendTypedInput(query)
        }
    }

    fun launchMatchingGame(category: GameCategory): String {
        val match = _installedApps.value.firstOrNull { app ->
            val lower = (app.label + " " + app.packageName).lowercase()
            category.keywords.any { kw -> lower.contains(kw) }
        }
        return if (match != null) {
            val res = phoneControl.launchPackage(match.packageName, prefs.value.restrictToApprovedApps, prefs.value.approvedAppPackages)
            when (res) {
                is AppLaunchResult.Launched -> "Launched ${res.app.label}."
                is AppLaunchResult.BlockedByAllowlist -> "${res.app.label} is blocked by Approved App Access."
                else -> "Could not launch ${match.label}."
            }
        } else {
            "No installed ${category.label} game matched automatically. Pick any app in Control -> App Launcher."
        }
    }

    fun saveMemory(category: String, key: String, value: String) {
        viewModelScope.launch {
            memoryDao.insert(MemoryEntryEntity(category = category, key = key.trim(), value = value.trim(), isApproved = true))
        }
    }

    fun updateMemory(entry: MemoryEntryEntity) {
        viewModelScope.launch {
            memoryDao.update(entry.copy(updatedAtMillis = System.currentTimeMillis()))
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { memoryDao.deleteById(id) }
    }

    fun toggleSkillModule(module: SkillModuleEntity) {
        viewModelScope.launch {
            saveConfigSnapshot("Before toggling ${module.name}")
            skillDao.upsert(module.copy(isEnabled = !module.isEnabled, updatedAtMillis = System.currentTimeMillis()))
        }
    }

    fun addControlledSkill(name: String, description: String, category: String, promptPatch: String) {
        viewModelScope.launch {
            saveConfigSnapshot("Before adding skill: $name")
            skillDao.upsert(
                SkillModuleEntity(
                    id = "custom_${System.currentTimeMillis()}",
                    name = name.trim(),
                    description = description.trim(),
                    category = category,
                    systemPromptPatch = promptPatch.trim(),
                    isEnabled = true,
                    isVerifiedBuiltIn = false
                )
            )
        }
    }

    suspend fun saveConfigSnapshot(label: String) {
        val p = prefs.value
        val enabledSkills = skillDao.getEnabledOnce().joinToString(",") { it.id }
        val json = JSONObject().apply {
            put("activeTextModel", p.activeTextModel)
            put("fallbackTextModel", p.fallbackTextModel)
            put("jarvisToneStyle", p.jarvisToneStyle)
            put("roseToneStyle", p.roseToneStyle)
            put("graphicsQuality", p.graphicsQuality.name)
            put("enabledSkills", enabledSkills)
        }.toString()
        snapshotDao.insert(ConfigSnapshotEntity(label = label, snapshotJson = json))
    }

    fun restoreSnapshot(snapshot: ConfigSnapshotEntity) {
        viewModelScope.launch {
            runCatching {
                val json = JSONObject(snapshot.snapshotJson)
                prefsRepo.setModelConfig(json.getString("activeTextModel"), json.getString("fallbackTextModel"))
                prefsRepo.setPersonalityTones(json.getString("jarvisToneStyle"), json.getString("roseToneStyle"))
                val gq = GraphicsQuality.valueOf(json.getString("graphicsQuality"))
                prefsRepo.setPerformanceSettings(gq, prefs.value.batterySaverMode, prefs.value.reducedAnimationMode, prefs.value.lowResVideoPreview)
                val restoredSkillIds = json.optString("enabledSkills", "").split(",").filter { it.isNotBlank() }.toSet()
                skillModules.value.forEach { mod ->
                    skillDao.upsert(mod.copy(isEnabled = mod.id in restoredSkillIds))
                }
            }
        }
    }

    fun checkModel(modelId: String) {
        viewModelScope.launch {
            _modelCheckResult.value = AiModelRegistry.checkModelAvailability(getApplication(), modelId)
        }
    }

    fun refreshRemoteModelRegistry(url: String) {
        viewModelScope.launch {
            val res = AiModelRegistry.checkTrustedRegistry(url)
            res.onSuccess { list -> _modelRegistry.value = list }
        }
    }

    fun clearHistory() {
        viewModelScope.launch { conversationDao.clearAll() }
    }

    private suspend fun appendMessage(speaker: Speaker, text: String, mode: AssistantMode, isOffline: Boolean) {
        conversationDao.insert(
            ConversationMessageEntity(
                speaker = speaker.name,
                text = text,
                mode = mode.name,
                isOffline = isOffline
            )
        )
    }

    private fun speakIfEnabled(speaker: Speaker, text: String, p: UserPreferencesState, queueAdd: Boolean = false) {
        if (p.voiceTtsEnabled && (speaker == Speaker.JARVIS || speaker == Speaker.ROSE)) {
            ttsManager.speak(text, speaker, p.jarvisPitch, p.rosePitch, queueAdd)
        }
    }

    private suspend fun seedBuiltInSkillsIfEmpty() {
        val current = skillDao.observeAll().first()
        if (current.isEmpty()) {
            skillDao.insertAll(
                listOf(
                    SkillModuleEntity(
                        id = "skill_concise_voice",
                        name = "Concise Voice Mode",
                        description = "Keeps spoken answers crisp and under 3 sentences for faster TTS playback.",
                        category = "Conversation",
                        systemPromptPatch = "Keep voice responses crisp, natural, and concise (2-3 sentences unless detailed steps are requested).",
                        isEnabled = true
                    ),
                    SkillModuleEntity(
                        id = "skill_creator_coach",
                        name = "Video Pacing & Hook Coach",
                        description = "Adds retention hook & pacing advice when discussing gaming clips or edits.",
                        category = "Video Editing",
                        systemPromptPatch = "Offer practical first-3-second hook and pacing feedback whenever the user asks about video content.",
                        isEnabled = true
                    ),
                    SkillModuleEntity(
                        id = "skill_low_ram_advisor",
                        name = "Android 11 / 3GB RAM Optimizer",
                        description = "Tailors game and device advice for Vivo Y15 / 3GB RAM hardware limits.",
                        category = "Performance",
                        systemPromptPatch = "Account for 3GB RAM Android 11 thermal and storage limits when recommending game or export settings.",
                        isEnabled = true
                    )
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechManager.stopListening()
    }
}
