package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.data.local.MemoryEntryEntity
import com.example.data.model.GraphicsQuality
import com.example.system.BiometricAuthManager
import com.example.system.UpdateStatus
import com.example.ui.JarvisViewModel
import com.example.ui.theme.AmberPulse
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramCardElevated
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.OutlineCyan
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import kotlinx.coroutines.launch

@Composable
fun SystemBrainScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val prefs by viewModel.prefs.collectAsStateWithLifecycle()
    val deviceHealth by viewModel.deviceHealth.collectAsStateWithLifecycle()
    val models by viewModel.modelRegistry.collectAsStateWithLifecycle()
    val modelCheck by viewModel.modelCheckResult.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val skills by viewModel.skillModules.collectAsStateWithLifecycle()
    val snapshots by viewModel.configSnapshots.collectAsStateWithLifecycle()
    val updateStatus by viewModel.updateStatus.collectAsStateWithLifecycle()

    var privateNameInput by remember(prefs.privateName) { mutableStateOf(prefs.privateName) }
    var groupTitleInput by remember(prefs.groupTitle) { mutableStateOf(prefs.groupTitle) }
    var registryUrlInput by remember { mutableStateOf("") }
    var manifestUrlInput by remember(prefs.updateManifestUrl) { mutableStateOf(prefs.updateManifestUrl) }

    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var editingMemory by remember { mutableStateOf<MemoryEntryEntity?>(null) }
    var showAddSkillDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepVoidNavy, SpaceSlate, DeepVoidNavy)))
            .padding(horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 720.dp).fillMaxSize(),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("SYSTEM, AI BRAIN & SETTINGS", style = MaterialTheme.typography.titleLarge, color = JarvisCyan)
            }

            // 1. Gemini AI Brain & Future Model Upgrade Manager
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Psychology, null, tint = JarvisCyan)
                                Text("Gemini AI Brain & Models", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            }
                            Switch(
                                checked = prefs.onlineModeEnabled,
                                onCheckedChange = { enabled ->
                                    scope.launch { viewModel.prefsRepo.setOnlineMode(enabled) }
                                }
                            )
                        }
                        Text(
                            if (prefs.onlineModeEnabled) "Online Gemini enabled (App Check protected). Offline fallback activates automatically when no internet."
                            else "Online Gemini manually paused — running strictly in Offline Local Mode.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )

                        models.forEach { spec ->
                            val isActive = prefs.activeTextModel == spec.id
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isActive) HologramCardElevated else SpaceSlate
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (isActive) JarvisCyan else OutlineCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${spec.displayName} (${spec.id})", style = MaterialTheme.typography.labelLarge, color = JarvisCyan)
                                        Text(spec.tier, style = MaterialTheme.typography.labelSmall, color = RoseAzure)
                                    }
                                    Text(spec.description, style = MaterialTheme.typography.bodySmall, color = IceWhite)
                                    Text("Voice/Live: ${spec.supportsLiveVoiceNote}", style = MaterialTheme.typography.labelSmall, color = MistBlue)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (spec.id != "gemini-3.1-flash-tts-preview") {
                                            OutlinedButton(onClick = {
                                                scope.launch {
                                                    viewModel.saveConfigSnapshot("Before model switch to ${spec.id}")
                                                    viewModel.prefsRepo.setModelConfig(spec.id, prefs.fallbackTextModel)
                                                }
                                            }) {
                                                Text(if (isActive) "Active" else "Use Model")
                                            }
                                        }
                                        OutlinedButton(onClick = { viewModel.checkModel(spec.id) }) {
                                            Text("Check Live")
                                        }
                                    }
                                }
                            }
                        }

                        modelCheck?.let { res ->
                            Text(
                                text = "[${res.modelId}] ${res.message}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (res.isAvailable) NeonMint else AmberPulse
                            )
                        }

                        OutlinedTextField(
                            value = registryUrlInput,
                            onValueChange = { registryUrlInput = it },
                            label = { Text("Trusted Future Model Registry HTTPS URL (Optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(onClick = { viewModel.refreshRemoteModelRegistry(registryUrlInput) }) {
                            Text("Verify Model Upgrades (Never assumes unverified Gemini 5+)")
                        }
                    }
                }
            }

            // 2. Personalized Address & Voice Settings
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Personalized Address & Voice", style = MaterialTheme.typography.titleMedium, color = JarvisCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = privateNameInput == "Feather",
                                onClick = {
                                    privateNameInput = "Feather"
                                    scope.launch { viewModel.prefsRepo.setAddressPreferences("Feather", prefs.groupModeEnabled, groupTitleInput) }
                                },
                                label = { Text("Feather") }
                            )
                            FilterChip(
                                selected = privateNameInput == "Sujan",
                                onClick = {
                                    privateNameInput = "Sujan"
                                    scope.launch { viewModel.prefsRepo.setAddressPreferences("Sujan", prefs.groupModeEnabled, groupTitleInput) }
                                },
                                label = { Text("Sujan") }
                            )
                        }
                        OutlinedTextField(
                            value = privateNameInput,
                            onValueChange = { privateNameInput = it },
                            label = { Text("Private Mode Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Group Mode (Address as \"$groupTitleInput\")", color = IceWhite, style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = prefs.groupModeEnabled,
                                onCheckedChange = { enabled ->
                                    scope.launch { viewModel.prefsRepo.setAddressPreferences(privateNameInput, enabled, groupTitleInput) }
                                }
                            )
                        }
                        Button(onClick = {
                            scope.launch { viewModel.prefsRepo.setAddressPreferences(privateNameInput, prefs.groupModeEnabled, groupTitleInput) }
                        }) {
                            Text("Save Address Name")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Voice Readout (Android TTS)", color = IceWhite)
                            Switch(
                                checked = prefs.voiceTtsEnabled,
                                onCheckedChange = { enabled ->
                                    scope.launch { viewModel.prefsRepo.setVoiceSettings(enabled, prefs.jarvisPitch, prefs.rosePitch) }
                                }
                            )
                        }
                        Text("JARVIS Pitch: ${"%.2f".format(prefs.jarvisPitch)}", style = MaterialTheme.typography.labelSmall, color = JarvisCyan)
                        Slider(
                            value = prefs.jarvisPitch,
                            onValueChange = { p -> scope.launch { viewModel.prefsRepo.setVoiceSettings(prefs.voiceTtsEnabled, p, prefs.rosePitch) } },
                            valueRange = 0.65f..1.20f
                        )
                        Text("ROSE Pitch: ${"%.2f".format(prefs.rosePitch)}", style = MaterialTheme.typography.labelSmall, color = RoseAzure)
                        Slider(
                            value = prefs.rosePitch,
                            onValueChange = { p -> scope.launch { viewModel.prefsRepo.setVoiceSettings(prefs.voiceTtsEnabled, prefs.jarvisPitch, p) } },
                            valueRange = 0.90f..1.45f
                        )
                    }
                }
            }

            // 3. User-Controlled Memory System
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Memory, null, tint = JarvisCyan)
                                Text("User-Controlled Memory (${memories.size})", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                            }
                            Switch(
                                checked = prefs.memoryEnabled,
                                onCheckedChange = { enabled -> scope.launch { viewModel.prefsRepo.setMemoryEnabled(enabled) } }
                            )
                        }
                        Text(
                            "Only stores user-approved preferences (language, editing style, gaming tastes). View, edit, delete, or disable anytime.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        Button(onClick = {
                            editingMemory = null
                            showAddMemoryDialog = true
                        }, modifier = Modifier.testTag("add_memory_button")) {
                            Text("Add Approved Preference")
                        }
                        memories.forEach { mem ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("[${mem.category}] ${mem.key}: ${mem.value}", style = MaterialTheme.typography.bodySmall, color = IceWhite)
                                }
                                Row {
                                    IconButton(onClick = {
                                        editingMemory = mem
                                        showAddMemoryDialog = true
                                    }) {
                                        Icon(Icons.Default.Edit, "Edit memory", tint = MistBlue)
                                    }
                                    IconButton(onClick = { viewModel.deleteMemory(mem.id) }) {
                                        Icon(Icons.Default.Delete, "Delete memory", tint = CrimsonAlert)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Safe Self-Improvement & Configuration Rollback
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Verified, null, tint = NeonMint)
                            Text("Safe Self-Improvement & Rollback", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "Enable verified behavioral modules or create safe prompt skills with automatic configuration backups. Source code and security settings are never modified autonomously.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        skills.forEach { mod ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mod.name, style = MaterialTheme.typography.bodyMedium, color = IceWhite)
                                    Text(mod.description, style = MaterialTheme.typography.bodySmall, color = MistBlue)
                                }
                                Switch(checked = mod.isEnabled, onCheckedChange = { viewModel.toggleSkillModule(mod) })
                            }
                        }
                        OutlinedButton(onClick = { showAddSkillDialog = true }) {
                            Text("Add Controlled Skill Module")
                        }
                        if (snapshots.isNotEmpty()) {
                            Text("Configuration Backups (Review & Undo):", style = MaterialTheme.typography.labelMedium, color = JarvisCyan)
                            snapshots.take(4).forEach { snap ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.History, null, tint = MistBlue)
                                        Text(snap.label, style = MaterialTheme.typography.bodySmall, color = MistBlue)
                                    }
                                    TextButton(onClick = { viewModel.restoreSnapshot(snap) }) {
                                        Text("Undo / Restore", color = JarvisCyan)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Performance Optimization (Vivo Y15 / Android 11 / 3GB RAM)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Speed, null, tint = JarvisCyan)
                            Text("Performance & 3GB RAM Optimizer", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "${deviceHealth.deviceLabel} • ${deviceHealth.androidVersionLabel}\nRAM: ${deviceHealth.availableRamMb}/${deviceHealth.totalRamMb} MB free • Free Storage: ${deviceHealth.freeStorageMb} MB",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoseAzure
                        )
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            GraphicsQuality.entries.forEach { q ->
                                FilterChip(
                                    selected = prefs.graphicsQuality == q,
                                    onClick = {
                                        scope.launch {
                                            viewModel.prefsRepo.setPerformanceSettings(q, prefs.batterySaverMode, prefs.reducedAnimationMode, prefs.lowResVideoPreview)
                                        }
                                    },
                                    label = { Text(q.label) }
                                )
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Battery-Saving Mode", color = IceWhite)
                            Switch(checked = prefs.batterySaverMode, onCheckedChange = { v ->
                                scope.launch { viewModel.prefsRepo.setPerformanceSettings(prefs.graphicsQuality, v, prefs.reducedAnimationMode, prefs.lowResVideoPreview) }
                            })
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Reduced Animations", color = IceWhite)
                            Switch(checked = prefs.reducedAnimationMode, onCheckedChange = { v ->
                                scope.launch { viewModel.prefsRepo.setPerformanceSettings(prefs.graphicsQuality, prefs.batterySaverMode, v, prefs.lowResVideoPreview) }
                            })
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Low-Memory Video Processing Guard", color = IceWhite)
                            Switch(checked = prefs.lowResVideoPreview, onCheckedChange = { v ->
                                scope.launch { viewModel.prefsRepo.setPerformanceSettings(prefs.graphicsQuality, prefs.batterySaverMode, prefs.reducedAnimationMode, v) }
                            })
                        }
                    }
                }
            }

            // 6. Security & App Lock
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Security, null, tint = NeonMint)
                            Text("Security & App Lock", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "Biometric hardware available: ${BiometricAuthManager.isBiometricAvailable(context)}. Uses Android BiometricPrompt + PIN fallback + Recovery Code (never permanently locks you out).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showSecurityDialog = true }, modifier = Modifier.testTag("configure_lock_button")) {
                                Icon(Icons.Default.Lock, null)
                                Spacer(Modifier.width(4.dp))
                                Text(if (prefs.appLockEnabled) "Lock Settings (ON)" else "Enable App Lock")
                            }
                            if (prefs.appLockEnabled) {
                                OutlinedButton(onClick = { viewModel.lockAppNow() }) {
                                    Text("Test Lock Now")
                                }
                            }
                        }
                    }
                }
            }

            // 7. Safe Application Update Manager
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = HologramPanel),
                    modifier = Modifier.fillMaxWidth().border(1.dp, OutlineCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.SystemUpdate, null, tint = JarvisCyan)
                            Text("Safe Application Update Manager", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                        }
                        Text(
                            "Current Version: v${BuildConfig.VERSION_NAME} (Code ${BuildConfig.VERSION_CODE}). Verifies HTTPS source, minSdk compatibility, and SHA-256 checksum; requires your confirmation via Android's installer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MistBlue
                        )
                        OutlinedTextField(
                            value = manifestUrlInput,
                            onValueChange = { manifestUrlInput = it },
                            label = { Text("Official Release Manifest HTTPS URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = {
                            scope.launch {
                                viewModel.prefsRepo.setUpdateManifestUrl(manifestUrlInput)
                                viewModel.updateManager.checkForUpdates(manifestUrlInput)
                            }
                        }, modifier = Modifier.testTag("check_updates_button")) {
                            Text("Check for Official Update")
                        }

                        when (val st = updateStatus) {
                            UpdateStatus.Idle -> Unit
                            UpdateStatus.Checking -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            is UpdateStatus.UpToDate -> Text(st.currentVersion, style = MaterialTheme.typography.bodySmall, color = NeonMint)
                            is UpdateStatus.UpdateAvailable -> {
                                Text("Latest: v${st.manifest.versionName} • ${st.manifest.changelog}", style = MaterialTheme.typography.bodySmall, color = JarvisCyan)
                                Text(st.note, style = MaterialTheme.typography.labelSmall, color = if (st.isCompatible) NeonMint else CrimsonAlert)
                                if (st.isCompatible) {
                                    Button(onClick = { scope.launch { viewModel.updateManager.downloadAndVerifyApk(st.manifest) } }) {
                                        Text("Download & Verify Package")
                                    }
                                }
                            }
                            is UpdateStatus.Downloading -> {
                                LinearProgressIndicator(progress = { st.progressPercent / 100f }, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Downloading ${st.progressPercent}%", color = JarvisCyan)
                                    TextButton(onClick = { viewModel.updateManager.cancelDownload() }) {
                                        Text("Cancel", color = CrimsonAlert)
                                    }
                                }
                            }
                            is UpdateStatus.ReadyToInstall -> {
                                Text("SHA-256 Verified: ${st.verifiedSha256.take(16)}...", color = NeonMint, style = MaterialTheme.typography.labelSmall)
                                Button(onClick = { viewModel.updateManager.launchSystemPackageInstaller(st.apkFile) }) {
                                    Text("Install Verified Update (Android Prompt)")
                                }
                            }
                            is UpdateStatus.Error -> Text(st.message, style = MaterialTheme.typography.bodySmall, color = CrimsonAlert)
                        }
                    }
                }
            }
        }
    }

    if (showAddMemoryDialog) {
        var cat by remember { mutableStateOf(editingMemory?.category ?: "Preferred Style") }
        var key by remember { mutableStateOf(editingMemory?.key ?: "") }
        var value by remember { mutableStateOf(editingMemory?.value ?: "") }

        AlertDialog(
            onDismissRequest = { showAddMemoryDialog = false },
            containerColor = HologramCardElevated,
            title = { Text(if (editingMemory == null) "Save Approved Preference" else "Edit Memory") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("Category") })
                    OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("Preference Key") })
                    OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text("Value") })
                }
            },
            confirmButton = {
                Button(enabled = key.isNotBlank() && value.isNotBlank(), onClick = {
                    val target = editingMemory
                    if (target == null) viewModel.saveMemory(cat, key, value)
                    else viewModel.updateMemory(target.copy(category = cat, key = key, value = value))
                    showAddMemoryDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddMemoryDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddSkillDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var patch by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddSkillDialog = false },
            containerColor = HologramCardElevated,
            title = { Text("Add Controlled Skill Module") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Skill Name") })
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Purpose") })
                    OutlinedTextField(value = patch, onValueChange = { patch = it }, label = { Text("Behavior Prompt Rule") })
                }
            },
            confirmButton = {
                Button(enabled = name.isNotBlank() && patch.isNotBlank(), onClick = {
                    viewModel.addControlledSkill(name, desc, "Custom", patch)
                    showAddSkillDialog = false
                }) { Text("Save Skill") }
            },
            dismissButton = { TextButton(onClick = { showAddSkillDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSecurityDialog) {
        var lockEnabled by remember { mutableStateOf(prefs.appLockEnabled) }
        var bioEnabled by remember { mutableStateOf(prefs.biometricEnabled) }
        var pin by remember { mutableStateOf("") }
        var recovery by remember { mutableStateOf("FEATHER-RECOVER-9") }
        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            containerColor = HologramCardElevated,
            title = { Text("Configure App Lock") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Require Unlock on Launch")
                        Switch(checked = lockEnabled, onCheckedChange = { lockEnabled = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Use Fingerprint / BiometricPrompt")
                        Switch(checked = bioEnabled, onCheckedChange = { bioEnabled = it })
                    }
                    OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("New PIN (4+ digits)") })
                    OutlinedTextField(value = recovery, onValueChange = { recovery = it }, label = { Text("Recovery Code (Keep safe!)") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        viewModel.prefsRepo.setSecurityConfig(
                            appLockEnabled = lockEnabled,
                            biometricEnabled = bioEnabled,
                            pinRaw = pin.takeIf { it.length >= 4 },
                            recoveryCodeRaw = recovery.takeIf { it.isNotBlank() }
                        )
                    }
                    showSecurityDialog = false
                }) { Text("Save Security") }
            },
            dismissButton = { TextButton(onClick = { showSecurityDialog = false }) { Text("Cancel") } }
        )
    }
}
