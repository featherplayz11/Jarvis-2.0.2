package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepVoidNavy = Color(0xFF030A1C)
val SpaceSlate = Color(0xFF07132B)
val HologramPanel = Color(0xFF0B1C3D)
val HologramCardElevated = Color(0xFF102650)

val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanDim = Color(0xFF0097B2)
val RoseAzure = Color(0xFF38BDF8)
val RoseGlow = Color(0xFF60A5FA)
val DualVioletCyan = Color(0xFF22D3EE)

val IceWhite = Color(0xFFE6F4FF)
val MistBlue = Color(0xFF94B8D7)
val DimSteel = Color(0xFF537294)

val NeonMint = Color(0xFF10B981)
val AmberPulse = Color(0xFFF59E0B)
val CrimsonAlert = Color(0xFFEF4444)
val OutlineCyan = Color(0x4D00E5FF)
