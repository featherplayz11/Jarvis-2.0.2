package com.example.ui.hologram

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AssistantMode
import com.example.data.model.GraphicsQuality
import com.example.data.model.Speaker
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.NeonMint
import com.example.ui.theme.RoseAzure
import com.example.ui.theme.SpaceSlate
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun HologramStage(
    mode: AssistantMode,
    speakingCharacter: Speaker?,
    lipAmplitude: Float,
    isListening: Boolean,
    graphicsQuality: GraphicsQuality,
    reducedAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val isWide = maxWidth >= 520.dp
        when (mode) {
            AssistantMode.INACTIVE -> {
                StandbyCoreBeacon(
                    isListening = isListening,
                    graphicsQuality = graphicsQuality,
                    reducedAnimations = reducedAnimations,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            AssistantMode.JARVIS_ONLY -> {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CharacterHologramWindow(
                        character = Speaker.JARVIS,
                        isSpeaking = speakingCharacter == Speaker.JARVIS,
                        isListening = isListening,
                        lipAmplitude = if (speakingCharacter == Speaker.JARVIS) lipAmplitude else 0f,
                        graphicsQuality = graphicsQuality,
                        reducedAnimations = reducedAnimations,
                        modifier = Modifier
                            .fillMaxWidth(if (isWide) 0.55f else 0.88f)
                            .aspectRatio(1f)
                    )
                }
            }
            AssistantMode.ROSE_ONLY -> {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CharacterHologramWindow(
                        character = Speaker.ROSE,
                        isSpeaking = speakingCharacter == Speaker.ROSE,
                        isListening = isListening,
                        lipAmplitude = if (speakingCharacter == Speaker.ROSE) lipAmplitude else 0f,
                        graphicsQuality = graphicsQuality,
                        reducedAnimations = reducedAnimations,
                        modifier = Modifier
                            .fillMaxWidth(if (isWide) 0.55f else 0.88f)
                            .aspectRatio(1f)
                    )
                }
            }
            AssistantMode.DUAL_MODE -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
                ) {
                    CharacterHologramWindow(
                        character = Speaker.JARVIS,
                        isSpeaking = speakingCharacter == Speaker.JARVIS,
                        isListening = isListening,
                        lipAmplitude = if (speakingCharacter == Speaker.JARVIS) lipAmplitude else 0f,
                        graphicsQuality = graphicsQuality,
                        reducedAnimations = reducedAnimations,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                    )
                    CharacterHologramWindow(
                        character = Speaker.ROSE,
                        isSpeaking = speakingCharacter == Speaker.ROSE,
                        isListening = isListening,
                        lipAmplitude = if (speakingCharacter == Speaker.ROSE) lipAmplitude else 0f,
                        graphicsQuality = graphicsQuality,
                        reducedAnimations = reducedAnimations,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun StandbyCoreBeacon(
    isListening: Boolean,
    graphicsQuality: GraphicsQuality,
    reducedAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "standbyCore")
    val rot by infinite.animateFloat(
        initialValue = 0f,
        targetValue = if (reducedAnimations) 0f else 360f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing)),
        label = "standbyRot"
    )
    val accent = if (isListening) NeonMint else JarvisCyan

    Box(
        modifier = modifier
            .height(148.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.radialGradient(listOf(HologramPanel, SpaceSlate, DeepVoidNavy)))
            .border(1.dp, accent.copy(alpha = if (isListening) 0.8f else 0.35f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val c = Offset(size.width * 0.5f, size.height * 0.5f)
            val rings = if (reducedAnimations) 1 else graphicsQuality.ringCount
            for (i in 0 until rings) {
                val r = 28f + i * 18f
                drawArc(
                    color = accent.copy(alpha = if (isListening) 0.55f else 0.25f),
                    startAngle = rot * (if (i % 2 == 0) 1f else -0.6f) + i * 50f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(c.x - r, c.y - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(width = 2.4f, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (isListening) "VOICE STANDBY LISTENING" else "ASSISTANTS STANDBY",
                style = MaterialTheme.typography.labelLarge,
                color = accent
            )
            Text(
                text = "Say \"Hey JARVIS\", \"Hey ROSE\", or \"Hey JARVIS and ROSE\"",
                style = MaterialTheme.typography.bodySmall,
                color = MistBlue
            )
        }
    }
}

@Composable
fun CharacterHologramWindow(
    character: Speaker,
    isSpeaking: Boolean,
    isListening: Boolean,
    lipAmplitude: Float,
    graphicsQuality: GraphicsQuality,
    reducedAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    val accent = if (character == Speaker.JARVIS) JarvisCyan else RoseAzure
    val drawableRes = if (character == Speaker.JARVIS) R.drawable.jarvis_hologram else R.drawable.rose_hologram

    // Natural periodic blink & subtle eye/head micro-motion
    var blinkProgress by remember { mutableFloatStateOf(0f) }
    var headTilt by remember { mutableFloatStateOf(0f) }
    var browLift by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(reducedAnimations, isSpeaking) {
        if (reducedAnimations) {
            blinkProgress = 0f
            headTilt = 0f
            browLift = 0f
            return@LaunchedEffect
        }
        while (true) {
            delay(Random.nextLong(2200L, 4600L))
            blinkProgress = 1f
            delay(110L)
            blinkProgress = 0f
            headTilt = (Random.nextFloat() - 0.5f) * (if (isSpeaking) 4.2f else 2.2f)
            browLift = if (isSpeaking) Random.nextFloat() * 3.5f else 0.5f
        }
    }

    val animatedBlink by animateFloatAsState(
        targetValue = blinkProgress,
        animationSpec = tween(90),
        label = "blink"
    )
    val animatedHeadTilt by animateFloatAsState(
        targetValue = headTilt,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "headTilt"
    )
    val animatedMouth by animateFloatAsState(
        targetValue = if (isSpeaking) lipAmplitude.coerceIn(0.15f, 1f) else 0f,
        animationSpec = tween(80),
        label = "mouth"
    )

    val infinite = rememberInfiniteTransition(label = "holoLoop")
    val ringRotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = if (reducedAnimations) 0f else 360f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "ringRot"
    )
    val floatPhase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "floatPhase"
    )

    val verticalDrift = if (reducedAnimations) 0f else sin(floatPhase) * 4f + (if (isSpeaking) -animatedMouth * 2.5f else 0f)
    val particleSeeds = remember(graphicsQuality) {
        List(graphicsQuality.particleCount) {
            Triple(Random.nextFloat(), Random.nextFloat(), 0.4f + Random.nextFloat() * 0.6f)
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(HologramPanel, SpaceSlate, DeepVoidNavy)
                )
            )
            .border(
                width = if (isSpeaking || isListening) 1.8.dp else 1.dp,
                color = when {
                    isSpeaking -> accent
                    isListening -> NeonMint
                    else -> accent.copy(alpha = 0.42f)
                },
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        // Supplied Portrait with subtle 2.5D head breathing, micro-tilt, and brow lift
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = "${character.label} holographic avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = verticalDrift - browLift * 0.4f
                    rotationZ = animatedHeadTilt
                    scaleX = 1.03f + (if (isSpeaking) animatedMouth * 0.018f else 0f)
                    scaleY = 1.03f + (if (isSpeaking) animatedMouth * 0.018f else 0f)
                }
        )

        // Holographic energy rings, particles, natural blink overlay, and speaking lip/jaw synth wave
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w * 0.5f, h * 0.48f)

            // Rotating arc rings
            val ringCount = if (reducedAnimations) 1 else graphicsQuality.ringCount
            for (i in 0 until ringCount) {
                val radius = w * (0.37f + i * 0.055f)
                val sweep = 110f + i * 35f
                val startAngle = ringRotation * (if (i % 2 == 0) 1f else -0.7f) + i * 70f
                drawArc(
                    color = accent.copy(alpha = if (isSpeaking) 0.45f else 0.22f),
                    startAngle = startAngle,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2f, radius * 2f),
                    style = Stroke(width = 2.2f, cap = StrokeCap.Round)
                )
            }

            // Floating holographic particles
            if (!reducedAnimations) {
                particleSeeds.forEachIndexed { idx, (px, py, speed) ->
                    val yOffset = ((py - (floatPhase / (2f * PI.toFloat())) * speed) % 1f + 1f) % 1f
                    val xWobble = px + sin(floatPhase + idx) * 0.02f
                    drawCircle(
                        color = accent.copy(alpha = 0.35f),
                        radius = (1.5f + speed * 2f),
                        center = Offset(xWobble * w, yOffset * h)
                    )
                }
            }

            // Natural eyelid blink bands positioned over upper ocular zone
            if (animatedBlink > 0.05f) {
                val eyeY = h * 0.36f
                val eyeSpan = w * 0.075f
                val lidH = h * 0.026f * animatedBlink
                drawRoundRect(
                    color = DeepVoidNavy.copy(alpha = 0.78f * animatedBlink),
                    topLeft = Offset(w * 0.405f - eyeSpan * 0.5f, eyeY - lidH * 0.5f),
                    size = Size(eyeSpan, lidH),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = DeepVoidNavy.copy(alpha = 0.78f * animatedBlink),
                    topLeft = Offset(w * 0.595f - eyeSpan * 0.5f, eyeY - lidH * 0.5f),
                    size = Size(eyeSpan, lidH),
                    cornerRadius = CornerRadius(6f, 6f)
                )
            }

            // Lip/Jaw holographic energy modulation & live voice waveform bar
            val barCount = 15
            val barAreaWidth = w * 0.54f
            val startX = (w - barAreaWidth) * 0.5f
            val baseY = h * 0.87f
            val step = barAreaWidth / barCount
            for (b in 0 until barCount) {
                val distFromCenter = kotlin.math.abs(b - barCount / 2f) / (barCount / 2f)
                val wave = if (isSpeaking) {
                    (0.22f + animatedMouth * (1f - distFromCenter * 0.65f) *
                        (0.6f + 0.4f * sin(floatPhase * 3f + b)))
                } else if (isListening) {
                    0.22f + 0.16f * sin(floatPhase * 2f + b)
                } else {
                    0.12f
                }
                val barH = h * 0.09f * wave
                drawLine(
                    color = if (isListening && !isSpeaking) NeonMint else accent,
                    start = Offset(startX + b * step, baseY - barH * 0.5f),
                    end = Offset(startX + b * step, baseY + barH * 0.5f),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Top HUD Status Badge
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(DeepVoidNavy.copy(alpha = 0.75f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isSpeaking -> accent
                                isListening -> NeonMint
                                else -> MistBlue.copy(alpha = 0.5f)
                            }
                        )
                )
                Text(
                    text = character.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = when {
                    isSpeaking -> "SPEAKING"
                    isListening -> "LISTENING"
                    else -> "STANDBY"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (isSpeaking || isListening) accent else MistBlue,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(DeepVoidNavy.copy(alpha = 0.75f))
                    .padding(horizontal = 7.dp, vertical = 3.dp)
                    .alpha(0.95f)
            )
        }
    }
}
