package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.system.BiometricAuthManager
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.MistBlue
import com.example.ui.theme.OutlineCyan

@Composable
fun AppLockOverlay(
    biometricEnabled: Boolean,
    hasPinConfigured: Boolean,
    onUnlockSuccess: () -> Unit,
    onVerifyPin: (String) -> Boolean,
    onVerifyRecovery: (String) -> Boolean
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    var pinInput by remember { mutableStateOf("") }
    var recoveryMode by remember { mutableStateOf(false) }
    var recoveryInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun triggerBiometric() {
        if (activity != null && biometricEnabled && BiometricAuthManager.isBiometricAvailable(context)) {
            BiometricAuthManager.authenticate(
                activity = activity,
                onSuccess = onUnlockSuccess,
                onFallbackPin = { errorMsg = "Enter your App PIN or Recovery Code." },
                onError = { msg -> errorMsg = msg }
            )
        }
    }

    LaunchedEffect(Unit) {
        triggerBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepVoidNavy),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = HologramPanel),
            modifier = Modifier
                .widthIn(max = 420.dp)
                .padding(24.dp)
                .border(1.dp, OutlineCyan, RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Lock, null, tint = JarvisCyan)
                Text("JARVIS FEATHER LOCKED", style = MaterialTheme.typography.titleLarge, color = JarvisCyan)
                Text(
                    if (recoveryMode) "Enter your Recovery Code to reset App Lock safely."
                    else "Authenticate with Biometrics or App PIN.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MistBlue
                )

                if (!recoveryMode) {
                    if (biometricEnabled && BiometricAuthManager.isBiometricAvailable(context)) {
                        Button(onClick = { triggerBiometric() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Fingerprint, null)
                            Spacer(Modifier.height(4.dp))
                            Text("Verify Fingerprint / Biometric")
                        }
                    }

                    if (hasPinConfigured) {
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { pinInput = it },
                            label = { Text("App PIN") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                if (onVerifyPin(pinInput)) {
                                    errorMsg = null
                                } else {
                                    errorMsg = "Incorrect PIN."
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Unlock with PIN")
                        }
                    } else if (!biometricEnabled || !BiometricAuthManager.isBiometricAvailable(context)) {
                        OutlinedButton(onClick = onUnlockSuccess, modifier = Modifier.fillMaxWidth()) {
                            Text("Continue (No PIN/Biometric enrolled)")
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = recoveryInput,
                        onValueChange = { recoveryInput = it },
                        label = { Text("Recovery Code") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (!onVerifyRecovery(recoveryInput)) {
                                errorMsg = "Recovery code did not match."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Recover & Unlock")
                    }
                }

                errorMsg?.let {
                    Text(it, style = MaterialTheme.typography.labelMedium, color = CrimsonAlert)
                }

                TextButton(onClick = {
                    recoveryMode = !recoveryMode
                    errorMsg = null
                }) {
                    Text(if (recoveryMode) "Back to PIN / Biometric" else "Forgot PIN? Use Recovery Code", color = IceWhite)
                }
            }
        }
    }
}
