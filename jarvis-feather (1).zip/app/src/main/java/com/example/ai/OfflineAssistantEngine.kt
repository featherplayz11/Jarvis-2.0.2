package com.example.ai

import com.example.data.model.AssistantMode
import com.example.data.model.GameCategory
import com.example.data.model.Speaker
import java.util.Locale

sealed interface VoiceWakeResult {
    data class Activate(
        val mode: AssistantMode,
        val spokenConfirmation: String,
        val trailingCommand: String? = null
    ) : VoiceWakeResult
    data object StopBoth : VoiceWakeResult
    data object UnclearOrAccidental : VoiceWakeResult
}

sealed interface LocalCommandAction {
    data class OpenApp(val query: String) : LocalCommandAction
    data class OpenSystemScreen(val target: String) : LocalCommandAction
    data class CreateReminder(val title: String, val delayMinutes: Long) : LocalCommandAction
    data class SearchWeb(val query: String) : LocalCommandAction
    data object MediaPlayPause : LocalCommandAction
    data object MediaNext : LocalCommandAction
    data object GoHome : LocalCommandAction
    data object NavigateBack : LocalCommandAction
    data object StopSpeakingOrControl : LocalCommandAction
    data object OpenVideoEditor : LocalCommandAction
    data class ReplyOnly(val speaker: Speaker, val text: String) : LocalCommandAction
}

object OfflineAssistantEngine {

    private val jokes = listOf(
        "Why did the redstone repeater go to therapy? It kept delaying its feelings by four ticks.",
        "I told JARVIS to take a break. He replied, 'I operate in milliseconds, Rose—that *was* my vacation.'",
        "Why do survival gamers never tell secrets in caves? Too many creepers eavesdropping.",
        "What is an Android assistant's favorite snack? Micro-chips with a side of clean cache."
    )

    private val encouragements = listOf(
        "Take a breath—progress does not have to be loud to be real. One small step right now is enough.",
        "You have gotten through tough levels before. Reset, grab water, and tackle one piece at a time.",
        "Steady pace wins long runs. I'm right here whenever you want to brainstorm or take a quick break."
    )

    val quizzes: List<Triple<String, List<String>, Int>> = listOf(
        Triple(
            "In Minecraft, which block stops creepers from destroying nearby terrain when exploding inside it?",
            listOf("Oak Planks", "Water source block", "Sandstone", "Glass"),
            1
        ),
        Triple(
            "Which Android component safely handles background media transcoding and trimming in Media3?",
            listOf("Transformer", "ListView", "ContentResolver", "WebView"),
            0
        ),
        Triple(
            "In racing games, what is the ideal cornering sequence for maximum exit speed?",
            listOf("Accelerate mid-turn, brake late", "Brake straight before turn-in, hit apex, throttle out", "Drift every straightaway", "Stay on outer curb"),
            1
        )
    )

    /**
     * Strict voice-only wake-word parser.
     * Prevents accidental wake-word activation by requiring explicit anchored wake phrases.
     * Returns null when the spoken utterance is a normal query for an already-active assistant.
     */
    fun parseVoiceWakeCommand(
        rawTranscript: String,
        currentMode: AssistantMode,
        preferredAddress: String
    ): VoiceWakeResult? {
        val cleaned = rawTranscript.trim()
            .replace(Regex("[,\\.!?;:]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val lower = cleaned.lowercase(Locale.US)

        if (lower.isEmpty()) return VoiceWakeResult.UnclearOrAccidental

        // Stop both assistants immediately
        if (lower == "stop both" || lower == "hey stop both" || lower == "deactivate both") {
            return VoiceWakeResult.StopBoth
        }

        // Activate both: "Hey JARVIS and ROSE" (or "Hey ROSE and JARVIS")
        val dualRegex = Regex("^hey (jarvis and rose|rose and jarvis)(?:\\s+(.*))?$")
        dualRegex.matchEntire(lower)?.let { match ->
            val trailing = match.groupValues.getOrNull(2)?.trim()?.takeIf { it.isNotEmpty() }
            return VoiceWakeResult.Activate(
                mode = AssistantMode.DUAL_MODE,
                spokenConfirmation = "Dual mode active, $preferredAddress. Both JARVIS and ROSE are online.",
                trailingCommand = trailing
            )
        }

        // Narrow from dual or activate single explicitly: "Hey JARVIS only" / "Hey ROSE only"
        val jarvisOnlyRegex = Regex("^hey jarvis only(?:\\s+(.*))?$")
        jarvisOnlyRegex.matchEntire(lower)?.let { match ->
            val trailing = match.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() }
            return VoiceWakeResult.Activate(
                mode = AssistantMode.JARVIS_ONLY,
                spokenConfirmation = "JARVIS only active, $preferredAddress. ROSE is standing down.",
                trailingCommand = trailing
            )
        }

        val roseOnlyRegex = Regex("^hey rose only(?:\\s+(.*))?$")
        roseOnlyRegex.matchEntire(lower)?.let { match ->
            val trailing = match.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() }
            return VoiceWakeResult.Activate(
                mode = AssistantMode.ROSE_ONLY,
                spokenConfirmation = "ROSE only active, $preferredAddress! JARVIS is standing down.",
                trailingCommand = trailing
            )
        }

        // "Hey JARVIS"
        val jarvisRegex = Regex("^hey jarvis(?:\\s+(.*))?$")
        jarvisRegex.matchEntire(lower)?.let { match ->
            val trailing = match.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() }
            return VoiceWakeResult.Activate(
                mode = AssistantMode.JARVIS_ONLY,
                spokenConfirmation = "JARVIS online, $preferredAddress.",
                trailingCommand = trailing
            )
        }

        // "Hey ROSE"
        val roseRegex = Regex("^hey rose(?:\\s+(.*))?$")
        roseRegex.matchEntire(lower)?.let { match ->
            val trailing = match.groupValues.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() }
            return VoiceWakeResult.Activate(
                mode = AssistantMode.ROSE_ONLY,
                spokenConfirmation = "Hey $preferredAddress! ROSE is here.",
                trailingCommand = trailing
            )
        }

        // Guard against accidental partial triggers when inactive
        if (currentMode == AssistantMode.INACTIVE) {
            return VoiceWakeResult.UnclearOrAccidental
        }

        // When an assistant is already active, if the user appears to have misspoken a wake phrase
        // like "jarvis" or "rose" in isolation, ask them to repeat clearly instead of guessing.
        if (lower == "jarvis" || lower == "rose" || lower == "both" || lower == "jarvis and rose") {
            return VoiceWakeResult.UnclearOrAccidental
        }

        return null
    }

    /**
     * Parses general phone control / utility commands (never activates or switches assistant characters).
     */
    fun parseCommandOrOfflineReply(rawInput: String): LocalCommandAction? {
        val text = rawInput.trim()
        val lower = text.lowercase(Locale.US)

        return when {
            lower == "stop" || lower == "silence" -> LocalCommandAction.StopSpeakingOrControl
            lower == "go home" || lower == "home screen" -> LocalCommandAction.GoHome
            lower == "go back" || lower == "back" -> LocalCommandAction.NavigateBack
            lower.contains("pause music") || lower.contains("play music") || lower.contains("play pause") ->
                LocalCommandAction.MediaPlayPause
            lower.contains("next song") || lower.contains("next track") ->
                LocalCommandAction.MediaNext
            lower.contains("open video editor") || lower.contains("edit video") ->
                LocalCommandAction.OpenVideoEditor
            lower.startsWith("open settings") || lower.contains("wifi settings") || lower.contains("bluetooth settings") ->
                LocalCommandAction.OpenSystemScreen(lower)
            lower.startsWith("open ") || lower.startsWith("launch ") -> {
                val appQuery = text.replaceFirst(Regex("(?i)^(open|launch)\\s+"), "").trim()
                if (appQuery.isNotEmpty()) LocalCommandAction.OpenApp(appQuery) else null
            }
            lower.startsWith("search ") || lower.startsWith("google ") -> {
                val query = text.replaceFirst(Regex("(?i)^(search|google)\\s+(for\\s+)?"), "").trim()
                if (query.isNotEmpty()) LocalCommandAction.SearchWeb(query) else null
            }
            lower.startsWith("remind me") -> {
                val minutesMatch = Regex("(\\d+)\\s*(min|minute|minutes)").find(lower)
                val hoursMatch = Regex("(\\d+)\\s*(hr|hour|hours)").find(lower)
                val delayMinutes = when {
                    minutesMatch != null -> minutesMatch.groupValues[1].toLongOrNull() ?: 15L
                    hoursMatch != null -> (hoursMatch.groupValues[1].toLongOrNull() ?: 1L) * 60L
                    else -> 15L
                }
                val cleanTitle = text
                    .replace(Regex("(?i)^remind me( to)?\\s*"), "")
                    .replace(Regex("(?i)\\s*in \\d+\\s*(min|minute|minutes|hr|hour|hours).*$"), "")
                    .trim()
                    .ifBlank { "Scheduled Reminder" }
                LocalCommandAction.CreateReminder(cleanTitle, delayMinutes)
            }
            else -> null
        }
    }

    fun buildOfflineResponse(
        rawInput: String,
        mode: AssistantMode,
        preferredAddress: String
    ): Pair<Speaker, String> {
        val lower = rawInput.lowercase(Locale.US)
        val speaker = when (mode) {
            AssistantMode.JARVIS_ONLY -> Speaker.JARVIS
            AssistantMode.ROSE_ONLY -> Speaker.ROSE
            AssistantMode.DUAL_MODE -> if (lower.contains("rose") || lower.contains("joke") || lower.contains("bored") || lower.contains("sad")) Speaker.ROSE else Speaker.JARVIS
            AssistantMode.INACTIVE -> Speaker.SYSTEM
        }

        val reply = when {
            lower.contains("joke") -> jokes.random()
            lower.contains("encourage") || lower.contains("lonely") || lower.contains("tired") || lower.contains("bored") -> {
                "${encouragements.random()} Want to try a quick quiz in Tasks or start a video edit in Studio?"
            }
            lower.contains("minecraft") -> gamingTipsFor(GameCategory.MINECRAFT)
            lower.contains("horror") -> gamingTipsFor(GameCategory.HORROR)
            lower.contains("survival") -> gamingTipsFor(GameCategory.SURVIVAL)
            lower.contains("pvp") || lower.contains("bgmi") || lower.contains("pubg") -> gamingTipsFor(GameCategory.PVP)
            lower.contains("racing") -> gamingTipsFor(GameCategory.RACING)
            lower.contains("time") -> "Local system time is ${java.text.SimpleDateFormat("hh:mm a, EEE MMM d", Locale.getDefault()).format(java.util.Date())}."
            else -> {
                if (speaker == Speaker.JARVIS) {
                    "[Offline Mode] Ready, $preferredAddress. Cloud Gemini requires internet, but I can still launch apps, set reminders, read responses aloud, edit local videos, and run saved gaming strategies."
                } else {
                    "[Offline Mode] Hi $preferredAddress! We're offline right now so Gemini cloud chat is paused, but I can still tell jokes, manage reminders, or open your favorite apps!"
                }
            }
        }
        return speaker to reply
    }

    fun gamingTipsFor(category: GameCategory): String = when (category) {
        GameCategory.MINECRAFT ->
            "Minecraft Strategy: Carry a water bucket on hotbar slot 9 for MLG drops & lava safety, branch-mine at Y=-58 for diamonds, and place torches on the left side when cave exploring so right-side torches always guide you out."
        GameCategory.HORROR ->
            "Horror Strategy: Lower ambient music slightly and raise SFX cues, keep one escape route memorized before picking up key items, and preserve sprint stamina for sudden chase triggers."
        GameCategory.SURVIVAL ->
            "Survival Strategy: Secure renewable water and shelter before night one, craft duplicate backup tools before dangerous raids, and organize chests by crafting tier."
        GameCategory.PVP ->
            "PvP Strategy: Keep crosshair at head-level along common peek angles, never reload in open sightlines, and pair utility (smoke/flash) with rotation instead of dry-peeking."
        GameCategory.RACING ->
            "Racing Strategy: Brake in a straight line before turn-in, clip the inner apex smoothly, and trigger nitro on corner exits onto long straights rather than mid-drift."
        GameCategory.ADVENTURE ->
            "Adventure Strategy: Mark side puzzles with map pins, upgrade core traversal abilities early, and read item lore hints before brute-forcing locked gates."
        GameCategory.ACTION ->
            "Action Strategy: Watch enemy shoulder/weapon wind-ups rather than health bars, cancel long combos into dodges when outnumbered, and weave crowd-control between heavy finishers."
        GameCategory.FUNNY_CHALLENGE ->
            "Challenge & Co-op Tips: Establish clear rules before starting, record reaction audio on a separate rhythm, and mark timestamps immediately after hilarious fails for fast cuts in Studio."
    }
}
