package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.core.DeviceCapabilities
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.SkillModuleEntity
import com.example.data.local.UserPreferencesState
import com.example.data.model.AiEditSuggestion
import com.example.data.model.Speaker
import com.example.data.model.VideoStylePreset
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json

sealed interface AiResponseChunk {
    data class Delta(val accumulatedText: String) : AiResponseChunk
    data class Completed(val finalText: String, val usedModel: String) : AiResponseChunk
    data class Error(val message: String, val isOfflineOrUnavailable: Boolean) : AiResponseChunk
}

interface AiBrainProvider {
    fun streamReply(
        speaker: Speaker,
        userPrompt: String,
        historyContext: List<Pair<Speaker, String>>,
        prefs: UserPreferencesState,
        memories: List<MemoryEntryEntity>,
        skills: List<SkillModuleEntity>,
        extraInstruction: String = ""
    ): Flow<AiResponseChunk>

    suspend fun analyzeCameraScene(
        bitmap: Bitmap,
        prompt: String,
        speaker: Speaker,
        prefs: UserPreferencesState
    ): Result<String>

    suspend fun suggestVideoEdits(
        sampleFrames: List<Bitmap>,
        stylePreset: VideoStylePreset,
        clipSummaries: String,
        prefs: UserPreferencesState
    ): Result<AiEditSuggestion>
}

class FirebaseJarvisAiProvider(
    private val context: Context
) : AiBrainProvider {

    companion object {
        private const val TAG = "JarvisAiEngine"
        private const val TIMEOUT_MS = 45_000L
    }

    private val jsonParser = Json { ignoreUnknownKeys = true }

    // Lazily instantiated per model + system prompt signature
    private val modelCache = mutableMapOf<String, GenerativeModel>()

    private fun getOrCreateTextModel(modelId: String, systemPrompt: String): GenerativeModel {
        val cacheKey = "$modelId::${systemPrompt.hashCode()}"
        return modelCache.getOrPut(cacheKey) {
            Firebase.ai.generativeModel(
                modelName = modelId,
                systemInstruction = content { text(systemPrompt) }
            )
        }
    }

    private fun buildSystemInstruction(
        speaker: Speaker,
        prefs: UserPreferencesState,
        memories: List<MemoryEntryEntity>,
        skills: List<SkillModuleEntity>,
        extraInstruction: String
    ): String {
        val addressName = if (prefs.groupModeEnabled) prefs.groupTitle else prefs.privateName
        val persona = if (speaker == Speaker.JARVIS) {
            """
            You are JARVIS, the male futuristic AI assistant in JARVIS Feather.
            Personality: Intelligent, calm, analytical, composed, helpful, occasionally dryly humorous (${prefs.jarvisToneStyle}).
            Address the user naturally as "$addressName" when appropriate. Keep responses crisp, accurate, and practical for mobile voice/reading.
            """.trimIndent()
        } else {
            """
            You are ROSE, the female futuristic AI assistant in JARVIS Feather.
            Personality: Friendly, cheerful, caring, playful, witty, expressive, lightly teasing in a warm respectful way (${prefs.roseToneStyle}).
            Address the user naturally as "$addressName" when appropriate. Be encouraging without fostering unhealthy emotional dependency; respect real-world relationships. If the user wants a serious talk, match their serious tone without forcing jokes.
            """.trimIndent()
        }

        val memoryBlock = if (prefs.memoryEnabled && memories.isNotEmpty()) {
            "\nUser-approved preferences & memory:\n" + memories.joinToString("\n") { "- ${it.category}: ${it.key} = ${it.value}" }
        } else ""

        val skillBlock = if (skills.isNotEmpty()) {
            "\nActive verified skill modules:\n" + skills.joinToString("\n") { "- ${it.name}: ${it.systemPromptPatch}" }
        } else ""

        val safetyBlock = """
            Honesty rules:
            - Never pretend an offline action used cloud AI, and never invent capabilities you did not actually execute.
            - Never claim a future Gemini model (like Gemini 5+) is available unless verified.
            - Respect Android privacy and security boundaries.
        """.trimIndent()

        return listOf(persona, memoryBlock, skillBlock, safetyBlock, extraInstruction)
            .filter { it.isNotBlank() }
            .joinToString("\n\n")
    }

    override fun streamReply(
        speaker: Speaker,
        userPrompt: String,
        historyContext: List<Pair<Speaker, String>>,
        prefs: UserPreferencesState,
        memories: List<MemoryEntryEntity>,
        skills: List<SkillModuleEntity>,
        extraInstruction: String
    ): Flow<AiResponseChunk> = flow {
        if (!prefs.onlineModeEnabled) {
            emit(AiResponseChunk.Error("Online AI mode is switched off in Settings.", isOfflineOrUnavailable = true))
            return@flow
        }
        if (!DeviceCapabilities.isNetworkAvailable(context)) {
            emit(AiResponseChunk.Error("No internet connection detected.", isOfflineOrUnavailable = true))
            return@flow
        }

        val sysPrompt = buildSystemInstruction(speaker, prefs, memories, skills, extraInstruction)
        val contextTranscript = historyContext.takeLast(8).joinToString("\n") { (sp, msg) ->
            "${sp.label}: $msg"
        }
        val fullPrompt = if (contextTranscript.isNotBlank()) {
            "Recent conversation:\n$contextTranscript\n\nLatest user message:\n$userPrompt"
        } else {
            userPrompt
        }

        val primaryId = prefs.activeTextModel
        val fallbackId = prefs.fallbackTextModel

        val firstResult = tryStreamModel(primaryId, sysPrompt, fullPrompt) { delta ->
            emit(AiResponseChunk.Delta(delta))
        }
        if (firstResult != null) {
            emit(firstResult)
            return@flow
        }

        if (fallbackId.isNotBlank() && fallbackId != primaryId) {
            Log.w(TAG, "Primary model $primaryId failed; attempting fallback $fallbackId")
            val fallbackResult = tryStreamModel(fallbackId, sysPrompt, fullPrompt) { delta ->
                emit(AiResponseChunk.Delta(delta))
            }
            if (fallbackResult != null) {
                emit(fallbackResult)
                return@flow
            }
        }

        emit(AiResponseChunk.Error("Both primary ($primaryId) and fallback ($fallbackId) models could not respond right now.", isOfflineOrUnavailable = false))
    }

    private suspend fun tryStreamModel(
        modelId: String,
        sysPrompt: String,
        prompt: String,
        onDelta: suspend (String) -> Unit
    ): AiResponseChunk? {
        val sb = StringBuilder()
        return try {
            val model = getOrCreateTextModel(modelId, sysPrompt)
            withTimeout(TIMEOUT_MS) {
                model.generateContentStream(prompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        sb.append(piece)
                        onDelta(sb.toString())
                    }
                }
            }
            val result = sb.toString().trim()
            if (result.isNotEmpty()) {
                AiResponseChunk.Completed(result, modelId)
            } else {
                null
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Stream timed out for $modelId", e)
            AiResponseChunk.Error("Request timed out after 45s on $modelId.", isOfflineOrUnavailable = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Stream failed for $modelId", e)
            null
        }
    }

    override suspend fun analyzeCameraScene(
        bitmap: Bitmap,
        prompt: String,
        speaker: Speaker,
        prefs: UserPreferencesState
    ): Result<String> {
        if (!prefs.onlineModeEnabled || !DeviceCapabilities.isNetworkAvailable(context)) {
            return Result.failure(IllegalStateException("Camera AI vision requires Online Mode and an internet connection."))
        }
        return try {
            val model = getOrCreateTextModel(
                prefs.activeTextModel,
                "You are ${speaker.label}, analyzing a user-authorized live camera frame concisely and accurately. Never invent details not visible in the frame."
            )
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        image(bitmap)
                        text(prompt.ifBlank { "Describe what is visible in this camera frame and offer helpful next steps." })
                    }
                )
            }
            val text = response.text?.trim()
            if (!text.isNullOrEmpty()) Result.success(text)
            else Result.failure(IllegalStateException("Vision model returned empty output."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Camera analysis failed", e)
            Result.failure(e)
        }
    }

    override suspend fun suggestVideoEdits(
        sampleFrames: List<Bitmap>,
        stylePreset: VideoStylePreset,
        clipSummaries: String,
        prefs: UserPreferencesState
    ): Result<AiEditSuggestion> {
        if (!prefs.onlineModeEnabled || !DeviceCapabilities.isNetworkAvailable(context)) {
            return Result.failure(IllegalStateException("AI Video Director requires Online Mode and internet connectivity."))
        }

        val schema = Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Short overview of recommended edit"),
                "recommendedStyle" to Schema.string(description = "Recommended preset style name"),
                "cutRecommendations" to Schema.array(items = Schema.string(), description = "Timestamped or pacing cut suggestions"),
                "musicMood" to Schema.string(description = "Recommended background music vibe"),
                "soundEffects" to Schema.array(items = Schema.string(), description = "Suggested sound effects"),
                "transitions" to Schema.array(items = Schema.string(), description = "Recommended transitions"),
                "suggestedSubtitles" to Schema.array(items = Schema.string(), description = "Short punchy subtitle lines"),
                "cinematicEffect" to Schema.string(description = "Color/effect recommendation"),
                "suggestedSpeed" to Schema.double(description = "Suggested playback multiplier between 0.75 and 1.5")
            )
        )

        return try {
            val structuredModel by lazy {
                Firebase.ai.generativeModel(
                    modelName = prefs.activeTextModel,
                    generationConfig = generationConfig {
                        responseMimeType = "application/json"
                        responseSchema = schema
                    }
                )
            }
            val response = withTimeout(TIMEOUT_MS) {
                structuredModel.generateContent(
                    content {
                        sampleFrames.take(4).forEach { frame -> image(frame) }
                        text(
                            """
                            Analyze these sampled frames and clip timeline for a ${stylePreset.label} video (${stylePreset.tagline}).
                            Timeline info: $clipSummaries
                            Suggest practical, exciting cuts, music mood, sound effects, transitions, subtitles, color/cinematic effect, and pacing speed.
                            """.trimIndent()
                        )
                    }
                )
            }
            val rawJson = response.text ?: error("AI Video Director returned empty JSON.")
            val parsed = jsonParser.decodeFromString<AiEditSuggestion>(rawJson)
            Result.success(parsed)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI video analysis failed", e)
            Result.failure(e)
        }
    }
}
