package com.example.ai

import android.content.Context
import android.util.Log
import com.example.core.DeviceCapabilities
import com.example.data.model.AiModelSpec
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

data class ModelAvailabilityResult(
    val modelId: String,
    val isAvailable: Boolean,
    val latencyMs: Long,
    val message: String
)

object AiModelRegistry {
    private const val TAG = "AiModelRegistry"

    val verifiedModels: List<AiModelSpec> = listOf(
        AiModelSpec(
            id = "gemini-3.8-flash",
            displayName = "Gemini 3.8 Flash",
            tier = "Primary Default",
            description = "Balanced frontier-class speed & reasoning for JARVIS and ROSE conversations, vision, and video editing analysis.",
            supportsMultimodal = true,
            supportsLiveVoiceNote = "Uses Android SpeechRecognizer + TTS pipeline; evaluate Gemini Live API separately from text models.",
            billingRequired = false,
            isFallbackCapable = true
        ),
        AiModelSpec(
            id = "gemini-3.5-flash-lite",
            displayName = "Gemini 3.5 Flash-Lite",
            tier = "Fast Fallback / Low Bandwidth",
            description = "Ultra-low latency model ideal for quick replies, reminders, and fallback when primary model is throttled.",
            supportsMultimodal = true,
            supportsLiveVoiceNote = "Standard streaming text/multimodal model (not a Live API audio socket).",
            billingRequired = false,
            isFallbackCapable = true
        ),
        AiModelSpec(
            id = "gemini-4-argon",
            displayName = "Gemini 4 Argon",
            tier = "Deep Reasoning (Blaze)",
            description = "High-capability reasoning model for complex coding, strategy, and multi-step planning (requires Blaze plan).",
            supportsMultimodal = true,
            supportsLiveVoiceNote = "Reasoning model; requires separate Live audio evaluation.",
            billingRequired = true,
            isFallbackCapable = false
        ),
        AiModelSpec(
            id = "gemini-3.1-flash-tts-preview",
            displayName = "Gemini 3.1 Flash TTS (Preview)",
            tier = "Speech / Audio Reference",
            description = "Official low-latency cloud speech synthesis reference model. Text reasoning stays on Flash/Argon.",
            supportsMultimodal = false,
            supportsLiveVoiceNote = "Audio generation model; incompatible as a general text chat model.",
            billingRequired = false,
            isFallbackCapable = false
        )
    )

    fun findModel(id: String): AiModelSpec {
        return verifiedModels.firstOrNull { it.id == id } ?: verifiedModels.first()
    }

    suspend fun checkModelAvailability(context: Context, modelId: String): ModelAvailabilityResult {
        if (!DeviceCapabilities.isNetworkAvailable(context)) {
            return ModelAvailabilityResult(
                modelId = modelId,
                isAvailable = false,
                latencyMs = 0L,
                message = "Device is offline. Cloud Gemini models require an active internet connection."
            )
        }
        val spec = verifiedModels.firstOrNull { it.id == modelId }
        if (spec != null && modelId == "gemini-3.1-flash-tts-preview") {
            return ModelAvailabilityResult(
                modelId = modelId,
                isAvailable = false,
                latencyMs = 0L,
                message = "Audio TTS preview model cannot replace the text reasoning model; select a Flash or Argon text model."
            )
        }

        val start = System.currentTimeMillis()
        return try {
            withTimeout(15_000L) {
                val model = Firebase.ai.generativeModel(modelName = modelId)
                val response = model.generateContent("Reply with strictly the word READY.")
                val elapsed = System.currentTimeMillis() - start
                val reply = response.text.orEmpty().trim()
                if (reply.isNotEmpty()) {
                    ModelAvailabilityResult(
                        modelId = modelId,
                        isAvailable = true,
                        latencyMs = elapsed,
                        message = "Verified online (${elapsed}ms): $reply"
                    )
                } else {
                    ModelAvailabilityResult(
                        modelId = modelId,
                        isAvailable = false,
                        latencyMs = elapsed,
                        message = "Model responded with empty payload."
                    )
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Availability check failed for $modelId", e)
            ModelAvailabilityResult(
                modelId = modelId,
                isAvailable = false,
                latencyMs = System.currentTimeMillis() - start,
                message = e.localizedMessage ?: "Model unavailable or App Check / billing check failed."
            )
        }
    }

    suspend fun checkTrustedRegistry(registryUrl: String): Result<List<AiModelSpec>> =
        withContext(Dispatchers.IO) {
            if (registryUrl.isBlank()) {
                return@withContext Result.success(verifiedModels)
            }
            if (!registryUrl.startsWith("https://")) {
                return@withContext Result.failure(IllegalArgumentException("Registry URL must use HTTPS."))
            }
            runCatching {
                val client = OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(10, TimeUnit.SECONDS)
                    .build()
                val req = Request.Builder().url(registryUrl).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        error("Registry HTTP ${resp.code}")
                    }
                    val body = resp.body?.string().orEmpty()
                    val array = JSONArray(body)
                    val list = mutableListOf<AiModelSpec>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val id = obj.getString("id")
                        if (id.startsWith("gemini-")) {
                            list.add(
                                AiModelSpec(
                                    id = id,
                                    displayName = obj.optString("displayName", id),
                                    tier = obj.optString("tier", "Verified Remote"),
                                    description = obj.optString("description", "Official verified Gemini model."),
                                    supportsMultimodal = obj.optBoolean("supportsMultimodal", true),
                                    supportsLiveVoiceNote = obj.optString("liveNote", "Verify Live compatibility separately."),
                                    billingRequired = obj.optBoolean("billingRequired", false),
                                    isFallbackCapable = obj.optBoolean("isFallbackCapable", true)
                                )
                            )
                        }
                    }
                    if (list.isEmpty()) verifiedModels else list
                }
            }
        }
}
