package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY isCompleted ASC, dueAtMillis ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isCompleted = 0 ORDER BY dueAtMillis ASC")
    suspend fun getPendingOnce(): List<ReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: ReminderEntity): Long

    @Update
    suspend fun update(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_entries ORDER BY updatedAtMillis DESC")
    fun observeAll(): Flow<List<MemoryEntryEntity>>

    @Query("SELECT * FROM memory_entries WHERE isApproved = 1")
    suspend fun getApprovedOnce(): List<MemoryEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: MemoryEntryEntity): Long

    @Update
    suspend fun update(entry: MemoryEntryEntity)

    @Query("DELETE FROM memory_entries WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversation_messages ORDER BY timestampMillis ASC LIMIT 120")
    fun observeRecent(): Flow<List<ConversationMessageEntity>>

    @Insert
    suspend fun insert(message: ConversationMessageEntity): Long

    @Query("DELETE FROM conversation_messages")
    suspend fun clearAll()
}

@Dao
interface SkillModuleDao {
    @Query("SELECT * FROM skill_modules ORDER BY name ASC")
    fun observeAll(): Flow<List<SkillModuleEntity>>

    @Query("SELECT * FROM skill_modules WHERE isEnabled = 1")
    suspend fun getEnabledOnce(): List<SkillModuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(modules: List<SkillModuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(module: SkillModuleEntity)
}

@Dao
interface ConfigSnapshotDao {
    @Query("SELECT * FROM config_snapshots ORDER BY createdAtMillis DESC LIMIT 20")
    fun observeSnapshots(): Flow<List<ConfigSnapshotEntity>>

    @Insert
    suspend fun insert(snapshot: ConfigSnapshotEntity): Long
}

@Dao
interface VideoProjectDao {
    @Query("SELECT * FROM video_projects ORDER BY updatedAtMillis DESC")
    fun observeAll(): Flow<List<VideoProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(project: VideoProjectEntity): Long

    @Query("DELETE FROM video_projects WHERE id = :id")
    suspend fun deleteById(id: Long)
}
