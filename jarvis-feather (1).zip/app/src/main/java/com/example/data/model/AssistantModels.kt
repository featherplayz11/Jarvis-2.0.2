package com.example.data.model

import kotlinx.serialization.Serializable

enum class AssistantMode(val displayName: String) {
    INACTIVE("Standby"),
    JARVIS_ONLY("JARVIS Active"),
    ROSE_ONLY("ROSE Active"),
    DUAL_MODE("Dual Active")
}

enum class Speaker(val label: String) {
    USER("You"),
    JARVIS("JARVIS"),
    ROSE("ROSE"),
    SYSTEM("System")
}

enum class GraphicsQuality(val label: String, val particleCount: Int, val ringCount: Int) {
    LOW("Low (3GB RAM / Saver)", particleCount = 10, ringCount = 2),
    BALANCED("Balanced", particleCount = 22, ringCount = 3),
    HIGH("High Holographic", particleCount = 40, ringCount = 4)
}

enum class VideoStylePreset(val label: String, val tagline: String, val defaultSpeed: Float, val colorGrade: ColorGradePreset) {
    MINECRAFT("Minecraft", "Crisp blocks, upbeat cuts & pop SFX", 1.0f, ColorGradePreset.VIVID),
    HORROR("Horror", "Cold shadows, tense pacing & dread", 0.9f, ColorGradePreset.HORROR_DARK),
    SURVIVAL("Survival", "Gritty contrast & tactical pacing", 1.0f, ColorGradePreset.CINEMATIC_TEAL),
    PVP("PvP", "Fast-cut highlights & velocity", 1.25f, ColorGradePreset.HIGH_CONTRAST),
    ACTION("Action", "Punchy color & kinetic transitions", 1.15f, ColorGradePreset.CINEMATIC_TEAL),
    RACING("Racing", "Motion energy & turbo pacing", 1.3f, ColorGradePreset.VIVID),
    ADVENTURE("Adventure", "Warm golden vistas & story flow", 1.0f, ColorGradePreset.WARM_GOLD),
    FUNNY("Funny Videos", "Snappy punchlines & bounce zooms", 1.1f, ColorGradePreset.VIVID),
    CHALLENGE("Challenge Videos", "Countdown hype & reaction cuts", 1.05f, ColorGradePreset.HIGH_CONTRAST)
}

enum class ColorGradePreset(val label: String, val contrast: Float, val saturation: Float) {
    NATURAL("Natural", 0f, 0f),
    VIVID("Vivid Pop", 0.22f, 35f),
    CINEMATIC_TEAL("Cyber Cyan", 0.25f, -10f),
    HORROR_DARK("Horror Shadow", 0.38f, -40f),
    WARM_GOLD("Warm Adventure", 0.15f, 20f),
    HIGH_CONTRAST("PvP Sharp", 0.42f, 15f)
}

enum class TransitionType(val label: String) {
    NONE("Hard Cut"),
    FADE_BLACK("Fade Through Black"),
    CYBER_FLASH("Hologram Flash"),
    ZOOM_SNAP("Kinetic Snap")
}

enum class ExportResolution(val label: String, val heightPx: Int, val defaultBitrateMbps: Int) {
    HD_720("720p HD", 720, 5),
    FHD_1080("1080p Full HD", 1080, 10),
    QHD_1440("1440p (HW Check)", 1440, 18),
    UHD_4K("4K UHD (HW Check)", 2160, 32)
}

enum class GameCategory(val label: String, val subtitle: String, val keywords: List<String>) {
    MINECRAFT("Minecraft", "Redstone, survival bases & Nether prep", listOf("minecraft", "mojang")),
    HORROR("Horror Games", "Audio cues, stamina & dark corridors", listOf("horror", "granny", "fnaf", "phasmo")),
    SURVIVAL("Survival Games", "Resource loops, crafting & shelter", listOf("survival", "ark", "rust", "dayz")),
    PVP("PvP Games", "Crosshair placement, cooldowns & positioning", listOf("bgmi", "pubg", "free fire", "cod", "valorant", "brawl")),
    RACING("Racing Games", "Apex braking, drift lines & nitro timing", listOf("asphalt", "racing", "kart", "forza")),
    ADVENTURE("Adventure Games", "Exploration, lore & puzzle pacing", listOf("genshin", "zelda", "adventure")),
    ACTION("Action Games", "Combo timing, dodge frames & boss reads", listOf("action", "devil", "shadow")),
    FUNNY_CHALLENGE("Funny & Challenges", "Co-op chaos, rulesets & highlights", listOf("stumble", "among", "fall", "roblox"))
}

@Serializable
data class VideoClipItem(
    val id: String,
    val uriString: String,
    val title: String,
    val durationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = durationMs,
    val speed: Float = 1.0f,
    val transitionAfter: TransitionType = TransitionType.NONE
)

@Serializable
data class AiEditSuggestion(
    val summary: String,
    val recommendedStyle: String,
    val cutRecommendations: List<String>,
    val musicMood: String,
    val soundEffects: List<String>,
    val transitions: List<String>,
    val suggestedSubtitles: List<String>,
    val cinematicEffect: String,
    val suggestedSpeed: Float = 1.0f
)

data class AiModelSpec(
    val id: String,
    val displayName: String,
    val tier: String,
    val description: String,
    val supportsMultimodal: Boolean,
    val supportsLiveVoiceNote: String,
    val billingRequired: Boolean,
    val isFallbackCapable: Boolean
)
