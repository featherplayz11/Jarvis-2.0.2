package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AssistantMode
import com.example.data.model.GraphicsQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_prefs")

data class UserPreferencesState(
    val assistantMode: AssistantMode = AssistantMode.INACTIVE,
    val privateName: String = "Feather",
    val groupModeEnabled: Boolean = false,
    val groupTitle: String = "Master",
    val activeTextModel: String = "gemini-3.8-flash",
    val fallbackTextModel: String = "gemini-3.5-flash-lite",
    val onlineModeEnabled: Boolean = true,
    val memoryEnabled: Boolean = true,
    val voiceTtsEnabled: Boolean = true,
    val jarvisPitch: Float = 0.88f,
    val rosePitch: Float = 1.18f,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.BALANCED,
    val batterySaverMode: Boolean = false,
    val reducedAnimationMode: Boolean = false,
    val lowResVideoPreview: Boolean = true,
    val backgroundWakeWordEnabled: Boolean = false,
    val floatingOverlayEnabled: Boolean = false,
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = true,
    val pinHash: String = "",
    val recoveryCodeHash: String = "",
    val approvedAppPackages: Set<String> = emptySet(),
    val restrictToApprovedApps: Boolean = false,
    val jarvisToneStyle: String = "Analytical & Calm",
    val roseToneStyle: String = "Cheerful & Playful",
    val updateManifestUrl: String = ""
)

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val PRIVATE_NAME = stringPreferencesKey("private_name")
        val GROUP_MODE = booleanPreferencesKey("group_mode")
        val GROUP_TITLE = stringPreferencesKey("group_title")
        val ACTIVE_TEXT_MODEL = stringPreferencesKey("active_text_model")
        val FALLBACK_TEXT_MODEL = stringPreferencesKey("fallback_text_model")
        val ONLINE_MODE = booleanPreferencesKey("online_mode")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val VOICE_TTS = booleanPreferencesKey("voice_tts")
        val JARVIS_PITCH = floatPreferencesKey("jarvis_pitch")
        val ROSE_PITCH = floatPreferencesKey("rose_pitch")
        val GRAPHICS_QUALITY = stringPreferencesKey("graphics_quality")
        val BATTERY_SAVER = booleanPreferencesKey("battery_saver")
        val REDUCED_ANIM = booleanPreferencesKey("reduced_anim")
        val LOW_RES_PREVIEW = booleanPreferencesKey("low_res_preview")
        val BG_WAKE_WORD = booleanPreferencesKey("bg_wake_word")
        val FLOATING_OVERLAY = booleanPreferencesKey("floating_overlay")
        val APP_LOCK = booleanPreferencesKey("app_lock")
        val BIOMETRIC = booleanPreferencesKey("biometric")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val RECOVERY_HASH = stringPreferencesKey("recovery_hash")
        val APPROVED_APPS = stringSetPreferencesKey("approved_apps")
        val RESTRICT_APPROVED = booleanPreferencesKey("restrict_approved")
        val JARVIS_TONE = stringPreferencesKey("jarvis_tone")
        val ROSE_TONE = stringPreferencesKey("rose_tone")
        val UPDATE_MANIFEST_URL = stringPreferencesKey("update_manifest_url")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.dataStore.data.map { prefs ->
        UserPreferencesState(
            assistantMode = AssistantMode.INACTIVE,
            privateName = prefs[Keys.PRIVATE_NAME] ?: "Feather",
            groupModeEnabled = prefs[Keys.GROUP_MODE] ?: false,
            groupTitle = prefs[Keys.GROUP_TITLE] ?: "Master",
            activeTextModel = prefs[Keys.ACTIVE_TEXT_MODEL] ?: "gemini-3.8-flash",
            fallbackTextModel = prefs[Keys.FALLBACK_TEXT_MODEL] ?: "gemini-3.5-flash-lite",
            onlineModeEnabled = prefs[Keys.ONLINE_MODE] ?: true,
            memoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
            voiceTtsEnabled = prefs[Keys.VOICE_TTS] ?: true,
            jarvisPitch = prefs[Keys.JARVIS_PITCH] ?: 0.88f,
            rosePitch = prefs[Keys.ROSE_PITCH] ?: 1.18f,
            graphicsQuality = prefs[Keys.GRAPHICS_QUALITY]?.let {
                runCatching { GraphicsQuality.valueOf(it) }.getOrNull()
            } ?: GraphicsQuality.BALANCED,
            batterySaverMode = prefs[Keys.BATTERY_SAVER] ?: false,
            reducedAnimationMode = prefs[Keys.REDUCED_ANIM] ?: false,
            lowResVideoPreview = prefs[Keys.LOW_RES_PREVIEW] ?: true,
            backgroundWakeWordEnabled = prefs[Keys.BG_WAKE_WORD] ?: false,
            floatingOverlayEnabled = prefs[Keys.FLOATING_OVERLAY] ?: false,
            appLockEnabled = prefs[Keys.APP_LOCK] ?: false,
            biometricEnabled = prefs[Keys.BIOMETRIC] ?: true,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            recoveryCodeHash = prefs[Keys.RECOVERY_HASH] ?: "",
            approvedAppPackages = prefs[Keys.APPROVED_APPS] ?: emptySet(),
            restrictToApprovedApps = prefs[Keys.RESTRICT_APPROVED] ?: false,
            jarvisToneStyle = prefs[Keys.JARVIS_TONE] ?: "Analytical & Calm",
            roseToneStyle = prefs[Keys.ROSE_TONE] ?: "Cheerful & Playful",
            updateManifestUrl = prefs[Keys.UPDATE_MANIFEST_URL] ?: ""
        )
    }

    suspend fun setAddressPreferences(privateName: String, groupMode: Boolean, groupTitle: String) {
        context.dataStore.edit {
            it[Keys.PRIVATE_NAME] = privateName.ifBlank { "Feather" }
            it[Keys.GROUP_MODE] = groupMode
            it[Keys.GROUP_TITLE] = groupTitle.ifBlank { "Master" }
        }
    }

    suspend fun setModelConfig(activeModel: String, fallbackModel: String) {
        context.dataStore.edit {
            it[Keys.ACTIVE_TEXT_MODEL] = activeModel
            it[Keys.FALLBACK_TEXT_MODEL] = fallbackModel
        }
    }

    suspend fun setOnlineMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ONLINE_MODE] = enabled }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    }

    suspend fun setVoiceSettings(ttsEnabled: Boolean, jarvisPitch: Float, rosePitch: Float) {
        context.dataStore.edit {
            it[Keys.VOICE_TTS] = ttsEnabled
            it[Keys.JARVIS_PITCH] = jarvisPitch
            it[Keys.ROSE_PITCH] = rosePitch
        }
    }

    suspend fun setPerformanceSettings(
        graphicsQuality: GraphicsQuality,
        batterySaver: Boolean,
        reducedAnimation: Boolean,
        lowResPreview: Boolean
    ) {
        context.dataStore.edit {
            it[Keys.GRAPHICS_QUALITY] = graphicsQuality.name
            it[Keys.BATTERY_SAVER] = batterySaver
            it[Keys.REDUCED_ANIM] = reducedAnimation
            it[Keys.LOW_RES_PREVIEW] = lowResPreview
        }
    }

    suspend fun setBackgroundWakeWord(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BG_WAKE_WORD] = enabled }
    }

    suspend fun setFloatingOverlay(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FLOATING_OVERLAY] = enabled }
    }

    suspend fun setSecurityConfig(
        appLockEnabled: Boolean,
        biometricEnabled: Boolean,
        pinRaw: String?,
        recoveryCodeRaw: String?
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.APP_LOCK] = appLockEnabled
            prefs[Keys.BIOMETRIC] = biometricEnabled
            if (!pinRaw.isNullOrBlank()) {
                prefs[Keys.PIN_HASH] = hashSecret(pinRaw)
            }
            if (!recoveryCodeRaw.isNullOrBlank()) {
                prefs[Keys.RECOVERY_HASH] = hashSecret(recoveryCodeRaw)
            }
        }
    }

    suspend fun toggleApprovedApp(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.APPROVED_APPS] ?: emptySet()
            prefs[Keys.APPROVED_APPS] = if (packageName in current) current - packageName else current + packageName
        }
    }

    suspend fun setRestrictToApprovedApps(restrict: Boolean) {
        context.dataStore.edit { it[Keys.RESTRICT_APPROVED] = restrict }
    }

    suspend fun setPersonalityTones(jarvisTone: String, roseTone: String) {
        context.dataStore.edit {
            it[Keys.JARVIS_TONE] = jarvisTone
            it[Keys.ROSE_TONE] = roseTone
        }
    }

    suspend fun setUpdateManifestUrl(url: String) {
        context.dataStore.edit { it[Keys.UPDATE_MANIFEST_URL] = url.trim() }
    }

    fun verifyPin(rawPin: String, storedHash: String): Boolean {
        return storedHash.isNotEmpty() && hashSecret(rawPin) == storedHash
    }

    fun verifyRecoveryCode(rawCode: String, storedHash: String): Boolean {
        return storedHash.isNotEmpty() && hashSecret(rawCode.trim().uppercase()) == storedHash
    }

    private fun hashSecret(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(("jarvis_feather_salt_v1:$input").toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
