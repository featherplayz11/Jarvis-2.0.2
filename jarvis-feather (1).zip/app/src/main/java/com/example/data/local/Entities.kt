package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val dueAtMillis: Long,
    val isCompleted: Boolean = false,
    val characterTag: String = "JARVIS",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory_entries")
data class MemoryEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val key: String,
    val value: String,
    val isApproved: Boolean = true,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "conversation_messages")
data class ConversationMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val speaker: String,
    val text: String,
    val mode: String,
    val isOffline: Boolean = false,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "skill_modules")
data class SkillModuleEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val category: String,
    val systemPromptPatch: String,
    val isEnabled: Boolean,
    val isVerifiedBuiltIn: Boolean = true,
    val version: String = "1.0",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "config_snapshots")
data class ConfigSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val snapshotJson: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "video_projects")
data class VideoProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val stylePreset: String,
    val clipsJson: String,
    val audioUriString: String? = null,
    val musicTitle: String = "None",
    val sfxTagsJson: String = "[]",
    val textOverlay: String = "",
    val subtitleText: String = "",
    val colorGrade: String = "NATURAL",
    val speedMultiplier: Float = 1.0f,
    val resolution: String = "HD_720",
    val bitrateMbps: Int = 5,
    val lastExportPath: String? = null,
    val updatedAtMillis: Long = System.currentTimeMillis()
)
