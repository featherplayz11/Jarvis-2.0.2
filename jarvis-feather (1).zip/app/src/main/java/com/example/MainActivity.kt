package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.configureAppCheck
import com.example.ui.JarvisViewModel
import com.example.ui.screens.AppLockOverlay
import com.example.ui.screens.AssistantHubScreen
import com.example.ui.screens.ControlPrivacyScreen
import com.example.ui.screens.SystemBrainScreen
import com.example.ui.screens.TasksGamingScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.theme.DeepVoidNavy
import com.example.ui.theme.HologramPanel
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisFeatherTheme
import com.example.ui.theme.MistBlue
import com.example.videoeditor.VideoEditorViewModel
import com.example.voice.WakeWordForegroundService
import kotlinx.serialization.Serializable

@Serializable object RouteAssistant
@Serializable object RouteStudio
@Serializable object RouteTasksGaming
@Serializable object RouteControl
@Serializable object RouteSystem

private data class NavTabItem(
    val route: Any,
    val label: String,
    val icon: ImageVector
)

class MainActivity : FragmentActivity() {

    private val jarvisVm: JarvisViewModel by viewModels()
    private val editorVm: VideoEditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory Step 1: Configure Firebase App Check with launch intent before any UI or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            JarvisFeatherTheme {
                JarvisFeatherRoot(
                    jarvisVm = jarvisVm,
                    editorVm = editorVm,
                    initialQuickListen = intent?.action == WakeWordForegroundService.ACTION_QUICK_LISTEN
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == WakeWordForegroundService.ACTION_QUICK_LISTEN) {
            jarvisVm.startVoiceListen()
        }
    }
}

@Composable
private fun JarvisFeatherRoot(
    jarvisVm: JarvisViewModel,
    editorVm: VideoEditorViewModel,
    initialQuickListen: Boolean
) {
    val navController = rememberNavController()
    val prefs by jarvisVm.prefs.collectAsStateWithLifecycle()
    val isUnlocked by jarvisVm.isAppUnlocked.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        jarvisVm.attachEditorNavigator {
            navController.navigate(RouteStudio) {
                launchSingleTop = true
            }
        }
        if (initialQuickListen) {
            jarvisVm.startVoiceListen()
        }
    }

    if (!isUnlocked && prefs.appLockEnabled) {
        AppLockOverlay(
            biometricEnabled = prefs.biometricEnabled,
            hasPinConfigured = prefs.pinHash.isNotEmpty(),
            onUnlockSuccess = { jarvisVm.unlockApp() },
            onVerifyPin = { jarvisVm.verifyPinAndUnlock(it) },
            onVerifyRecovery = { jarvisVm.verifyRecoveryAndResetLock(it) }
        )
        return
    }

    val tabs = listOf(
        NavTabItem(RouteAssistant, "Assistant", Icons.Default.AutoAwesome),
        NavTabItem(RouteStudio, "Studio", Icons.Default.MovieCreation),
        NavTabItem(RouteTasksGaming, "Tasks", Icons.Default.TaskAlt),
        NavTabItem(RouteControl, "Control", Icons.Default.Shield),
        NavTabItem(RouteSystem, "System", Icons.Default.Settings)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val isStudioFullscreen = currentDestination?.hasRoute<RouteStudio>() == true

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = DeepVoidNavy,
            bottomBar = {
                if (!useRail && !isStudioFullscreen) {
                    NavigationBar(containerColor = HologramPanel) {
                        tabs.forEach { tab ->
                            val selected = currentDestination?.hasRoute(tab.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = JarvisCyan,
                                    selectedTextColor = JarvisCyan,
                                    indicatorColor = JarvisCyan.copy(alpha = 0.16f),
                                    unselectedIconColor = MistBlue,
                                    unselectedTextColor = MistBlue
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && !isStudioFullscreen) {
                    NavigationRail(containerColor = HologramPanel) {
                        tabs.forEach { tab ->
                            val selected = currentDestination?.hasRoute(tab.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = JarvisCyan,
                                    selectedTextColor = JarvisCyan,
                                    indicatorColor = JarvisCyan.copy(alpha = 0.16f),
                                    unselectedIconColor = MistBlue,
                                    unselectedTextColor = MistBlue
                                )
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = RouteAssistant,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<RouteAssistant> {
                        AssistantHubScreen(
                            viewModel = jarvisVm,
                            onOpenStudio = {
                                navController.navigate(RouteStudio) { launchSingleTop = true }
                            }
                        )
                    }
                    composable<RouteStudio> {
                        VideoStudioScreen(
                            editorVm = editorVm,
                            onBack = { navController.popBackStack() }
                        )
                    }
                    composable<RouteTasksGaming> {
                        TasksGamingScreen(
                            viewModel = jarvisVm,
                            onNavigateToAssistant = {
                                navController.navigate(RouteAssistant) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                    composable<RouteControl> {
                        ControlPrivacyScreen(viewModel = jarvisVm)
                    }
                    composable<RouteSystem> {
                        SystemBrainScreen(viewModel = jarvisVm)
                    }
                }
            }
        }
    }
}
