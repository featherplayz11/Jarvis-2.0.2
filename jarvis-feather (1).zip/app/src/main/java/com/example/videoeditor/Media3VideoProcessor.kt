package com.example.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.example.data.model.ColorGradePreset
import com.example.data.model.ExportResolution
import com.example.data.model.TransitionType
import com.example.data.model.VideoClipItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface VideoExportState {
    data object Idle : VideoExportState
    data class Exporting(val progressPercent: Int) : VideoExportState
    data class Completed(val outputFile: File) : VideoExportState
    data class Failed(val message: String) : VideoExportState
}

class Media3VideoProcessor(private val context: Context) {

    private val _exportState = MutableStateFlow<VideoExportState>(VideoExportState.Idle)
    val exportState: StateFlow<VideoExportState> = _exportState.asStateFlow()

    private var activeTransformer: Transformer? = null
    private var progressJob: Job? = null
    private val mainScope = CoroutineScope(Dispatchers.Main)

    suspend fun inspectClipDurationMs(uri: Uri): Long = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationStr?.toLongOrNull()?.coerceAtLeast(1000L) ?: 10_000L
        } catch (_: Exception) {
            10_000L
        } finally {
            runCatching { retriever.release() }
        }
    }

    suspend fun extractSampleFrames(uri: Uri, count: Int = 3, maxDimension: Int = 384): List<Bitmap> =
        withContext(Dispatchers.IO) {
            val frames = mutableListOf<Bitmap>()
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 5000L
                val stepUs = ((durationMs * 1000L) / (count + 1)).coerceAtLeast(250_000L)
                for (i in 1..count) {
                    val raw = retriever.getFrameAtTime(stepUs * i, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (raw != null) {
                        val scale = minOf(maxDimension.toFloat() / raw.width, maxDimension.toFloat() / raw.height, 1f)
                        val scaled = if (scale < 1f) {
                            Bitmap.createScaledBitmap(
                                raw,
                                (raw.width * scale).toInt().coerceAtLeast(64),
                                (raw.height * scale).toInt().coerceAtLeast(64),
                                true
                            ).also { raw.recycle() }
                        } else raw
                        frames.add(scaled)
                    }
                }
            } catch (_: Exception) {
                // Return any already-extracted frames safely
            } finally {
                runCatching { retriever.release() }
            }
            frames
        }

    @OptIn(UnstableApi::class)
    fun startExport(
        clips: List<VideoClipItem>,
        audioTrackUri: Uri?,
        colorGrade: ColorGradePreset,
        textOverlay: String,
        subtitleText: String,
        resolution: ExportResolution,
        bitrateMbps: Int,
        lowMemoryMode: Boolean
    ) {
        if (clips.isEmpty()) {
            _exportState.value = VideoExportState.Failed("Import at least one video clip before exporting.")
            return
        }

        val exportDir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "JARVIS_Feather"
        ).apply { mkdirs() }
        val outputFile = File(exportDir, "jf_export_${System.currentTimeMillis()}.mp4")

        val safeHeight = if (lowMemoryMode && resolution.heightPx > 1080) 1080 else resolution.heightPx
        val targetBitrate = (bitrateMbps.coerceIn(2, 35)) * 1_000_000

        val editedItems = clips.mapIndexed { idx, clip ->
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(clip.uriString))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.trimStartMs.coerceAtLeast(0L))
                        .setEndPositionMs(clip.trimEndMs.coerceAtLeast(clip.trimStartMs + 500L))
                        .build()
                )
                .build()

            val videoEffects = mutableListOf<Effect>()
            val audioProcessors = mutableListOf<AudioProcessor>()

            if (clip.speed != 1.0f) {
                videoEffects.add(SpeedChangeEffect(clip.speed))
                val sonic = SonicAudioProcessor().apply { setSpeed(clip.speed) }
                audioProcessors.add(sonic)
            }

            if (colorGrade != ColorGradePreset.NATURAL) {
                if (colorGrade.contrast != 0f) {
                    videoEffects.add(Contrast(colorGrade.contrast))
                }
                if (colorGrade.saturation != 0f) {
                    videoEffects.add(
                        HslAdjustment.Builder()
                            .adjustSaturation(colorGrade.saturation)
                            .build()
                    )
                }
            }

            val combinedOverlay = listOfNotNull(
                textOverlay.takeIf { it.isNotBlank() && idx == 0 },
                subtitleText.takeIf { it.isNotBlank() }
            ).joinToString("\n")

            if (combinedOverlay.isNotBlank()) {
                val spannable = SpannableString(combinedOverlay).apply {
                    setSpan(
                        ForegroundColorSpan(android.graphics.Color.CYAN),
                        0,
                        length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                val overlay = TextOverlay.createStaticTextOverlay(spannable)
                videoEffects.add(OverlayEffect(listOf(overlay)))
            }

            if (clip.transitionAfter == TransitionType.CYBER_FLASH && idx < clips.lastIndex) {
                videoEffects.add(Contrast(0.12f))
            }

            videoEffects.add(Presentation.createForHeight(safeHeight))

            EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(audioProcessors, videoEffects))
                .build()
        }

        val sequences = mutableListOf<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(editedItems))

        if (audioTrackUri != null) {
            val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(audioTrackUri)).build()
            sequences.add(EditedMediaItemSequence.Builder(listOf(audioItem)).setIsLooping(true).build())
        }

        val composition = Composition.Builder(sequences).build()

        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder()
                    .setBitrate(targetBitrate)
                    .build()
            )
            .build()

        val transformer = Transformer.Builder(context)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopProgressPolling()
                    _exportState.value = VideoExportState.Completed(outputFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopProgressPolling()
                    if (outputFile.exists()) outputFile.delete()
                    _exportState.value = VideoExportState.Failed(
                        exportException.localizedMessage ?: "Media3 export failed on this hardware encoder."
                    )
                }
            })
            .build()

        activeTransformer = transformer
        _exportState.value = VideoExportState.Exporting(0)
        transformer.start(composition, outputFile.absolutePath)
        startProgressPolling(transformer)
    }

    @OptIn(UnstableApi::class)
    private fun startProgressPolling(transformer: Transformer) {
        progressJob?.cancel()
        progressJob = mainScope.launch {
            val holder = ProgressHolder()
            while (isActive) {
                val state = transformer.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    _exportState.value = VideoExportState.Exporting(holder.progress.coerceIn(0, 99))
                }
                delay(250L)
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
        activeTransformer = null
    }

    @OptIn(UnstableApi::class)
    fun cancelExport() {
        activeTransformer?.cancel()
        stopProgressPolling()
        _exportState.value = VideoExportState.Idle
    }

    fun resetExportState() {
        _exportState.value = VideoExportState.Idle
    }
}
