package com.example.videoeditor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.FirebaseJarvisAiProvider
import com.example.core.DeviceCapabilities
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.VideoProjectEntity
import com.example.data.model.AiEditSuggestion
import com.example.data.model.ColorGradePreset
import com.example.data.model.ExportResolution
import com.example.data.model.TransitionType
import com.example.data.model.VideoClipItem
import com.example.data.model.VideoStylePreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

data class EditorTimelineSnapshot(
    val projectName: String = "Untitled Edit",
    val stylePreset: VideoStylePreset = VideoStylePreset.MINECRAFT,
    val clips: List<VideoClipItem> = emptyList(),
    val selectedClipIndex: Int = 0,
    val audioUriString: String? = null,
    val musicTitle: String = "None",
    val sfxTags: List<String> = emptyList(),
    val textOverlay: String = "",
    val subtitleText: String = "",
    val colorGrade: ColorGradePreset = ColorGradePreset.NATURAL,
    val resolution: ExportResolution = ExportResolution.HD_720,
    val bitrateMbps: Int = 5
)

class VideoEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val projectDao = db.videoProjectDao()
    private val prefsRepo = UserPreferencesRepository(application)
    private val aiProvider = FirebaseJarvisAiProvider(application)
    val processor = Media3VideoProcessor(application)

    private val json = Json { ignoreUnknownKeys = true }

    val savedProjects: StateFlow<List<VideoProjectEntity>> = projectDao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val exportState: StateFlow<VideoExportState> = processor.exportState

    private val _state = MutableStateFlow(EditorTimelineSnapshot())
    val state: StateFlow<EditorTimelineSnapshot> = _state.asStateFlow()

    private val undoStack = ArrayDeque<EditorTimelineSnapshot>()
    private val redoStack = ArrayDeque<EditorTimelineSnapshot>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _aiSuggestion = MutableStateFlow<AiEditSuggestion?>(null)
    val aiSuggestion: StateFlow<AiEditSuggestion?> = _aiSuggestion.asStateFlow()

    private val _isAnalyzingAi = MutableStateFlow(false)
    val isAnalyzingAi: StateFlow<Boolean> = _isAnalyzingAi.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    val maxHardwareHeight: Int = DeviceCapabilities.inspect(application).maxSupportedVideoHeight

    private fun pushSnapshot(newSnapshot: EditorTimelineSnapshot) {
        undoStack.addLast(_state.value)
        if (undoStack.size > 25) undoStack.removeFirst()
        redoStack.clear()
        _state.value = newSnapshot
        syncUndoFlags()
    }

    private fun syncUndoFlags() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(_state.value)
        _state.value = undoStack.removeLast()
        syncUndoFlags()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(_state.value)
        _state.value = redoStack.removeLast()
        syncUndoFlags()
    }

    fun importVideoUri(uri: Uri, label: String = "Clip") {
        viewModelScope.launch {
            val durationMs = processor.inspectClipDurationMs(uri)
            val newClip = VideoClipItem(
                id = UUID.randomUUID().toString(),
                uriString = uri.toString(),
                title = "$label ${_state.value.clips.size + 1}",
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs
            )
            val updated = _state.value.clips + newClip
            pushSnapshot(
                _state.value.copy(
                    clips = updated,
                    selectedClipIndex = updated.lastIndex
                )
            )
            _statusBanner.value = "Imported ${newClip.title} (${durationMs / 1000}s). Original file stays untouched."
        }
    }

    fun importBackgroundAudio(uri: Uri, name: String) {
        pushSnapshot(
            _state.value.copy(
                audioUriString = uri.toString(),
                musicTitle = name
            )
        )
        _statusBanner.value = "Attached music track: $name"
    }

    fun selectClip(index: Int) {
        if (index in _state.value.clips.indices) {
            _state.value = _state.value.copy(selectedClipIndex = index)
        }
    }

    fun updateSelectedTrim(startMs: Long, endMs: Long) {
        val cur = _state.value
        val clip = cur.clips.getOrNull(cur.selectedClipIndex) ?: return
        val safeStart = startMs.coerceIn(0L, (clip.durationMs - 500L).coerceAtLeast(0L))
        val safeEnd = endMs.coerceIn(safeStart + 500L, clip.durationMs)
        val updated = cur.clips.toMutableList().apply {
            this[cur.selectedClipIndex] = clip.copy(trimStartMs = safeStart, trimEndMs = safeEnd)
        }
        pushSnapshot(cur.copy(clips = updated))
    }

    fun splitSelectedClipAtMidpoint() {
        val cur = _state.value
        val idx = cur.selectedClipIndex
        val clip = cur.clips.getOrNull(idx) ?: return
        val span = clip.trimEndMs - clip.trimStartMs
        if (span < 1200L) {
            _statusBanner.value = "Clip segment too short to split (minimum 1.2s)."
            return
        }
        val mid = clip.trimStartMs + span / 2L
        val firstHalf = clip.copy(
            title = "${clip.title} A",
            trimEndMs = mid
        )
        val secondHalf = clip.copy(
            id = UUID.randomUUID().toString(),
            title = "${clip.title} B",
            trimStartMs = mid
        )
        val updated = cur.clips.toMutableList().apply {
            removeAt(idx)
            add(idx, firstHalf)
            add(idx + 1, secondHalf)
        }
        pushSnapshot(cur.copy(clips = updated, selectedClipIndex = idx))
        _statusBanner.value = "Split ${clip.title} cleanly into two timeline segments."
    }

    fun moveSelectedClipLeft() {
        val cur = _state.value
        val idx = cur.selectedClipIndex
        if (idx <= 0 || idx >= cur.clips.size) return
        val updated = cur.clips.toMutableList().apply {
            val item = removeAt(idx)
            add(idx - 1, item)
        }
        pushSnapshot(cur.copy(clips = updated, selectedClipIndex = idx - 1))
    }

    fun removeSelectedClip() {
        val cur = _state.value
        val idx = cur.selectedClipIndex
        if (idx !in cur.clips.indices) return
        val updated = cur.clips.toMutableList().apply { removeAt(idx) }
        pushSnapshot(cur.copy(clips = updated, selectedClipIndex = (idx - 1).coerceAtLeast(0)))
    }

    fun setSelectedClipSpeed(speed: Float) {
        val cur = _state.value
        val idx = cur.selectedClipIndex
        val clip = cur.clips.getOrNull(idx) ?: return
        val updated = cur.clips.toMutableList().apply {
            this[idx] = clip.copy(speed = speed.coerceIn(0.5f, 2.0f))
        }
        pushSnapshot(cur.copy(clips = updated))
    }

    fun setSelectedTransition(transition: TransitionType) {
        val cur = _state.value
        val idx = cur.selectedClipIndex
        val clip = cur.clips.getOrNull(idx) ?: return
        val updated = cur.clips.toMutableList().apply {
            this[idx] = clip.copy(transitionAfter = transition)
        }
        pushSnapshot(cur.copy(clips = updated))
    }

    fun applyStylePreset(preset: VideoStylePreset) {
        val cur = _state.value
        val updatedClips = cur.clips.map { it.copy(speed = preset.defaultSpeed) }
        pushSnapshot(
            cur.copy(
                stylePreset = preset,
                colorGrade = preset.colorGrade,
                clips = updatedClips
            )
        )
        _statusBanner.value = "Applied ${preset.label} preset (${preset.colorGrade.label}, ${preset.defaultSpeed}x)."
    }

    fun setColorGrade(grade: ColorGradePreset) {
        pushSnapshot(_state.value.copy(colorGrade = grade))
    }

    fun setTextAndSubtitles(titleOverlay: String, subtitles: String) {
        pushSnapshot(_state.value.copy(textOverlay = titleOverlay, subtitleText = subtitles))
    }

    fun toggleSfxTag(tag: String) {
        val cur = _state.value
        val next = if (tag in cur.sfxTags) cur.sfxTags - tag else cur.sfxTags + tag
        pushSnapshot(cur.copy(sfxTags = next))
    }

    fun setExportConfig(resolution: ExportResolution, bitrateMbps: Int) {
        _state.value = _state.value.copy(resolution = resolution, bitrateMbps = bitrateMbps)
    }

    fun setProjectName(name: String) {
        _state.value = _state.value.copy(projectName = name)
    }

    fun saveProject() {
        viewModelScope.launch {
            val s = _state.value
            val entity = VideoProjectEntity(
                name = s.projectName.ifBlank { "Untitled Edit" },
                stylePreset = s.stylePreset.name,
                clipsJson = json.encodeToString(s.clips),
                audioUriString = s.audioUriString,
                musicTitle = s.musicTitle,
                sfxTagsJson = json.encodeToString(s.sfxTags),
                textOverlay = s.textOverlay,
                subtitleText = s.subtitleText,
                colorGrade = s.colorGrade.name,
                resolution = s.resolution.name,
                bitrateMbps = s.bitrateMbps
            )
            projectDao.upsert(entity)
            _statusBanner.value = "Project \"${entity.name}\" saved locally."
        }
    }

    fun loadProject(entity: VideoProjectEntity) {
        val clips = runCatching { json.decodeFromString<List<VideoClipItem>>(entity.clipsJson) }.getOrDefault(emptyList())
        val sfx = runCatching { json.decodeFromString<List<String>>(entity.sfxTagsJson) }.getOrDefault(emptyList())
        pushSnapshot(
            EditorTimelineSnapshot(
                projectName = entity.name,
                stylePreset = runCatching { VideoStylePreset.valueOf(entity.stylePreset) }.getOrDefault(VideoStylePreset.MINECRAFT),
                clips = clips,
                audioUriString = entity.audioUriString,
                musicTitle = entity.musicTitle,
                sfxTags = sfx,
                textOverlay = entity.textOverlay,
                subtitleText = entity.subtitleText,
                colorGrade = runCatching { ColorGradePreset.valueOf(entity.colorGrade) }.getOrDefault(ColorGradePreset.NATURAL),
                resolution = runCatching { ExportResolution.valueOf(entity.resolution) }.getOrDefault(ExportResolution.HD_720),
                bitrateMbps = entity.bitrateMbps
            )
        )
        _statusBanner.value = "Loaded project \"${entity.name}\"."
    }

    fun requestAiDirectorAnalysis() {
        val cur = _state.value
        val firstClip = cur.clips.firstOrNull()
        if (firstClip == null) {
            _statusBanner.value = "Import a video clip first so Gemini AI Director can inspect frames."
            return
        }
        viewModelScope.launch {
            _isAnalyzingAi.value = true
            _aiSuggestion.value = null
            val prefs = prefsRepo.preferencesFlow.first()
            val frames = processor.extractSampleFrames(Uri.parse(firstClip.uriString), count = 3)
            val summary = cur.clips.joinToString("; ") {
                "${it.title}: ${(it.trimEndMs - it.trimStartMs) / 1000}s @ ${it.speed}x"
            }
            val res = aiProvider.suggestVideoEdits(frames, cur.stylePreset, summary, prefs)
            frames.forEach { it.recycle() }

            res.onSuccess { suggestion ->
                _aiSuggestion.value = suggestion
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "AI Video Director failed."
            }
            _isAnalyzingAi.value = false
        }
    }

    fun applyAiSuggestion(suggestion: AiEditSuggestion) {
        val cur = _state.value
        val matchedGrade = when {
            suggestion.cinematicEffect.contains("horror", true) -> ColorGradePreset.HORROR_DARK
            suggestion.cinematicEffect.contains("warm", true) -> ColorGradePreset.WARM_GOLD
            suggestion.cinematicEffect.contains("contrast", true) -> ColorGradePreset.HIGH_CONTRAST
            suggestion.cinematicEffect.contains("teal", true) || suggestion.cinematicEffect.contains("cyber", true) ->
                ColorGradePreset.CINEMATIC_TEAL
            else -> ColorGradePreset.VIVID
        }
        val speed = suggestion.suggestedSpeed.coerceIn(0.75f, 1.5f)
        val updatedClips = cur.clips.map { it.copy(speed = speed, transitionAfter = TransitionType.CYBER_FLASH) }
        pushSnapshot(
            cur.copy(
                clips = updatedClips,
                colorGrade = matchedGrade,
                subtitleText = suggestion.suggestedSubtitles.joinToString(" • "),
                sfxTags = suggestion.soundEffects.take(4),
                musicTitle = if (cur.audioUriString == null) "AI Mood: ${suggestion.musicMood}" else cur.musicTitle
            )
        )
        _statusBanner.value = "Applied AI Director timeline recommendations! Preview and export when ready."
    }

    fun startExport() {
        viewModelScope.launch {
            val prefs = prefsRepo.preferencesFlow.first()
            val s = _state.value
            processor.startExport(
                clips = s.clips,
                audioTrackUri = s.audioUriString?.let { Uri.parse(it) },
                colorGrade = s.colorGrade,
                textOverlay = s.textOverlay,
                subtitleText = s.subtitleText,
                resolution = s.resolution,
                bitrateMbps = s.bitrateMbps,
                lowMemoryMode = prefs.lowResVideoPreview || prefs.batterySaverMode
            )
        }
    }

    fun cancelExport() {
        processor.cancelExport()
    }
}
