package com.example.core

import android.app.ActivityManager
import android.content.Context
import android.media.MediaCodecList
import android.media.MediaFormat
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.example.data.model.GraphicsQuality

data class DeviceHealthSnapshot(
    val deviceLabel: String,
    val androidVersionLabel: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeStorageMb: Long,
    val isLowRamDevice: Boolean,
    val isOnline: Boolean,
    val maxSupportedVideoHeight: Int,
    val recommendedGraphics: GraphicsQuality
)

object DeviceCapabilities {
    fun inspect(context: Context): DeviceHealthSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024L * 1024L)
        val availRamMb = memInfo.availMem / (1024L * 1024L)
        val isLowRam = am.isLowRamDevice || totalRamMb <= 3500L

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeStorageMb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024L * 1024L)

        val recommended = when {
            totalRamMb <= 3500L -> GraphicsQuality.LOW
            totalRamMb <= 6000L -> GraphicsQuality.BALANCED
            else -> GraphicsQuality.HIGH
        }

        val maxVideoHeight = detectMaxEncoderHeight()

        return DeviceHealthSnapshot(
            deviceLabel = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersionLabel = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            freeStorageMb = freeStorageMb,
            isLowRamDevice = isLowRam,
            isOnline = isNetworkAvailable(context),
            maxSupportedVideoHeight = maxVideoHeight,
            recommendedGraphics = recommended
        )
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun detectMaxEncoderHeight(): Int {
        return try {
            val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            var maxHeight = 720
            for (info in codecList.codecInfos) {
                if (!info.isEncoder) continue
                if (info.supportedTypes.any {
                        it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) ||
                            it.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
                    }
                ) {
                    val caps = info.getCapabilitiesForType(
                        info.supportedTypes.first {
                            it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) ||
                                it.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
                        }
                    )
                    val videoCaps = caps.videoCapabilities ?: continue
                    val upper = videoCaps.supportedHeights.upper
                    if (upper > maxHeight) {
                        maxHeight = upper
                    }
                }
            }
            maxHeight
        } catch (_: Exception) {
            1080
        }
    }
}
