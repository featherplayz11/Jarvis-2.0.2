package com.example.system

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.R
import com.example.data.model.AssistantMode
import com.example.ui.AssistantActivationBus
import com.example.voice.WakeWordForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FloatingHologramService : Service() {

    companion object {
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

        fun start(context: Context): Boolean {
            if (!canDrawOverlays(context)) return false
            context.startService(Intent(context, FloatingHologramService::class.java))
            return true
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingHologramService::class.java))
        }
    }

    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var isMinimized = false
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var observeJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 220
        }

        val dp = { v: Int -> (v * resources.displayMetrics.density).toInt() }

        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#E607132B"))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(2), Color.parseColor("#00E5FF"))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleView = TextView(this).apply {
            text = "STANDBY"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 12f
            setPadding(0, 0, dp(8), 0)
        }

        val minBtn = TextView(this).apply {
            text = "—"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#EF4444"))
            textSize = 14f
            setPadding(dp(8), dp(2), dp(4), dp(2))
        }

        header.addView(titleView)
        header.addView(minBtn)
        header.addView(closeBtn)

        val avatarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        val jarvisAvatar = ImageView(this).apply {
            setImageResource(R.drawable.jarvis_hologram)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(86), dp(86)).apply {
                topMargin = dp(6)
                bottomMargin = dp(6)
                rightMargin = dp(4)
            }
        }

        val roseAvatar = ImageView(this).apply {
            setImageResource(R.drawable.rose_hologram)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(86), dp(86)).apply {
                topMargin = dp(6)
                bottomMargin = dp(6)
            }
        }

        avatarRow.addView(jarvisAvatar)
        avatarRow.addView(roseAvatar)

        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val micBtn = TextView(this).apply {
            text = "Speak Wake Command"
            setTextColor(Color.parseColor("#10B981"))
            textSize = 11f
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        actionsRow.addView(micBtn)

        container.addView(header)
        container.addView(avatarRow)
        container.addView(actionsRow)

        // Reflect active voice-controlled mode ONLY (zero manual character switch buttons)
        observeJob = serviceScope.launch {
            AssistantActivationBus.mode.collect { mode ->
                when (mode) {
                    AssistantMode.INACTIVE -> {
                        titleView.text = "STANDBY"
                        titleView.setTextColor(Color.parseColor("#94B8D7"))
                        avatarRow.visibility = View.GONE
                        jarvisAvatar.visibility = View.GONE
                        roseAvatar.visibility = View.GONE
                    }
                    AssistantMode.JARVIS_ONLY -> {
                        titleView.text = "JARVIS"
                        titleView.setTextColor(Color.parseColor("#00E5FF"))
                        avatarRow.visibility = if (isMinimized) View.GONE else View.VISIBLE
                        jarvisAvatar.visibility = View.VISIBLE
                        roseAvatar.visibility = View.GONE
                    }
                    AssistantMode.ROSE_ONLY -> {
                        titleView.text = "ROSE"
                        titleView.setTextColor(Color.parseColor("#38BDF8"))
                        avatarRow.visibility = if (isMinimized) View.GONE else View.VISIBLE
                        jarvisAvatar.visibility = View.GONE
                        roseAvatar.visibility = View.VISIBLE
                    }
                    AssistantMode.DUAL_MODE -> {
                        titleView.text = "JARVIS & ROSE"
                        titleView.setTextColor(Color.parseColor("#22D3EE"))
                        avatarRow.visibility = if (isMinimized) View.GONE else View.VISIBLE
                        jarvisAvatar.visibility = View.VISIBLE
                        roseAvatar.visibility = View.VISIBLE
                    }
                }
            }
        }

        micBtn.setOnClickListener {
            val openVoice = Intent(this, MainActivity::class.java).apply {
                action = WakeWordForegroundService.ACTION_QUICK_LISTEN
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(openVoice)
        }

        minBtn.setOnClickListener {
            isMinimized = !isMinimized
            val activeMode = AssistantActivationBus.mode.value
            avatarRow.visibility = if (isMinimized || activeMode == AssistantMode.INACTIVE) View.GONE else View.VISIBLE
            actionsRow.visibility = if (isMinimized) View.GONE else View.VISIBLE
            minBtn.text = if (isMinimized) "▢" else "—"
        }

        closeBtn.setOnClickListener {
            stopSelf()
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }

        rootView = container
        windowManager?.addView(container, params)
        _isRunning.value = true
    }

    override fun onDestroy() {
        observeJob?.cancel()
        _isRunning.value = false
        rootView?.let { runCatching { windowManager?.removeView(it) } }
        rootView = null
        super.onDestroy()
    }
}
