package com.example.system

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private var instanceRef: WeakReference<JarvisAccessibilityService>? = null

        private val _isServiceEnabled = MutableStateFlow(false)
        val isServiceEnabled: StateFlow<Boolean> = _isServiceEnabled.asStateFlow()

        private val _activeControlBanner = MutableStateFlow<String?>(null)
        val activeControlBanner: StateFlow<String?> = _activeControlBanner.asStateFlow()

        private val blockedSensitiveKeywords = listOf(
            "password", "passcode", "pin", "bank", "pay", "wallet", "upi",
            "biometric", "fingerprint", "keystore", "credential", "vanguard", "anticheat"
        )

        fun getInstance(): JarvisAccessibilityService? = instanceRef?.get()

        fun emergencyStop() {
            _activeControlBanner.value = null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        _isServiceEnabled.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()?.lowercase().orEmpty()
        if (blockedSensitiveKeywords.any { pkg.contains(it) }) {
            _activeControlBanner.value = null
        }
    }

    override fun onInterrupt() {
        _activeControlBanner.value = null
    }

    override fun onDestroy() {
        _isServiceEnabled.value = false
        _activeControlBanner.value = null
        instanceRef = null
        super.onDestroy()
    }

    private fun isCurrentWindowSensitive(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString()?.lowercase().orEmpty()
        if (blockedSensitiveKeywords.any { pkg.contains(it) }) return true
        return containsPasswordField(root)
    }

    private fun containsPasswordField(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isPassword) return true
        for (i in 0 until node.childCount) {
            if (containsPasswordField(node.getChild(i))) return true
        }
        return false
    }

    fun performBackAction(): Boolean {
        _activeControlBanner.value = "Screen Control: Back"
        val ok = performGlobalAction(GLOBAL_ACTION_BACK)
        _activeControlBanner.value = null
        return ok
    }

    fun performHomeAction(): Boolean {
        _activeControlBanner.value = "Screen Control: Home"
        val ok = performGlobalAction(GLOBAL_ACTION_HOME)
        _activeControlBanner.value = null
        return ok
    }

    fun performScroll(down: Boolean): Boolean {
        if (isCurrentWindowSensitive()) return false
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val startY = if (down) dm.heightPixels * 0.72f else dm.heightPixels * 0.30f
        val endY = if (down) dm.heightPixels * 0.28f else dm.heightPixels * 0.75f
        return performSwipe(x, startY, x, endY, 260L, if (down) "Scrolling Down" else "Scrolling Up")
    }

    fun performTap(x: Float, y: Float): Boolean {
        if (isCurrentWindowSensitive()) return false
        _activeControlBanner.value = "Screen Control: Tap (${x.toInt()}, ${y.toInt()})"
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                _activeControlBanner.value = null
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                _activeControlBanner.value = null
            }
        }, null)
    }

    fun enterTextSafely(text: String): Boolean {
        if (isCurrentWindowSensitive()) return false
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (focused.isPassword) return false
        _activeControlBanner.value = "Screen Control: Text Entry"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        _activeControlBanner.value = null
        return ok
    }

    private fun performSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
        bannerText: String
    ): Boolean {
        _activeControlBanner.value = "Screen Control: $bannerText"
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                _activeControlBanner.value = null
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                _activeControlBanner.value = null
            }
        }, null)
    }
}
