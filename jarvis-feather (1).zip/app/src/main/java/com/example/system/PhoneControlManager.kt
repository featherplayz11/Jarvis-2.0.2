package com.example.system

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.KeyEvent
import java.util.Locale

data class InstalledAppInfo(
    val label: String,
    val packageName: String
)

sealed interface AppLaunchResult {
    data class Launched(val app: InstalledAppInfo) : AppLaunchResult
    data class BlockedByAllowlist(val app: InstalledAppInfo) : AppLaunchResult
    data class Ambiguous(val candidates: List<InstalledAppInfo>) : AppLaunchResult
    data class NotFound(val query: String) : AppLaunchResult
}

class PhoneControlManager(private val context: Context) {

    fun listLaunchableApps(): List<InstalledAppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        return resolveInfos
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .map { info ->
                InstalledAppInfo(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.activityInfo.packageName
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.US) }
            .toList()
    }

    fun launchAppByQuery(
        query: String,
        restrictToApproved: Boolean,
        approvedPackages: Set<String>
    ): AppLaunchResult {
        val clean = query.trim().lowercase(Locale.US)
        val apps = listLaunchableApps()
        val exact = apps.firstOrNull { it.label.lowercase(Locale.US) == clean }
        if (exact != null) {
            return executeLaunch(exact, restrictToApproved, approvedPackages)
        }

        val matches = apps.filter {
            it.label.lowercase(Locale.US).contains(clean) ||
                it.packageName.lowercase(Locale.US).contains(clean)
        }
        return when {
            matches.isEmpty() -> AppLaunchResult.NotFound(query)
            matches.size == 1 -> executeLaunch(matches.first(), restrictToApproved, approvedPackages)
            else -> AppLaunchResult.Ambiguous(matches.take(5))
        }
    }

    fun launchPackage(
        packageName: String,
        restrictToApproved: Boolean,
        approvedPackages: Set<String>
    ): AppLaunchResult {
        val app = listLaunchableApps().firstOrNull { it.packageName == packageName }
            ?: InstalledAppInfo(packageName, packageName)
        return executeLaunch(app, restrictToApproved, approvedPackages)
    }

    private fun executeLaunch(
        app: InstalledAppInfo,
        restrictToApproved: Boolean,
        approvedPackages: Set<String>
    ): AppLaunchResult {
        if (restrictToApproved && app.packageName !in approvedPackages) {
            return AppLaunchResult.BlockedByAllowlist(app)
        }
        val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return AppLaunchResult.NotFound(app.label)
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return AppLaunchResult.Launched(app)
    }

    fun goHome() {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openSystemScreen(command: String): String {
        val lower = command.lowercase(Locale.US)
        val action = when {
            lower.contains("wifi") -> Settings.ACTION_WIFI_SETTINGS
            lower.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
            lower.contains("display") || lower.contains("brightness") -> Settings.ACTION_DISPLAY_SETTINGS
            lower.contains("sound") || lower.contains("volume") -> Settings.ACTION_SOUND_SETTINGS
            lower.contains("battery") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            lower.contains("accessibility") -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        context.startActivity(intent)
        return "Opened system settings screen."
    }

    fun searchWeb(query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            runCatching { context.startActivity(browserIntent) }.isSuccess
        }
    }

    fun dispatchMediaKey(keyCode: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    fun openAccessibilitySettings() {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
    }

    fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        context.startActivity(intent)
    }
}
