package com.example.system

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.FileProvider
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class UpdateManifestInfo(
    val versionCode: Int,
    val versionName: String,
    val changelog: String,
    val apkUrl: String,
    val expectedSha256: String,
    val minSdk: Int
)

sealed interface UpdateStatus {
    data object Idle : UpdateStatus
    data object Checking : UpdateStatus
    data class UpToDate(val currentVersion: String) : UpdateStatus
    data class UpdateAvailable(val manifest: UpdateManifestInfo, val isCompatible: Boolean, val note: String) : UpdateStatus
    data class Downloading(val progressPercent: Int) : UpdateStatus
    data class ReadyToInstall(val apkFile: File, val verifiedSha256: String) : UpdateStatus
    data class Error(val message: String) : UpdateStatus
}

class SafeUpdateManager(private val context: Context) {

    private val _status = MutableStateFlow<UpdateStatus>(UpdateStatus.Idle)
    val status: StateFlow<UpdateStatus> = _status.asStateFlow()

    @Volatile
    private var cancelRequested = false

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun checkForUpdates(manifestUrl: String) = withContext(Dispatchers.IO) {
        if (manifestUrl.isBlank()) {
            _status.value = UpdateStatus.UpToDate(
                "${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE}) — No remote update server configured; local integrity verified."
            )
            return@withContext
        }
        if (!manifestUrl.startsWith("https://")) {
            _status.value = UpdateStatus.Error("Blocked insecure update URL. Official updates must use HTTPS.")
            return@withContext
        }

        _status.value = UpdateStatus.Checking
        try {
            val req = Request.Builder().url(manifestUrl).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    _status.value = UpdateStatus.Error("Update server returned HTTP ${resp.code}.")
                    return@withContext
                }
                val json = JSONObject(resp.body?.string().orEmpty())
                val manifest = UpdateManifestInfo(
                    versionCode = json.getInt("versionCode"),
                    versionName = json.getString("versionName"),
                    changelog = json.optString("changelog", "Stability & feature improvements."),
                    apkUrl = json.getString("apkUrl"),
                    expectedSha256 = json.getString("sha256").lowercase(),
                    minSdk = json.optInt("minSdk", 24)
                )

                if (manifest.versionCode <= BuildConfig.VERSION_CODE) {
                    _status.value = UpdateStatus.UpToDate(
                        "${BuildConfig.VERSION_NAME} (Latest verified: ${manifest.versionName})"
                    )
                } else {
                    val compatible = Build.VERSION.SDK_INT >= manifest.minSdk &&
                        manifest.apkUrl.startsWith("https://") &&
                        manifest.expectedSha256.length == 64
                    val note = when {
                        Build.VERSION.SDK_INT < manifest.minSdk ->
                            "Incompatible: Requires Android API ${manifest.minSdk}, device is API ${Build.VERSION.SDK_INT}."
                        !manifest.apkUrl.startsWith("https://") ->
                            "Blocked: APK download URL must use HTTPS."
                        manifest.expectedSha256.length != 64 ->
                            "Blocked: Missing valid SHA-256 integrity hash."
                        else -> "Compatible & SHA-256 verified manifest. User approval required before installation."
                    }
                    _status.value = UpdateStatus.UpdateAvailable(manifest, compatible, note)
                }
            }
        } catch (e: Exception) {
            _status.value = UpdateStatus.Error(e.localizedMessage ?: "Failed to check updates.")
        }
    }

    suspend fun downloadAndVerifyApk(manifest: UpdateManifestInfo) = withContext(Dispatchers.IO) {
        if (!manifest.apkUrl.startsWith("https://") || manifest.expectedSha256.length != 64) {
            _status.value = UpdateStatus.Error("Refused untrusted or unverified APK source.")
            return@withContext
        }
        cancelRequested = false
        _status.value = UpdateStatus.Downloading(0)

        val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
        val outFile = File(updatesDir, "jarvis_feather_${manifest.versionName}.apk")

        try {
            val req = Request.Builder().url(manifest.apkUrl).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    _status.value = UpdateStatus.Error("APK download failed (HTTP ${resp.code}).")
                    return@withContext
                }
                val body = resp.body ?: error("Empty response body.")
                val total = body.contentLength()
                val digest = MessageDigest.getInstance("SHA-256")

                body.byteStream().use { input ->
                    FileOutputStream(outFile).use { output ->
                        val buf = ByteArray(8192)
                        var downloaded = 0L
                        while (true) {
                            if (cancelRequested) {
                                outFile.delete()
                                _status.value = UpdateStatus.Idle
                                return@withContext
                            }
                            val read = input.read(buf)
                            if (read == -1) break
                            output.write(buf, 0, read)
                            digest.update(buf, 0, read)
                            downloaded += read
                            if (total > 0) {
                                _status.value = UpdateStatus.Downloading(((downloaded * 100) / total).toInt())
                            }
                        }
                    }
                }

                val actualSha = digest.digest().joinToString("") { "%02x".format(it) }
                if (actualSha != manifest.expectedSha256.lowercase()) {
                    outFile.delete()
                    _status.value = UpdateStatus.Error("Integrity check failed! SHA-256 mismatch.")
                    return@withContext
                }

                _status.value = UpdateStatus.ReadyToInstall(outFile, actualSha)
            }
        } catch (e: Exception) {
            outFile.delete()
            _status.value = UpdateStatus.Error(e.localizedMessage ?: "Download failed.")
        }
    }

    fun cancelDownload() {
        cancelRequested = true
    }

    fun launchSystemPackageInstaller(apkFile: File): Result<Unit> = runCatching {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}
