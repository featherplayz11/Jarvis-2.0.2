package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.Speaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

class VoiceTtsManager(context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceTtsManager"
    }

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady = false
    private val scope = CoroutineScope(Dispatchers.Main)
    private var lipSyncJob: Job? = null

    private val _speakingCharacter = MutableStateFlow<Speaker?>(null)
    val speakingCharacter: StateFlow<Speaker?> = _speakingCharacter.asStateFlow()

    private val _lipAmplitude = MutableStateFlow(0f)
    val lipAmplitude: StateFlow<Float> = _lipAmplitude.asStateFlow()

    private val _ttsAvailable = MutableStateFlow(false)
    val ttsAvailable: StateFlow<Boolean> = _ttsAvailable.asStateFlow()

    init {
        tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val langResult = tts?.setLanguage(Locale.US)
            isReady = langResult != TextToSpeech.LANG_MISSING_DATA &&
                langResult != TextToSpeech.LANG_NOT_SUPPORTED
            _ttsAvailable.value = isReady

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    startLipAnimation()
                }

                override fun onDone(utteranceId: String?) {
                    stopLipAnimation()
                    _speakingCharacter.value = null
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    stopLipAnimation()
                    _speakingCharacter.value = null
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    stopLipAnimation()
                    _speakingCharacter.value = null
                }
            })
        } else {
            Log.w(TAG, "TextToSpeech init failed with status $status")
            isReady = false
            _ttsAvailable.value = false
        }
    }

    fun speak(
        text: String,
        speaker: Speaker,
        jarvisPitch: Float = 0.88f,
        rosePitch: Float = 1.18f,
        queueAdd: Boolean = false
    ) {
        if (!isReady || text.isBlank()) return
        val cleanText = text.replace(Regex("\\[.*?\\]"), "").trim()
        if (cleanText.isEmpty()) return

        _speakingCharacter.value = speaker
        when (speaker) {
            Speaker.JARVIS -> {
                tts?.setPitch(jarvisPitch.coerceIn(0.6f, 1.3f))
                tts?.setSpeechRate(0.98f)
            }
            Speaker.ROSE -> {
                tts?.setPitch(rosePitch.coerceIn(0.8f, 1.5f))
                tts?.setSpeechRate(1.06f)
            }
            else -> {
                tts?.setPitch(1.0f)
                tts?.setSpeechRate(1.0f)
            }
        }
        val mode = if (queueAdd) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH
        tts?.speak(cleanText, mode, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
        stopLipAnimation()
        _speakingCharacter.value = null
    }

    private fun startLipAnimation() {
        lipSyncJob?.cancel()
        lipSyncJob = scope.launch {
            while (isActive) {
                _lipAmplitude.value = 0.25f + Random.nextFloat() * 0.75f
                delay(95L)
            }
        }
    }

    private fun stopLipAnimation() {
        lipSyncJob?.cancel()
        _lipAmplitude.value = 0f
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
